package com.example.core.service

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.test.core.app.ApplicationProvider
import com.example.core.widget.CircleToSearchOverlayActivity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], application = Application::class)
class StealthAndBankingGuardTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        MagicTuneCtsAccessibilityService.isBankingBlocked = false
        MagicTuneCtsAccessibilityService.isAccessibilityAutoHidden = false
        CircleToSearchOverlayActivity.isOverlayActive = false
        NoAccessibilityScreenEngine.isLiveScrollTranslateActive = false
    }

    @Test
    fun isSensitiveBankingPackage_blocksVneidAndBanks_butExcludesShoppingApps() {
        assertTrue(NoAccessibilityScreenEngine.isSensitiveBankingPackage("com.VCB"))
        assertTrue(NoAccessibilityScreenEngine.isSensitiveBankingPackage("vn.com.techcombank.bb.app"))
        assertTrue(NoAccessibilityScreenEngine.isSensitiveBankingPackage("com.mbmobile"))
        assertTrue(NoAccessibilityScreenEngine.isSensitiveBankingPackage("vn.gov.id.vneid"))
        assertTrue(NoAccessibilityScreenEngine.isSensitiveBankingPackage("com.vnpay.bidv"))

        // Shopping apps for live-scroll translation must never be treated as banking
        assertFalse(NoAccessibilityScreenEngine.isSensitiveBankingPackage("com.taobao.taobao"))
        assertFalse(NoAccessibilityScreenEngine.isSensitiveBankingPackage("com.alibaba.wireless"))
        assertFalse(NoAccessibilityScreenEngine.isSensitiveBankingPackage("com.shopee.vn"))
        assertFalse(NoAccessibilityScreenEngine.isSensitiveBankingPackage(""))
    }

    @Test
    fun isAnyFeatureActive_isFalseWhenIdle_andTrueDuringTemporaryBurst() {
        assertFalse(MagicTuneCtsAccessibilityService.isAnyFeatureActive())

        MagicTuneCtsAccessibilityService.beginTemporaryBurst(1000L)
        assertTrue(MagicTuneCtsAccessibilityService.isAnyFeatureActive())

        MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(context, idleDelayMs = 5000L)
        assertFalse(MagicTuneCtsAccessibilityService.isAnyFeatureActive())
    }

    @Test
    fun disableServiceViaSecureSettings_separatesIdleStealthFromBankingBlock() {
        val component = ComponentName(context, MagicTuneCtsAccessibilityService::class.java)

        // Idle stealth: disables component cleanly without setting isBankingBlocked
        MagicTuneCtsAccessibilityService.disableServiceViaSecureSettings(
            context = context,
            forceRemoveFromSettings = true,
            isBankingBlock = false
        )
        assertFalse(MagicTuneCtsAccessibilityService.isBankingBlocked)
        assertFalse(MagicTuneCtsAccessibilityService.isAccessibilityAutoHidden)
        assertEquals(
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            context.packageManager.getComponentEnabledSetting(component)
        )

        // Banking block: sets both isBankingBlocked and isAccessibilityAutoHidden
        MagicTuneCtsAccessibilityService.disableServiceViaSecureSettings(
            context = context,
            forceRemoveFromSettings = true,
            isBankingBlock = true
        )
        assertTrue(MagicTuneCtsAccessibilityService.isBankingBlocked)
        assertTrue(MagicTuneCtsAccessibilityService.isAccessibilityAutoHidden)
    }
}
