package com.example.core.receiver

import android.app.Notification
import android.content.ComponentName
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.example.core.keyboard.MagicOtpManager
import com.example.core.license.LicenseManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * BankingNotificationListenerService:
 * Dịch vụ Auto-Admin chuyên biệt dành riêng cho thiết bị của Admin.
 * - Trên máy người dùng thông thường (`!LicenseManager.isCurrentUserAdmin`): Dịch vụ hoàn toàn KHÔNG đọc bất kỳ thông báo nào (bảo vệ quyền riêng tư 100%).
 * - Trên máy Admin (khi bật công tắc `Tự động duyệt Pro qua Thông báo Ngân hàng & SMS`):
 *   Tự động bắt biến động số dư (+50.000đ / +100.000đ) từ các ứng dụng Ngân hàng chính thống (MB Bank, Vietcombank, Techcombank, BIDV, VietinBank, ACB, VPBank, TPBank, Agribank, MoMo...)
 *   và tin nhắn SMS Brandname Ngân hàng, đối soát chống gian lận 7 lớp và kích hoạt Pro tự động lên Firebase Cloud.
 *
 * TỐI ƯU HÓA ANR CHUẨN GOOGLE (100% NON-BLOCKING MAIN THREAD):
 * Toàn bộ quá trình quét regex, băm chữ ký SHA-256 và lưu SharedPreferences được đẩy sang `serviceScope` (Dispatchers.Default),
 * hàm `onNotificationPosted` và `onListenerConnected` trả quyền điều khiển về hệ điều hành trong < 0.1ms.
 */
class BankingNotificationListenerService : NotificationListenerService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onListenerConnected() {
        super.onListenerConnected()
        val appCtx = applicationContext ?: return
        serviceScope.launch {
            try {
                val activeList = try { activeNotifications } catch (_: Throwable) { null }
                val now = System.currentTimeMillis()
                if (activeList != null) {
                    for (sbn in activeList) {
                        if (!sbn.isOngoing && (now - sbn.postTime) in 0..45_000L) {
                            MagicOtpManager.processNotification(appCtx, sbn)
                        }
                    }
                }
                if (!LicenseManager.isCurrentUserAdmin(appCtx)) return@launch
                if (!LicenseManager.isAutoApproveNotificationPaymentEnabled(appCtx)) return@launch
                for (sbn in activeList ?: emptyArray()) {
                    inspectStatusBarNotification(sbn)
                }
            } catch (_: Throwable) {}
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return
        val appCtx = applicationContext ?: return
        // Trả quyền điều khiển ngay lập tức cho Main Thread của Android SystemServer (0ms ANR guarantee)
        serviceScope.launch {
            MagicOtpManager.processNotification(appCtx, sbn)
            inspectStatusBarNotification(sbn)
        }
    }

    private fun inspectStatusBarNotification(sbn: StatusBarNotification) {
        try {
            val appCtx = applicationContext ?: return
            // Chỉ hoạt động trên máy của Admin và khi công tắc Auto-Approve đang BẬT
            if (!LicenseManager.isCurrentUserAdmin(appCtx)) return
            if (!LicenseManager.isAutoApproveNotificationPaymentEnabled(appCtx)) return

            val pkg = sbn.packageName?.trim().orEmpty()
            if (pkg.isBlank() || pkg == appCtx.packageName) return

            // Chỉ kiểm tra thông báo từ App Ngân Hàng chính thống hoặc App SMS mặc định của hệ thống
            val isBankApp = LicenseManager.OFFICIAL_BANK_APP_PACKAGES.contains(pkg)
            val isSysSmsApp = LicenseManager.SYSTEM_SMS_APP_PACKAGES.contains(pkg)
            if (!isBankApp && !isSysSmsApp) return

            val notification = sbn.notification ?: return
            val extras = notification.extras ?: return

            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
            val bigTitle = extras.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString()?.trim().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
            val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
            val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim().orEmpty()
            val summaryText = extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT)?.toString()?.trim().orEmpty()
            val tickerText = notification.tickerText?.toString()?.trim().orEmpty()

            val linesBuilder = StringBuilder()
            if (bigText.isNotBlank()) {
                linesBuilder.append(bigText).append(" ")
            }
            if (text.isNotBlank() && !bigText.contains(text)) {
                linesBuilder.append(text).append(" ")
            }
            val textLines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            if (textLines != null) {
                for (line in textLines) {
                    val l = line?.toString()?.trim().orEmpty()
                    if (l.isNotBlank() && !linesBuilder.contains(l)) {
                        linesBuilder.append(l).append(" ")
                    }
                }
            }
            if (linesBuilder.isEmpty() && tickerText.isNotBlank()) {
                linesBuilder.append(tickerText)
            }

            val effectiveTitle = bigTitle.ifBlank { title }
            val effectiveBody = linesBuilder.toString().trim()
            if (effectiveBody.isBlank() && effectiveTitle.isBlank()) return

            // Thu thập metadata người gửi (chống SĐT cá nhân giả danh Brandname trong app SMS)
            val metaBuilder = StringBuilder()
            metaBuilder.append(sbn.tag.orEmpty()).append(" ")
            metaBuilder.append(subText).append(" ")
            metaBuilder.append(summaryText).append(" ")
            try {
                @Suppress("DEPRECATION")
                val people = extras.getStringArray(Notification.EXTRA_PEOPLE)
                people?.forEach { metaBuilder.append(it).append(" ") }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val personList = extras.getParcelableArrayList<android.app.Person>(Notification.EXTRA_PEOPLE_LIST)
                    personList?.forEach { p ->
                        metaBuilder.append(p.uri.orEmpty()).append(" ")
                        metaBuilder.append(p.name ?: "").append(" ")
                        metaBuilder.append(p.key.orEmpty()).append(" ")
                    }
                }
            } catch (_: Throwable) {}

            LicenseManager.processAdminIncomingBankPaymentNotification(
                context = appCtx,
                sourcePackageOrSender = pkg,
                rawTitle = effectiveTitle,
                rawText = effectiveBody,
                isSms = false,
                rawPeopleAndMeta = metaBuilder.toString()
            )
        } catch (_: Throwable) {}
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && LicenseManager.isCurrentUserAdmin(applicationContext)) {
                requestRebind(ComponentName(this, BankingNotificationListenerService::class.java))
            }
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        try {
            serviceScope.cancel()
        } catch (_: Throwable) {}
        super.onDestroy()
    }
}
