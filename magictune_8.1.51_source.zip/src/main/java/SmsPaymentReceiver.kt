package com.example.core.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.example.core.license.LicenseManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * SmsPaymentReceiver:
 * Bộ thu tin nhắn SMS biến động số dư Ngân hàng dành riêng cho thiết bị của Admin.
 * - Trên máy người dùng thông thường (`!LicenseManager.isCurrentUserAdmin`): Bỏ qua 100%, không xử lý SMS.
 * - Trên máy Admin: Chỉ chấp nhận SMS từ Brandname Ngân hàng chính thống (MBBANK, VIETCOMBANK, VCB, TECHCOMBANK, BIDV, VIETINBANK, ACB, VPBANK, TPBANK, AGRIBANK...),
 *   tuyệt đối chặn mọi tin nhắn từ số điện thoại cá nhân (09..., 03..., 07..., 08..., 05..., +84...).
 *
 * TỐI ƯU HÓA ANR CHUẨN GOOGLE (goAsync):
 * Sử dụng goAsync() để giải phóng Main Thread ngay lập tức, toàn bộ logic băm SHA-256
 * và cập nhật Firestore chạy trên Dispatchers.Default ngầm.
 */
class SmsPaymentReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent == null) return
        val appCtx = context.applicationContext
        if (!LicenseManager.isCurrentUserAdmin(appCtx)) return
        if (!LicenseManager.isAutoApproveNotificationPaymentEnabled(appCtx)) return

        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
                if (messages.isNullOrEmpty()) return@launch

                val sender = messages.firstOrNull()?.displayOriginatingAddress
                    ?.ifBlank { messages.firstOrNull()?.originatingAddress }
                    ?.trim()
                    .orEmpty()

                if (!LicenseManager.isOfficialBankSmsSender(sender)) {
                    return@launch
                }

                val bodyBuilder = StringBuilder()
                for (msg in messages) {
                    val part = msg?.displayMessageBody ?: msg?.messageBody
                    if (!part.isNullOrBlank()) {
                        bodyBuilder.append(part)
                    }
                }
                val fullBody = bodyBuilder.toString().trim()
                if (fullBody.isBlank()) return@launch

                LicenseManager.processAdminIncomingBankPaymentNotification(
                    context = appCtx,
                    sourcePackageOrSender = sender,
                    rawTitle = sender,
                    rawText = fullBody,
                    isSms = true,
                    rawPeopleAndMeta = sender
                )
            } catch (_: Throwable) {
            } finally {
                try { pendingResult.finish() } catch (_: Throwable) {}
            }
        }
    }
}
