package com.example.core.keyboard

import android.content.ClipboardManager
import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Bộ Nhớ Tạm Dùng Chung Trên Thiết Bị Android (Shared Local Android Clipboard Store):
 * - Đồng bộ 100% giữa Bàn phím MAGIC LIVE trên Bảng Trợ Lý và Bàn phím Hệ Thống trên mọi ứng dụng.
 * - Lưu trữ hoàn toàn cục bộ trên bộ nhớ Android (SharedPreferences), KHÔNG dùng Firebase -> Admin tốn 0đ chi phí!
 * - Tự động dọn sạch các văn bản đã sao chép cũ quá 15 ngày (TTL = 15 ngày).
 */
object MagicClipboardStore {

    private const val PREFS_NAME = "magic_shared_local_clipboard_v1"
    private const val KEY_ENTRIES_JSON = "clipboard_entries_json"
    private const val MAX_ITEMS = 50
    const val RETENTION_MS = 15L * 24L * 60L * 60L * 1000L // 15 ngày

    data class ClipboardEntry(
        val text: String,
        val timestampMs: Long,
        val isPinned: Boolean = false
    )

    private var isWatchingSystemClipboard = false
    private var systemClipboardManager: ClipboardManager? = null
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    @Volatile
    private var cachedEntries: List<ClipboardEntry>? = null
    private val saveLock = Any()
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun ensureWatching(context: Context) {
        val appCtx = context.applicationContext ?: context
        if (!isWatchingSystemClipboard) {
            isWatchingSystemClipboard = true
            try {
                val cm = appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                systemClipboardManager = cm
                cm?.addPrimaryClipChangedListener {
                    syncFromSystemClipboard(appCtx)
                }
            } catch (_: Throwable) {}
        }
        syncFromSystemClipboard(appCtx)
    }

    fun addChangeListener(listener: () -> Unit) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
        }
    }

    fun removeChangeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyListeners() {
        for (l in listeners) {
            try {
                l.invoke()
            } catch (_: Throwable) {}
        }
    }

    /**
     * Đọc văn bản mới nhất từ ClipboardManager hệ thống Android và đồng bộ vào bộ nhớ tạm dùng chung.
     */
    fun syncFromSystemClipboard(context: Context): String {
        val appCtx = context.applicationContext ?: context
        val latest = try {
            val cm = systemClipboardManager
                ?: (appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager).also {
                    systemClipboardManager = it
                }
            val clip = cm?.primaryClip
            if (clip != null && clip.itemCount > 0) {
                clip.getItemAt(0)?.coerceToText(appCtx)?.toString()?.trim().orEmpty()
            } else ""
        } catch (_: Throwable) {
            ""
        }

        if (latest.isNotEmpty()) {
            recordCopiedText(appCtx, latest)
        } else {
            pruneExpiredEntries(appCtx)
        }
        return latest
    }

    /**
     * Ghi nhận một văn bản vừa copy vào bộ nhớ tạm dùng chung (lưu trên Android) và tự động xóa mục cũ quá 15 ngày.
     */
    @Synchronized
    fun recordCopiedText(context: Context, rawText: String) {
        val clean = rawText.trim()
        if (clean.isEmpty()) return
        val appCtx = context.applicationContext ?: context
        val now = System.currentTimeMillis()
        val current = loadValidEntriesInternal(appCtx, now).toMutableList()

        val existingIdx = current.indexOfFirst { it.text == clean }
        val wasPinned = if (existingIdx >= 0) current[existingIdx].isPinned else false

        if (existingIdx >= 0) {
            val existing = current[existingIdx]
            // Nếu đã lưu gần đây (< 3 giây) và không đổi trạng thái ghim thì bỏ qua để tránh bão sự kiện
            if (now - existing.timestampMs < 3000L) {
                return
            }
            current.removeAt(existingIdx)
        }

        val entry = ClipboardEntry(clean, now, wasPinned)
        if (wasPinned) {
            // Đã ghim -> giữ ở vùng ghim đầu danh sách
            val firstUnpinnedIdx = current.indexOfFirst { !it.isPinned }
            if (firstUnpinnedIdx >= 0) {
                current.add(firstUnpinnedIdx, entry)
            } else {
                current.add(0, entry)
            }
        } else {
            // Không ghim -> chèn ngay sau các mục đã ghim
            val pinCount = current.count { it.isPinned }
            current.add(pinCount.coerceAtMost(current.size), entry)
        }

        while (current.size > MAX_ITEMS) {
            val lastUnpinnedIdx = current.indexOfLast { !it.isPinned }
            if (lastUnpinnedIdx >= 0) {
                current.removeAt(lastUnpinnedIdx)
            } else {
                break
            }
        }
        saveEntriesInternal(appCtx, current)
        notifyListeners()
    }

    /**
     * Ghim hoặc Bỏ ghim một văn bản trong bộ nhớ tạm (Tối đa 3 văn bản ghim).
     * Trả về true nếu thao tác thành công, false nếu đã đạt tối đa 3 mục ghim.
     */
    @Synchronized
    fun togglePin(context: Context, textToPin: String): Boolean {
        val appCtx = context.applicationContext ?: context
        val now = System.currentTimeMillis()
        val current = loadValidEntriesInternal(appCtx, now).toMutableList()
        val idx = current.indexOfFirst { it.text == textToPin }
        if (idx < 0) return false

        val item = current[idx]
        if (item.isPinned) {
            // Bỏ ghim
            current.removeAt(idx)
            val unpinnedEntry = item.copy(isPinned = false)
            val pinCount = current.count { it.isPinned }
            current.add(pinCount.coerceAtMost(current.size), unpinnedEntry)
            saveEntriesInternal(appCtx, current)
            notifyListeners()
            return true
        } else {
            // Ghim: Cho phép ghim tối đa 3 văn bản hay sử dụng
            val currentPinnedCount = current.count { it.isPinned }
            if (currentPinnedCount >= 3) {
                return false
            }
            current.removeAt(idx)
            val pinnedEntry = item.copy(isPinned = true)
            current.add(0, pinnedEntry)
            saveEntriesInternal(appCtx, current)
            notifyListeners()
            return true
        }
    }

    /**
     * Kiểm tra xem văn bản có đang được ghim hay không.
     */
    @Synchronized
    fun isPinned(context: Context, textToCheck: String): Boolean {
        val appCtx = context.applicationContext ?: context
        val now = System.currentTimeMillis()
        return loadValidEntriesInternal(appCtx, now).firstOrNull { it.text == textToCheck }?.isPinned ?: false
    }

    /**
     * Lấy danh sách toàn bộ văn bản trong bộ nhớ tạm cục bộ máy (Mục ghim luôn xếp ở đầu).
     */
    @Synchronized
    fun getItems(context: Context): List<String> {
        val appCtx = context.applicationContext ?: context
        val now = System.currentTimeMillis()
        return loadValidEntriesInternal(appCtx, now).map { it.text }
    }

    /**
     * Lấy danh sách chi tiết các mục clipboard (bao gồm trạng thái ghim) từ bộ nhớ máy cục bộ.
     */
    @Synchronized
    fun getDetailedEntries(context: Context): List<ClipboardEntry> {
        val appCtx = context.applicationContext ?: context
        val now = System.currentTimeMillis()
        return loadValidEntriesInternal(appCtx, now)
    }

    @Synchronized
    fun getLatestItem(context: Context): String {
        val appCtx = context.applicationContext ?: context
        val now = System.currentTimeMillis()
        return loadValidEntriesInternal(appCtx, now).firstOrNull()?.text.orEmpty()
    }

    /**
     * Xóa sạch bộ nhớ tạm: Mặc định xóa HẾT TẤT CẢ mọi văn bản, bao gồm cả các mục đã ghim.
     */
    @Synchronized
    fun clearAll(context: Context, preservePinned: Boolean = false) {
        val appCtx = context.applicationContext ?: context
        if (preservePinned) {
            val now = System.currentTimeMillis()
            val current = loadValidEntriesInternal(appCtx, now)
            val pinned = current.filter { it.isPinned }
            saveEntriesInternal(appCtx, pinned)
        } else {
            cachedEntries = emptyList()
            // Xóa toàn bộ nội dung trong SharedPreferences của máy điện thoại, bao gồm cả mục ghim
            ioScope.launch {
                synchronized(saveLock) {
                    appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit()
                        .remove(KEY_ENTRIES_JSON)
                        .apply()
                }
            }
        }
        try {
            val cm = systemClipboardManager
                ?: (appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                cm?.clearPrimaryClip()
            }
        } catch (_: Throwable) {}
        notifyListeners()
    }

    @Synchronized
    fun pruneExpiredEntries(context: Context) {
        val appCtx = context.applicationContext ?: context
        loadValidEntriesInternal(appCtx, System.currentTimeMillis())
    }

    private fun loadValidEntriesInternal(context: Context, nowMs: Long): List<ClipboardEntry> {
        val memCached = cachedEntries
        if (memCached != null) {
            val validMem = memCached.filter { it.isPinned || nowMs - it.timestampMs <= RETENTION_MS }
            if (validMem.size != memCached.size) {
                saveEntriesInternal(context, validMem)
            }
            return validMem
        }

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val rawJson = prefs.getString(KEY_ENTRIES_JSON, null)
        if (rawJson == null) {
            cachedEntries = emptyList()
            return emptyList()
        }
        val validList = mutableListOf<ClipboardEntry>()
        var hadExpiredOrInvalid = false

        try {
            val arr = JSONArray(rawJson)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val text = obj.optString("text", "").trim()
                val ts = obj.optLong("ts", 0L)
                val isPinned = obj.optBoolean("pinned", false)
                if (text.isEmpty() || ts <= 0L) {
                    hadExpiredOrInvalid = true
                    continue
                }
                // Các mục đã ghim thì giữ vĩnh viễn, mục không ghim xóa sau 15 ngày
                if (!isPinned && nowMs - ts > RETENTION_MS) {
                    hadExpiredOrInvalid = true
                    continue
                }
                if (validList.none { it.text == text }) {
                    validList.add(ClipboardEntry(text, ts, isPinned))
                }
            }
        } catch (_: Throwable) {
            cachedEntries = emptyList()
            return emptyList()
        }

        // Sắp xếp: Mục ghim luôn ở trên cùng (tối đa 3 mục)
        val sortedList = validList.sortedWith(
            compareByDescending<ClipboardEntry> { it.isPinned }
                .thenByDescending { it.timestampMs }
        )
        cachedEntries = sortedList

        if (hadExpiredOrInvalid) {
            saveEntriesInternal(context, sortedList)
        }
        return sortedList
    }

    private fun saveEntriesInternal(context: Context, entries: List<ClipboardEntry>) {
        val snapshot = entries.take(MAX_ITEMS).toList()
        cachedEntries = snapshot
        val appCtx = context.applicationContext ?: context
        ioScope.launch {
            synchronized(saveLock) {
                try {
                    val arr = JSONArray()
                    for (entry in snapshot) {
                        val obj = JSONObject()
                        obj.put("text", entry.text)
                        obj.put("ts", entry.timestampMs)
                        obj.put("pinned", entry.isPinned)
                        arr.put(obj)
                    }
                    appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit()
                        .putString(KEY_ENTRIES_JSON, arr.toString())
                        .apply()
                } catch (_: Throwable) {}
            }
        }
    }
}
