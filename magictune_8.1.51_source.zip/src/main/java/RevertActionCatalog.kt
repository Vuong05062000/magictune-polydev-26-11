package com.example.core.restore

/** Small, explicit restore actions used by the undo center. */
data class RevertActionDefinition(
    val id: String,
    val section: String,
    val title: String,
    val description: String,
    val commands: List<String>
)

object RevertActionCatalog {
    /** 72 additional atomic actions; together with the 8 existing presets this gives 80 choices. */
    val actions: List<RevertActionDefinition> = listOf(
        // Display and refresh rate (9)
        action("window_animations", "Màn hình", "Hoạt ảnh cửa sổ", "Đặt tốc độ hoạt ảnh về mặc định 1×.", "settings put global window_animation_scale 1.0"),
        action("transition_animations", "Màn hình", "Hoạt ảnh chuyển cảnh", "Đặt tốc độ chuyển cảnh về mặc định 1×.", "settings put global transition_animation_scale 1.0"),
        action("animator_duration", "Màn hình", "Thời lượng hiệu ứng", "Đặt thời lượng hiệu ứng về mặc định 1×.", "settings put global animator_duration_scale 1.0"),
        action("peak_refresh", "Màn hình", "Giới hạn tần số quét tối đa", "Bỏ giới hạn do MagicTune đặt để hệ thống tự quản lý.", "settings delete system peak_refresh_rate"),
        action("min_refresh", "Màn hình", "Giới hạn tần số quét tối thiểu", "Bỏ giới hạn do MagicTune đặt để hệ thống tự quản lý.", "settings delete system min_refresh_rate"),
        action("user_refresh", "Màn hình", "Tần số quét người dùng", "Trả lựa chọn tần số quét về tự động.", "settings put system user_refresh_rate 0"),
        action("smart_refresh_system", "Màn hình", "Tần số quét thông minh (System)", "Xóa ghi đè tần số quét của hệ thống.", "settings delete system smart_refresh_rate"),
        action("smart_refresh_secure", "Màn hình", "Tần số quét thông minh (Secure)", "Xóa ghi đè tần số quét bảo mật.", "settings delete secure smart_refresh_rate"),
        action("thermal_display_overrides", "Màn hình", "Ghi đè làm mát màn hình", "Xóa các khóa nhiệt và làm mát màn hình do app ghi.", "settings delete system smart_cooling_mode", "settings delete system hw_thermal_mode", "settings delete secure hw_thermal_mode", "settings delete system thermal_control"),

        // Navigation and touch (9)
        action("nav_pill_visibility", "Điều hướng & cảm ứng", "Thanh điều hướng", "Hiện thanh điều hướng và gợi ý cử chỉ mặc định.", "settings put secure gesture_navigation_pill_display 0", "settings put system gesture_navigation_pill_display 0", "settings put global gesture_navigation_pill_display 0", "settings put system gesture_pill_display 0"),
        action("nav_hide_flags", "Điều hướng & cảm ứng", "Cờ ẩn thanh điều hướng", "Gỡ trạng thái ẩn thanh điều hướng.", "settings put secure honor_hide_navigation_bar 0", "settings put system honor_hide_navigation_bar 0", "settings put secure hide_navigation_bar 0", "settings put system hide_navigation_bar 0", "settings put global hide_navigation_bar 0"),
        action("nav_immersive", "Điều hướng & cảm ứng", "Chế độ toàn màn hình cử chỉ", "Tắt chế độ ẩn thanh điều hướng toàn màn hình.", "settings put secure secure_gesture_navigation_immersive 0"),
        action("nav_hints", "Điều hướng & cảm ứng", "Gợi ý cử chỉ điều hướng", "Hiện lại thanh gợi ý và dấu điều hướng.", "settings put secure navigation_bar_hint 1", "settings put system navigation_bar_hint 1", "settings put secure show_gesture_bar 1", "settings put system show_gesture_bar 1", "settings put secure show_navigation_bar_hint 1", "settings put system show_navigation_bar_hint 1", "settings put secure gesture_hint_bar 1"),
        action("yoyo_nav_wake", "Điều hướng & cảm ứng", "Đánh thức YOYO từ thanh điều hướng", "Khôi phục các cờ gọi YOYO gốc của Honor.", "settings put secure navigation_bar_wakeup_yoyo 1", "settings put secure yoyo_navigation_bar_wakeup 1", "settings put system navigation_bar_wakeup_yoyo 1", "settings put secure wake_up_yoyo_by_nav_bar 1", "settings put secure yoyo_assistant_gesture_switch 1"),
        action("assist_long_home", "Điều hướng & cảm ứng", "Nhấn giữ nút Home", "Khôi phục cử chỉ trợ lý mặc định của Android.", "settings put secure assist_long_press_home_enabled 1"),
        action("touch_response", "Điều hướng & cảm ứng", "Phản hồi cảm ứng", "Trả thời gian phản hồi về mặc định.", "settings put secure touch_response_time 1", "settings put system touch_response_time 1"),
        action("touch_sensitivity", "Điều hướng & cảm ứng", "Độ nhạy và chế độ găng tay", "Tắt các chế độ tăng nhạy cảm ứng do app bật.", "settings put secure touch_sensitivity 0", "settings put secure high_touch_sensitivity_enable 0", "settings put system touch_screen_film_switch 0", "settings put system glove_file_status 0", "settings put system touch_glove_mode 0"),
        action("touch_edge_sampling", "Điều hướng & cảm ứng", "Cảm ứng cạnh và lấy mẫu game", "Trả các thông số cạnh và lấy mẫu về mặc định.", "settings put secure touch_responsiveness_level 0", "settings put system game_touch_sampling_rate 0", "settings put secure touch_edge_filter 0"),

        // Network and Wi-Fi (9)
        action("wifi_scan", "Mạng & Wi-Fi", "Quét Wi-Fi nền", "Cho phép hệ thống quản lý quét Wi-Fi.", "settings put global wifi_scan_always_enabled 1"),
        action("ble_scan", "Mạng & Wi-Fi", "Quét Bluetooth nền", "Cho phép hệ thống quản lý quét BLE.", "settings put global ble_scan_always_enabled 1"),
        action("wifi_scan_throttle", "Mạng & Wi-Fi", "Giới hạn quét Wi-Fi", "Giữ cơ chế giới hạn quét mặc định của Android.", "settings put global wifi_scan_throttle_enabled 1"),
        action("mobile_data_standby", "Mạng & Wi-Fi", "Dữ liệu di động chờ nền", "Đặt lại giá trị chờ dữ liệu di động theo cấu hình tiết kiệm pin của app.", "settings put global mobile_data_always_on 0"),
        action("wifi_notifications", "Mạng & Wi-Fi", "Thông báo mạng Wi-Fi", "Khôi phục thông báo Wi-Fi và cảnh báo kết nối kém.", "settings put global wifi_networks_available_notification_on 1", "settings put global wifi_poor_connection_warning 1"),
        action("wifi_sleep", "Mạng & Wi-Fi", "Chính sách ngủ Wi-Fi", "Trả chính sách ngủ Wi-Fi về lựa chọn Android mặc định.", "settings put global wifi_sleep_policy 2", "settings put global wifi_suspend_optimizations_enabled 1"),
        action("wifi_latency", "Mạng & Wi-Fi", "Độ trễ và băng tần Wi-Fi", "Tắt chế độ độ trễ thấp và khôi phục băng tần tự động.", "settings put global wifi_low_latency_mode 0", "settings put global wifi_frequency_band 0", "settings put global network_avoid_bad_wifi 0", "settings put global wifi_verbose_logging_enabled 0"),
        action("wifi_scan_interval", "Mạng & Wi-Fi", "Chu kỳ quét Wi-Fi", "Khôi phục chu kỳ quét và tối ưu tạm ngưng Wi-Fi.", "settings put global wifi_framework_scan_interval_ms 10000", "settings put global wifi_suspend_optimizations_enabled 1"),
        action("dual_wifi_link_turbo", "Mạng & Wi-Fi", "Wi-Fi kép và Link Turbo", "Tắt các cờ tăng tốc đa mạng do app đặt.", "settings put system dual_wifi_state 0", "settings put system hw_dual_band_enable 0", "settings put system hihonor_dual_band_enable 0", "settings put global wifi_boost_enable 0", "settings put system wifi_accelerate_state 0", "settings put system link_turbo_enable 0", "settings put global link_turbo_enable 0", "settings put secure link_turbo_enable 0", "settings put system smart_dual_card_switch 0"),

        // Battery and thermal (9)
        action("app_standby", "Pin & nhiệt", "App Standby", "Bật lại quản lý ứng dụng chờ của Android.", "settings put global app_standby_enabled 1"),
        action("cached_freezer", "Pin & nhiệt", "Đóng băng ứng dụng đệm", "Khôi phục cơ chế freezer mặc định của Android.", "settings put global cached_apps_freezer enabled", "device_config put activity_manager_native_boot use_freezer true >/dev/null 2>&1 || true"),
        action("adaptive_battery", "Pin & nhiệt", "Pin thích ứng", "Bật lại quản lý pin thích ứng.", "settings put global adaptive_battery_management_enabled 1"),
        action("device_idle", "Pin & nhiệt", "Doze và Device Idle", "Xóa cấu hình chờ tùy chỉnh để Android dùng giá trị mặc định.", "settings delete global device_idle_constants"),
        action("job_scheduler", "Pin & nhiệt", "Lịch chạy tác vụ nền", "Xóa lịch chạy tùy chỉnh để hệ thống tự điều phối.", "settings delete global job_scheduler_constants"),
        action("adaptive_power", "Pin & nhiệt", "Tiết kiệm pin thích ứng", "Bật lại chế độ tiết kiệm pin do Android quản lý.", "cmd power set-adaptive-power-saver-enabled true >/dev/null 2>&1 || true"),
        action("smart_5g", "Pin & nhiệt", "Smart 5G", "Khôi phục chuyển mạng thông minh trên các namespace hỗ trợ.", "settings put system smart_5g 1", "settings put global smart_5g 1", "settings put secure smart_5g 1"),
        action("battery_thermal_services", "Pin & nhiệt", "Dịch vụ nhiệt và làm mát", "Đặt hệ thống nhiệt về điều khiển của ROM.", "cmd thermalservice reset 2>/dev/null || true"),
        action("battery_saver_mobile", "Pin & nhiệt", "Chờ modem khi có Wi-Fi", "Không giữ dữ liệu di động luôn hoạt động khi Wi-Fi đã kết nối.", "settings put global mobile_data_always_on 0"),

        // Sound, font and notifications (9)
        action("font_scale", "Âm thanh & thông báo", "Cỡ chữ", "Đưa cỡ chữ về tỷ lệ chuẩn.", "settings put system font_scale 1.0"),
        action("font_weight", "Âm thanh & thông báo", "Độ đậm chữ", "Đưa độ đậm chữ về tỷ lệ chuẩn.", "settings put system font_weight_scale 1.0"),
        action("bluetooth_volume", "Âm thanh & thông báo", "Âm lượng Bluetooth tuyệt đối", "Khôi phục đồng bộ âm lượng Bluetooth.", "settings put global bluetooth_absolute_volume 1"),
        action("sound_effects", "Âm thanh & thông báo", "Hiệu ứng âm thanh", "Bật lại hiệu ứng âm thanh hệ thống.", "settings put system sound_effects_enabled 1"),
        action("default_notification_sound", "Âm thanh & thông báo", "Âm báo mặc định", "Khôi phục âm báo mặc định của hệ thống.", "settings put system use_default_notification_sound 1"),
        action("gentle_notifications", "Âm thanh & thông báo", "Thông báo nhẹ nhàng", "Khôi phục cài đặt thông báo nhẹ nhàng.", "settings put system gentle_notification_enabled 1", "settings put system hw_notification_gentle_switch 1"),
        action("lock_screen_notifications", "Âm thanh & thông báo", "Thông báo màn hình khóa", "Hiện thông báo theo cài đặt mặc định.", "settings put system lock_screen_notification_style 1", "settings put secure lock_screen_show_notifications 1", "settings put secure lock_screen_allow_private_notifications 1", "settings put system lock_screen_show_notifications 1"),
        action("heads_up_notifications", "Âm thanh & thông báo", "Thông báo nổi", "Khôi phục biểu ngữ thông báo.", "settings put global heads_up_notifications_enabled 1", "settings put system notification_banner_enabled 1"),
        action("notification_cooldown", "Âm thanh & thông báo", "Giảm lặp thông báo", "Bật lại giới hạn thông báo lặp mặc định.", "settings put system notification_cooldown_enabled 1", "settings put secure notification_cooldown_enabled 1"),

        // Privacy and location (9)
        action("private_dns", "Riêng tư & vị trí", "DNS riêng", "Xóa máy chủ DNS tùy chỉnh và dùng DNS tự động.", "settings put global private_dns_mode opportunistic", "settings delete global private_dns_specifier"),
        action("ad_privacy", "Riêng tư & vị trí", "Quyền riêng tư quảng cáo", "Khôi phục trạng thái nhận dạng quảng cáo mặc định.", "settings put secure advertising_id_opt_out 0", "settings delete global personalized_ad_enabled", "settings delete secure limit_ad_tracking"),
        action("location_mode", "Riêng tư & vị trí", "Chế độ vị trí", "Khôi phục vị trí GPS và mạng.", "settings put secure location_mode 3", "settings put secure location_providers_allowed +gps,+network"),
        action("location_nlp", "Riêng tư & vị trí", "Nhà cung cấp vị trí mạng", "Đặt lại dịch vụ vị trí mạng của Google nếu có.", "settings put secure location_nlp_pkg com.google.android.gms", "settings put global location_nlp_pkg com.google.android.gms", "settings put secure google_location_accuracy_enabled 1"),
        action("gps_assist", "Riêng tư & vị trí", "Hỗ trợ GPS", "Khôi phục máy chủ hỗ trợ GPS mặc định.", "settings put global supl_host supl.google.com", "settings put global supl_port 7275", "settings put global assisted_gps_enabled 1"),
        action("location_throttle", "Riêng tư & vị trí", "Giới hạn vị trí nền", "Xóa các giới hạn vị trí nền do app đặt.", "settings delete global location_gnss_raw_meas_full_tracking", "settings delete global location_background_throttle_interval_ms", "settings delete global location_background_throttle_proximity_alert_interval_ms"),
        action("wifi_location_scan", "Riêng tư & vị trí", "Quét Wi-Fi/BLE định vị", "Khôi phục lựa chọn quét nền của hệ điều hành.", "settings put global wifi_scan_always_enabled 1", "settings put global ble_scan_always_enabled 1"),
        action("location_accuracy", "Riêng tư & vị trí", "Độ chính xác vị trí", "Bật lại độ chính xác vị trí của dịch vụ tương thích.", "settings put secure google_location_accuracy_enabled 1", "settings put secure google_location_accuracy 1"),
        action("location_nlp_mode", "Riêng tư & vị trí", "Chế độ NLP", "Đặt chế độ nhà cung cấp vị trí mạng về mặc định.", "settings put secure nlp_mode 1"),

        // Honor services (9)
        action("honor_search", "Dịch vụ Honor", "Honor Search", "Hiện lại tìm kiếm vuốt của Honor.", "settings put secure honor_search_disabled 0", "settings put secure hiboard_search_switch 1", "settings put system hiboard_search_switch 1"),
        action("hiboard", "Dịch vụ Honor", "HiBoard", "Bật lại bảng tin Honor.", "settings put secure hiboard_switch 1", "settings put system hiboard_switch 1"),
        action("app_market_update", "Dịch vụ Honor", "Tự cập nhật App Market", "Khôi phục tự cập nhật ứng dụng theo cài đặt Honor.", "settings put global auto_update_app 1", "settings put secure auto_update_app 1"),
        action("app_market_enable", "Dịch vụ Honor", "Kích hoạt App Market", "Bật lại cửa hàng ứng dụng Honor nếu đang bị tắt.", "pm enable --user 0 com.hihonor.appmarket >/dev/null 2>&1 || true"),
        action("magazine_download", "Dịch vụ Honor", "Tạp chí màn hình khóa", "Khôi phục tải tạp chí qua Wi-Fi.", "settings put system auto_download_magazine_wifi 1"),
        action("honor_yoyo_wake", "Dịch vụ Honor", "YOYO trên thanh điều hướng", "Bật lại các cờ gọi trợ lý Honor.", "settings put secure navigation_bar_wakeup_yoyo 1", "settings put secure yoyo_navigation_bar_wakeup 1", "settings put system navigation_bar_wakeup_yoyo 1"),
        action("honor_auto_update", "Dịch vụ Honor", "Cập nhật tự động Honor", "Khôi phục cờ cập nhật App Market.", "settings put global auto_update_app 1"),
        action("system_update_flags", "Dịch vụ Honor", "Cờ cập nhật hệ thống", "Bỏ các cờ chặn cập nhật OTA.", "settings put global ota_disable_automatic_update 0", "settings put system ota_disable_automatic_update 0", "settings put secure ota_disable_automatic_update 0", "settings put global system_update_disabled 0"),
        action("system_update_overrides", "Dịch vụ Honor", "Ghi đè cập nhật OTA", "Xóa các khóa chặn cập nhật OTA còn sót.", "settings delete global ota_disable_automatic_update", "settings delete system ota_disable_automatic_update", "settings delete secure ota_disable_automatic_update"),

        // Developer and Android system settings (9)
        action("developer_global", "Android & nhà phát triển", "Menu nhà phát triển (Global)", "Hiện lại trang Tùy chọn nhà phát triển.", "settings put global development_settings_enabled 1"),
        action("developer_secure", "Android & nhà phát triển", "Menu nhà phát triển (Secure)", "Khôi phục cờ hiển thị của ROM.", "settings put secure development_settings_enabled 1"),
        action("dev_stealth", "Android & nhà phát triển", "Ẩn nhà phát triển MagicTune", "Tắt chế độ ẩn menu do MagicTune quản lý.", "settings put global magictune_dev_stealth 0"),
        action("phantom_monitor", "Android & nhà phát triển", "Theo dõi tiến trình nền", "Bật lại giám sát tiến trình ảo của Android.", "settings put global settings_enable_monitor_phantom_procs true"),
        action("adb_charging", "Android & nhà phát triển", "ADB chỉ khi sạc", "Trả cờ ADB khi sạc về mặc định.", "settings delete global adb_charging_only", "settings delete secure allow_charging_adb", "settings delete secure adb_TakeEffectInChargingOnly"),
        action("adb_connection_time", "Android & nhà phát triển", "Thời hạn kết nối ADB", "Xóa thời hạn ADB do app thiết lập.", "settings delete global adb_allowed_connection_time"),
        action("display_capture", "Android & nhà phát triển", "Chặn chụp màn hình", "Tắt cờ chặn chụp màn hình do app đặt.", "settings put global block_screen_capture 0"),
        action("bluetooth_audio", "Android & nhà phát triển", "Âm lượng Bluetooth hệ thống", "Đồng bộ lại âm lượng tuyệt đối Bluetooth.", "settings put global bluetooth_absolute_volume 1"),
        action("device_freezer_config", "Android & nhà phát triển", "Cấu hình freezer Android", "Khôi phục freezer tiến trình theo cấu hình mặc định.", "device_config put activity_manager_native_boot use_freezer true >/dev/null 2>&1 || true")
    )

    private fun action(id: String, section: String, title: String, description: String, vararg commands: String) =
        RevertActionDefinition("RESTORE_$id", section, title, description, commands.toList())

    fun find(id: String): RevertActionDefinition? = actions.firstOrNull { it.id == id }
}
