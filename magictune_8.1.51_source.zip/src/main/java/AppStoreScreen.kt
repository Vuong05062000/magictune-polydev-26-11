package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.auth.FirebaseAuthManager
import com.example.core.license.LicenseManager
import com.example.data.HonorAppItem
import com.example.ui.theme.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AppStoreScreen(
    onNavigateBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val proStateVersion by LicenseManager.proStateVersionFlow.collectAsState()
    val authSession by FirebaseAuthManager.authSessionFlow.collectAsState()
    val currentUser = remember(authSession) { FirebaseAuthManager.getCurrentUser() }
    val isSimulateFree = remember(proStateVersion) { LicenseManager.isAdminSimulateFreeMode(context) }
    val isAdmin = remember(proStateVersion, authSession) {
        !isSimulateFree && (authSession.isAdmin || FirebaseAuthManager.isCurrentAdmin(context, null))
    }
    val isProUser = remember(proStateVersion, authSession) {
        LicenseManager.isAppFreeMode(context) || (!isSimulateFree && (LicenseManager.isProActivated(context) || isAdmin))
    }

    // Tuyệt đối không đọc ROM JSON hay gọi AppWidgetManager Binder IPC trên Main Thread trong remember
    var cloudApps by remember { mutableStateOf<List<HonorAppItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var widgetInstalledCounts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }

    // Tìm kiếm, Bộ lọc & Phân trang
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Tất cả") }
    var selectedProFilter by remember { mutableStateOf("Tất cả") } // "Tất cả", "⚡ Bản PRO", "Miễn phí"
    var currentPage by remember { mutableIntStateOf(0) }
    val pageSize = 6

    // Dialog Thêm / Sửa App (Dành cho Admin)
    var showAppEditDialog by remember { mutableStateOf(false) }
    var appToEdit by remember { mutableStateOf<HonorAppItem?>(null) }
    var inputAppName by remember { mutableStateOf("") }
    var inputAppUrl by remember { mutableStateOf("") }
    var inputAppDesc by remember { mutableStateOf("") }
    var inputAppCategory by remember { mutableStateOf("Tiện Ích") }
    var inputAppVersion by remember { mutableStateOf("1.0") }
    var inputAppProOnly by remember { mutableStateOf(false) }

    // Dialog xác nhận xóa app
    var appToDelete by remember { mutableStateOf<HonorAppItem?>(null) }

    // Dialog Đóng góp App (Dành cho Người Dùng)
    var showContributeDialog by remember { mutableStateOf(false) }
    var contributeAppName by remember { mutableStateOf("") }
    var contributeAppUrl by remember { mutableStateOf("") }
    var contributeAppDesc by remember { mutableStateOf("") }
    var contributeAppCategory by remember { mutableStateOf("Tiện Ích") }
    var contributeAppVersion by remember { mutableStateOf("1.0") }
    var contributeAppAuthor by remember { mutableStateOf(currentUser?.displayName ?: "") }
    var isSubmittingContribute by remember { mutableStateOf(false) }

    // Danh sách ứng dụng mặc định chất lượng cao cho Honor
    val defaultPresetApps = remember {
        listOf(
            HonorAppItem(
                id = "preset_magic_live",
                name = "Google Magic Live AI",
                description = "Trợ lý trí tuệ nhân tạo chính thức từ Google, trò chuyện giọng nói tự nhiên và xử lý hình ảnh thông minh.",
                downloadUrl = "https://play.google.com/store/apps/details?id=com.google.android.apps.bard",
                category = "Trợ Lý / AI",
                version = "Mới nhất",
                author = "Google LLC",
                isProOnly = false,
                iconName = "smart_toy"
            ),
            HonorAppItem(
                id = "preset_shizuku",
                name = "Shizuku",
                description = "Công cụ cầu nối quyền hệ thống ADB không cần Root, bắt buộc phải có để tối ưu sâu và đóng băng app Honor.",
                downloadUrl = "https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api",
                category = "Tối Ưu / Mod",
                version = "v13.5",
                author = "Rikka",
                isProOnly = false,
                iconName = "security"
            ),
            HonorAppItem(
                id = "preset_gbox",
                name = "Gbox",
                description = "Giải pháp môi trường chạy Google Services hoàn hảo và ổn định nhất cho các máy Honor xách tay nội địa.",
                downloadUrl = "https://gboxlab.com/",
                category = "Google Services",
                version = "Mới nhất",
                author = "Gbox Lab",
                isProOnly = false,
                iconName = "cloud"
            ),
            HonorAppItem(
                id = "preset_microg",
                name = "MicroG Companion",
                description = "Dịch vụ Google Play mã nguồn mở gọn nhẹ, giúp nhận thông báo tức thì và đăng nhập tài khoản Google.",
                downloadUrl = "https://microg.org/download.html",
                category = "Google Services",
                version = "v0.3.x",
                author = "MicroG Project",
                isProOnly = false,
                iconName = "cloud"
            ),
            HonorAppItem(
                id = "preset_google_search",
                name = "Google App & Circle Search",
                description = "Ứng dụng tìm kiếm Google hỗ trợ khoanh tròn tìm kiếm (Circle to Search) trên thanh điều hướng Honor.",
                downloadUrl = "https://play.google.com/store/apps/details?id=com.google.android.googlequicksearchbox",
                category = "Tiện Ích",
                version = "Official",
                author = "Google LLC",
                isProOnly = false,
                iconName = "search"
            ),
            HonorAppItem(
                id = "preset_theme_studio",
                name = "Bộ Font & Theme Honor Việt Hóa",
                description = "Bộ sưu tập font chữ tiếng Việt không lỗi font và giao diện MagicOS tối ưu cho màn hình OLED.",
                downloadUrl = "https://drive.google.com/drive/folders/1WLsS-OlxvKFUWzMPxnkrNn8kmlVIY6-k?usp=sharing",
                category = "Giao Diện",
                version = "2026",
                author = "Admin VXM",
                isProOnly = false,
                iconName = "style"
            )
        )
    }

    val lifecycleOwner = LocalLifecycleOwner.current

    LaunchedEffect(Unit) {
        val (romCached, counts) = withContext(Dispatchers.IO) {
            val cached = try { loadHonorAppsFromRomSnapshot(context) } catch (_: Throwable) { emptyList() }
            val wCounts = try { com.example.core.widget.HomeWidgetPinHelper.countInstalledWidgets(context) } catch (_: Throwable) { emptyMap() }
            cached to wCounts
        }
        if (cloudApps.isEmpty() && romCached.isNotEmpty()) {
            cloudApps = romCached
        }
        widgetInstalledCounts = counts
    }

    // Cập nhật số lượng Widget đang ghim ngoài màn hình chính trên Dispatchers.IO mỗi khi quay lại Tab Kho App
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                coroutineScope.launch {
                    val wCounts = withContext(Dispatchers.IO) {
                        try { com.example.core.widget.HomeWidgetPinHelper.countInstalledWidgets(context) } catch (_: Throwable) { emptyMap() }
                    }
                    if (!listState.isScrollInProgress) {
                        widgetInstalledCounts = wCounts
                    }
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Lắng nghe Firestore theo vòng đời STARTED (tự ngắt khi ẩn app để giảm pin/nhiệt; vẫn chờ dừng cuộn 120fps)
    LaunchedEffect(lifecycleOwner) {
        try {
            lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                FirebaseAuthManager.observeHonorApps(context).collect { list ->
                    cloudApps = list
                    isLoading = false
                    if (list.isNotEmpty()) {
                        withContext(Dispatchers.IO) {
                            try { saveHonorAppsToRomSnapshot(context, list) } catch (_: Throwable) {}
                        }
                    }
                }
            }
        } catch (_: Exception) {
            isLoading = false
        }
    }

    // Hợp nhất & lọc danh sách app trên Dispatchers.Default để không bao giờ chặn Main UI Thread
    var allStoreApps by remember { mutableStateOf(defaultPresetApps) }
    LaunchedEffect(cloudApps, isAdmin, currentUser?.email) {
        val currentEmail = currentUser?.email
        val computed = withContext(Dispatchers.Default) {
            val visibleCloudApps = if (isAdmin) {
                cloudApps
            } else {
                cloudApps.filter { it.status == "APPROVED" || (it.contributorEmail.isNotBlank() && it.contributorEmail == currentEmail) }
            }
            val merged = if (visibleCloudApps.isEmpty() && cloudApps.isEmpty()) {
                defaultPresetApps
            } else {
                val existingIds = visibleCloudApps.map { it.id }.toSet()
                val existingNames = visibleCloudApps.map { it.name.trim().lowercase() }.toSet()
                val missingPresets = defaultPresetApps.filter {
                    it.id !in existingIds && it.name.trim().lowercase() !in existingNames
                }
                visibleCloudApps + missingPresets
            }
            merged.distinctBy { it.id.ifBlank { it.name.trim().lowercase() } }
        }
        allStoreApps = computed
    }

    var filteredApps by remember { mutableStateOf(defaultPresetApps) }
    LaunchedEffect(allStoreApps, searchQuery, selectedCategory, selectedProFilter) {
        val computedFiltered = withContext(Dispatchers.Default) {
            allStoreApps.filter { app ->
                val matchCategory = selectedCategory == "Tất cả" || app.category.equals(selectedCategory, ignoreCase = true)
                val matchPro = when (selectedProFilter) {
                    "⚡ Bản PRO" -> app.isProOnly
                    "Miễn phí" -> !app.isProOnly
                    else -> true
                }
                val matchQuery = searchQuery.isBlank() ||
                    app.name.contains(searchQuery, ignoreCase = true) ||
                    app.description.contains(searchQuery, ignoreCase = true) ||
                    app.category.contains(searchQuery, ignoreCase = true) ||
                    app.author.contains(searchQuery, ignoreCase = true)

                matchCategory && matchPro && matchQuery
            }
        }
        filteredApps = computedFiltered
    }

    val totalPages = ((filteredApps.size - 1) / pageSize) + 1
    val safeCurrentPage = currentPage.coerceIn(0, (totalPages - 1).coerceAtLeast(0))
    val paginatedApps = remember(filteredApps, safeCurrentPage) {
        val start = safeCurrentPage * pageSize
        val end = (start + pageSize).coerceAtMost(filteredApps.size)
        if (start in 0 until filteredApps.size) filteredApps.subList(start, end) else emptyList()
    }

    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .background(MagicDarkBackground),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "store_header", contentType = "header") {
        // Top Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan.copy(alpha = 0.22f))
                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Ô #56",
                                color = MagicCyanLight,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = null,
                            tint = MagicCyan,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    if (isAdmin) {
                        Button(
                            onClick = {
                                appToEdit = null
                                inputAppName = ""
                                inputAppUrl = ""
                                inputAppDesc = ""
                                inputAppCategory = "Tiện Ích"
                                inputAppVersion = "1.0"
                                inputAppProOnly = false
                                showAppEditDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.heightIn(min = 34.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF020617))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Thêm App Mới", color = Color(0xFF020617), fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    } else if (currentUser != null) {
                        // Nút đóng góp cho người dùng
                        Button(
                            onClick = {
                                contributeAppName = ""
                                contributeAppUrl = ""
                                contributeAppDesc = ""
                                contributeAppCategory = "Tiện Ích"
                                contributeAppVersion = "1.0"
                                contributeAppAuthor = currentUser.displayName ?: ""
                                showContributeDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.heightIn(min = 34.dp)
                        ) {
                            Icon(imageVector = Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF020617))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Đóng Góp App", color = Color(0xFF020617), fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }

                Text(
                    text = "KHO ỨNG DỤNG HONOR",
                    color = Color.White,
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Khám phá và cài đặt các ứng dụng, công cụ mod và tiện ích tối ưu tốt nhất dành riêng cho điện thoại Honor MagicOS.",
                    color = TextSecondary,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
            }
        }
        }

        item(key = "store_home_widgets_hub", contentType = "widgets_hub") {
            StoreHomeWidgetsQuickPinCard(
                installedCounts = widgetInstalledCounts,
                onPinWidget = { descriptor ->
                    com.example.core.widget.HomeWidgetPinHelper.requestPinWidget(context, descriptor)
                    widgetInstalledCounts = com.example.core.widget.HomeWidgetPinHelper.countInstalledWidgets(context)
                },
                onRefreshCounts = {
                    widgetInstalledCounts = com.example.core.widget.HomeWidgetPinHelper.countInstalledWidgets(context)
                }
            )
        }

        item(key = "store_search", contentType = "search") {
        // Thanh Tìm Kiếm
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it; currentPage = 0 },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("app_store_search_input"),
            label = { Text("Tìm tên app, tính năng, tiện ích...", fontSize = 11.5.sp) },
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(18.dp))
            },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = { searchQuery = ""; currentPage = 0 }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }
        )
        }

        item(key = "store_filters", contentType = "filters") {
        // Bộ lọc Danh mục
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val categories = listOf("Tất cả", "Trợ Lý / AI", "Tiện Ích", "Tối Ưu / Mod", "Google Services", "Giao Diện")
                categories.forEach { cat ->
                    val isSelected = selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat; currentPage = 0 },
                        label = { Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MagicCyan.copy(alpha = 0.25f),
                            selectedLabelColor = MagicCyanLight,
                            containerColor = MagicSurfaceDark,
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) MagicCyan else MagicBorder
                        )
                    )
                }
            }

            // Bộ lọc Pro / Miễn Phí
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val proFilters = listOf("Tất cả", "⚡ Bản PRO", "Miễn phí")
                proFilters.forEach { filter ->
                    val isSelected = selectedProFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedProFilter = filter; currentPage = 0 },
                        label = { Text(filter, fontSize = 10.5.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = if (filter == "⚡ Bản PRO") MagicEmerald.copy(alpha = 0.25f) else MagicPurple.copy(alpha = 0.25f),
                            selectedLabelColor = if (filter == "⚡ Bản PRO") MagicEmeraldLight else MagicPurpleLight,
                            containerColor = MagicSurfaceDark,
                            labelColor = TextMuted
                        )
                    )
                }
            }
        }
        }

        item(key = "store_section_title", contentType = "section_title") {
        // Ô #57: Danh sách App trong Kho Ứng Dụng Honor
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MagicCyan.copy(alpha = 0.22f))
                        .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Ô #57",
                        color = MagicCyanLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
            Text(
                text = "DANH SÁCH ỨNG DỤNG TRONG KHO (${filteredApps.size} APP)",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.fillMaxWidth()
            )
        }
        }

        // Danh sách App
        if (paginatedApps.isEmpty()) {
            item(key = "store_empty", contentType = "empty") {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MagicSurfaceDark),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.SearchOff, contentDescription = null, tint = TextMuted, modifier = Modifier.size(32.dp))
                    Text(
                        text = "Không tìm thấy ứng dụng nào phù hợp.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            }
        } else {
            itemsIndexed(
                items = paginatedApps,
                key = { _, app -> "store_${app.id.ifBlank { app.name }}" },
                contentType = { _, _ -> "store_app" }
            ) { _, app ->
                    val isAppProRestricted = app.isProOnly

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                        border = BorderStroke(
                            1.dp,
                            if (isAppProRestricted) MagicEmerald.copy(alpha = 0.6f) else MagicBorder
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Tiêu đề & Nhãn tách hàng riêng
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val iconVector = when (app.iconName) {
                                        "mic" -> Icons.Default.Mic
                                        "smart_toy" -> Icons.Default.SmartToy
                                        "security" -> Icons.Default.Security
                                        "cloud" -> Icons.Default.CloudDownload
                                        "style" -> Icons.Default.Palette
                                        else -> Icons.Default.Apps
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isAppProRestricted) MagicEmerald.copy(alpha = 0.2f) else MagicCyan.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = iconVector,
                                            contentDescription = null,
                                            tint = if (isAppProRestricted) MagicEmeraldLight else MagicCyanLight,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(text = app.category, color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text(text = "•", color = TextMuted, fontSize = 10.sp)
                                        Text(text = app.version, color = TextSecondary, fontSize = 10.sp)
                                    }
                                }

                                if (isAppProRestricted) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MagicEmerald.copy(alpha = 0.2f))
                                            .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "⚡ ĐỘC QUYỀN PRO",
                                            color = MagicEmeraldLight,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                } else if (app.status == "PENDING") {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MagicAmber.copy(alpha = 0.2f))
                                            .border(1.dp, MagicAmber.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "⌛ CHỜ DUYỆT",
                                            color = MagicAmber,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                } else if (app.status == "REJECTED") {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MagicRose.copy(alpha = 0.2f))
                                            .border(1.dp, MagicRose.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "❌ BỊ TỪ CHỐI",
                                            color = MagicRoseLight,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }
                            }

                            Text(
                                text = app.name,
                                color = Color.White,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Mô tả app
                            Text(
                                text = app.description,
                                color = TextSecondary,
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp
                            )

                            // Hàng nút bấm hành động
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Tác giả
                                Text(
                                    text = "Đăng bởi: ${app.author}",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    // Nút Copy Link
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                            if (clipboard != null) {
                                                val clip = ClipData.newPlainText("App Link", app.downloadUrl)
                                                clipboard.setPrimaryClip(clip)
                                                Toast.makeText(context, "Đã sao chép liên kết tải ${app.name}!", Toast.LENGTH_SHORT).show()
                                            } else {
                                                Toast.makeText(context, "Không truy cập được Clipboard", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy Link", tint = TextSecondary, modifier = Modifier.size(15.dp))
                                    }

                                    // Nếu là Admin: nút Duyệt, Từ chối, Sửa & Xóa
                                    if (isAdmin) {
                                        if (app.status == "PENDING") {
                                            IconButton(
                                                onClick = {
                                                    coroutineScope.launch {
                                                        try {
                                                            FirebaseAuthManager.updateHonorAppStatus(app.id, "APPROVED")
                                                            Toast.makeText(context, "✅ Đã duyệt ứng dụng: ${app.name}", Toast.LENGTH_SHORT).show()
                                                        } catch (e: Exception) {
                                                            Toast.makeText(context, "Lỗi duyệt: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Duyệt", tint = MagicEmeraldLight, modifier = Modifier.size(18.dp))
                                            }

                                            IconButton(
                                                onClick = {
                                                    coroutineScope.launch {
                                                        try {
                                                            FirebaseAuthManager.updateHonorAppStatus(app.id, "REJECTED")
                                                            Toast.makeText(context, "❌ Đã từ chối ứng dụng: ${app.name}", Toast.LENGTH_SHORT).show()
                                                        } catch (e: Exception) {
                                                            Toast.makeText(context, "Lỗi từ chối: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(imageVector = Icons.Default.Cancel, contentDescription = "Từ chối", tint = MagicRoseLight, modifier = Modifier.size(18.dp))
                                            }
                                        }

                                        IconButton(
                                            onClick = {
                                                appToEdit = app
                                                inputAppName = app.name
                                                inputAppUrl = app.downloadUrl
                                                inputAppDesc = app.description
                                                inputAppCategory = app.category
                                                inputAppVersion = app.version
                                                inputAppProOnly = app.isProOnly
                                                showAppEditDialog = true
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Sửa", tint = MagicCyan, modifier = Modifier.size(15.dp))
                                        }

                                        IconButton(
                                            onClick = { appToDelete = app },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Xóa", tint = MagicRoseLight, modifier = Modifier.size(15.dp))
                                        }
                                    }

                                    // Nút Tải Ngay
                                    Button(
                                        onClick = {
                                            if (isAppProRestricted && !isProUser) {
                                                Toast.makeText(
                                                    context,
                                                    "🔒 TÍNH NĂNG ĐỘC QUYỀN BẢN PRO!\nChỉ các tài khoản PRO mới có quyền tải ${app.name}. Vui lòng nâng cấp bản PRO để tiếp tục.",
                                                    Toast.LENGTH_LONG
                                                ).show()
                                            } else {
                                                try {
                                                    val uri = Uri.parse(app.downloadUrl)
                                                    val isPlayLink = app.downloadUrl.contains("play.google.com") || app.downloadUrl.startsWith("market://")
                                                    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                                                        if (isPlayLink) {
                                                            setPackage("com.android.vending")
                                                        }
                                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                    }
                                                    try {
                                                        context.startActivity(intent)
                                                    } catch (_: Exception) {
                                                        val fallbackIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                                                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                        }
                                                        context.startActivity(fallbackIntent)
                                                    }
                                                    Toast.makeText(context, "🚀 Đang mở tải ${app.name}...", Toast.LENGTH_SHORT).show()
                                                } catch (e: Exception) {
                                                    Toast.makeText(context, "Không thể mở liên kết: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isAppProRestricted && !isProUser) MagicSurfaceCard else MagicCyan,
                                            contentColor = if (isAppProRestricted && !isProUser) MagicAmber else Color(0xFF020617)
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.heightIn(min = 34.dp),
                                        border = if (isAppProRestricted && !isProUser) BorderStroke(1.dp, MagicAmber.copy(alpha = 0.6f)) else null
                                    ) {
                                        Icon(
                                            imageVector = if (isAppProRestricted && !isProUser) Icons.Default.Lock else Icons.Default.Download,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isAppProRestricted && !isProUser) "Cần Bản Pro" else "Tải Về",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 11.5.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
            }

            // Thanh Phân Trang
            if (totalPages > 1) {
                item(key = "store_pagination", contentType = "pagination") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { if (safeCurrentPage > 0) currentPage = safeCurrentPage - 1 },
                        enabled = safeCurrentPage > 0,
                        modifier = Modifier.heightIn(min = 36.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Trang trước", fontSize = 11.sp)
                    }

                    Text(
                        text = "Trang ${safeCurrentPage + 1} / $totalPages",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedButton(
                        onClick = { if (safeCurrentPage < totalPages - 1) currentPage = safeCurrentPage + 1 },
                        enabled = safeCurrentPage < totalPages - 1,
                        modifier = Modifier.heightIn(min = 36.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Trang sau", fontSize = 11.sp)
                    }
                }
                }
            }
        }
    }

    // Dialog Thêm / Sửa App (Admin Only)
    if (showAppEditDialog) {
        val isEditing = appToEdit != null
        AlertDialog(
            onDismissRequest = { showAppEditDialog = false },
            containerColor = MagicSurfaceDark,
            title = {
                Text(
                    text = if (isEditing) "Sửa Ứng Dụng Trong Kho" else "Thêm Ứng Dụng Mới Vào Kho",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            },
            text = {
                ScrollableDialogColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inputAppName,
                        onValueChange = { inputAppName = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Tên ứng dụng (Bắt buộc)", fontSize = 11.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = inputAppUrl,
                        onValueChange = { inputAppUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Đường dẫn tải / URL APK (Bắt buộc)", fontSize = 11.sp) },
                        placeholder = { Text("https://...") },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = inputAppDesc,
                        onValueChange = { inputAppDesc = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Mô tả tính năng ngắn gọn", fontSize = 11.sp) },
                        maxLines = 3,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = inputAppCategory,
                            onValueChange = { inputAppCategory = it },
                            modifier = Modifier.weight(1.2f),
                            label = { Text("Danh mục", fontSize = 11.sp) },
                            placeholder = { Text("Tiện Ích") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp)
                        )

                        OutlinedTextField(
                            value = inputAppVersion,
                            onValueChange = { inputAppVersion = it },
                            modifier = Modifier.weight(0.8f),
                            label = { Text("Phiên bản", fontSize = 11.sp) },
                            placeholder = { Text("v1.0") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    // Tùy chọn chỉ dành cho bản Pro
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicSurfaceCard)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Chỉ mở cho tài khoản PRO tải",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Switch(
                            checked = inputAppProOnly,
                            onCheckedChange = { inputAppProOnly = it }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inputAppName.isBlank() || inputAppUrl.isBlank()) {
                            Toast.makeText(context, "Vui lòng nhập Tên và Đường dẫn tải!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        coroutineScope.launch {
                            try {
                                val newApp = HonorAppItem(
                                    id = appToEdit?.id ?: "",
                                    name = inputAppName.trim(),
                                    description = inputAppDesc.trim(),
                                    downloadUrl = inputAppUrl.trim(),
                                    category = inputAppCategory.trim().ifBlank { "Tiện Ích" },
                                    version = inputAppVersion.trim().ifBlank { "v1.0" },
                                    author = currentUser?.displayName ?: "Admin VXM",
                                    isProOnly = inputAppProOnly,
                                    createdAt = appToEdit?.createdAt ?: System.currentTimeMillis()
                                )
                                FirebaseAuthManager.saveHonorApp(newApp)
                                Toast.makeText(context, "✅ Đã lưu ứng dụng vào Kho thành công!", Toast.LENGTH_SHORT).show()
                                showAppEditDialog = false
                            } catch (e: Exception) {
                                Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                ) {
                    Text("Lưu Vào Kho", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAppEditDialog = false }) {
                    Text("Hủy", color = TextSecondary, fontSize = 12.sp)
                }
            }
        )
    }

    // Dialog xác nhận xóa App (Admin Only)
    appToDelete?.let { app ->
        AlertDialog(
            onDismissRequest = { appToDelete = null },
            containerColor = MagicSurfaceDark,
            title = {
                Text("Xác nhận xóa ứng dụng", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            },
            text = {
                ScrollableDialogColumn(thumbColor = MagicRose) {
                    Text(
                        text = "Bạn có chắc chắn muốn xóa ứng dụng '${app.name}' khỏi Kho Ứng Dụng Honor không?",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            try {
                                FirebaseAuthManager.deleteHonorApp(app.id)
                                Toast.makeText(context, "Đã xóa ứng dụng khỏi Kho!", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                            } finally {
                                appToDelete = null
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose)
                ) {
                    Text("Xóa Ngay", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { appToDelete = null }) {
                    Text("Hủy", color = TextSecondary, fontSize = 12.sp)
                }
            }
        )
    }

    // Dialog Đóng góp App (Người Dùng)
    if (showContributeDialog) {
        AlertDialog(
            onDismissRequest = { if (!isSubmittingContribute) showContributeDialog = false },
            containerColor = MagicSurfaceDark,
            title = {
                Text(
                    text = "Đóng Góp Ứng Dụng",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            },
            text = {
                ScrollableDialogColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Vui lòng nhập thông tin ứng dụng bạn muốn chia sẻ. Sau khi gửi, Admin sẽ kiểm duyệt trước khi hiển thị công khai.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    OutlinedTextField(
                        value = contributeAppName,
                        onValueChange = { contributeAppName = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Tên ứng dụng", fontSize = 11.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = contributeAppUrl,
                        onValueChange = { contributeAppUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Link tải APK / Play Store", fontSize = 11.sp) },
                        placeholder = { Text("https://...") },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = contributeAppDesc,
                        onValueChange = { contributeAppDesc = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Mô tả ngắn gọn", fontSize = 11.sp) },
                        maxLines = 3,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = contributeAppAuthor,
                        onValueChange = { contributeAppAuthor = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Tác giả / Người đóng góp", fontSize = 11.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                    
                    if (isSubmittingContribute) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = MagicCyan)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (contributeAppName.isBlank() || contributeAppUrl.isBlank()) {
                            Toast.makeText(context, "Vui lòng nhập Tên và Link tải!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        isSubmittingContribute = true
                        coroutineScope.launch {
                            try {
                                val newApp = HonorAppItem(
                                    name = contributeAppName.trim(),
                                    description = contributeAppDesc.trim(),
                                    downloadUrl = contributeAppUrl.trim(),
                                    category = contributeAppCategory,
                                    version = contributeAppVersion,
                                    author = contributeAppAuthor.trim().ifBlank { currentUser?.displayName ?: "Người dùng ẩn danh" },
                                    status = "PENDING",
                                    contributorEmail = currentUser?.email ?: ""
                                )
                                FirebaseAuthManager.contributeHonorApp(newApp)
                                Toast.makeText(context, "🚀 Gửi đóng góp thành công! Đang chờ Admin duyệt.", Toast.LENGTH_LONG).show()
                                showContributeDialog = false
                            } catch (e: Exception) {
                                Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                            } finally {
                                isSubmittingContribute = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                    enabled = !isSubmittingContribute
                ) {
                    Text("Gửi Đóng Góp", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showContributeDialog = false }, enabled = !isSubmittingContribute) {
                    Text("Hủy", color = TextSecondary, fontSize = 12.sp)
                }
            }
        )
    }
}

private const val ROM_STORE_APPS_SNAPSHOT = "honor_apps_store_v1.json"

private fun loadHonorAppsFromRomSnapshot(context: Context): List<HonorAppItem> {
    return try {
        val raw = com.example.core.perf.DeviceMemoryStorageOptimizer.readFastSnapshotJson(
            context,
            ROM_STORE_APPS_SNAPSHOT
        ) ?: return emptyList()
        val arr = org.json.JSONArray(raw)
        val out = ArrayList<HonorAppItem>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(
                HonorAppItem(
                    id = o.optString("id"),
                    name = o.optString("name"),
                    description = o.optString("desc"),
                    downloadUrl = o.optString("url"),
                    category = o.optString("cat", "Tiện Ích"),
                    version = o.optString("ver", "1.0"),
                    author = o.optString("author", "Admin VXM"),
                    isProOnly = o.optBoolean("pro", false),
                    iconName = o.optString("icon", "apps"),
                    status = o.optString("status", "APPROVED"),
                    contributorEmail = o.optString("email", ""),
                    createdAt = o.optLong("ts", 0L)
                )
            )
        }
        out
    } catch (_: Throwable) {
        emptyList()
    }
}

private fun saveHonorAppsToRomSnapshot(context: Context, list: List<HonorAppItem>) {
    try {
        val arr = org.json.JSONArray()
        for (item in list.take(120)) {
            arr.put(
                org.json.JSONObject().apply {
                    put("id", item.id)
                    put("name", item.name)
                    put("desc", item.description)
                    put("url", item.downloadUrl)
                    put("cat", item.category)
                    put("ver", item.version)
                    put("author", item.author)
                    put("pro", item.isProOnly)
                    put("icon", item.iconName)
                    put("status", item.status)
                    put("email", item.contributorEmail)
                    put("ts", item.createdAt)
                }
            )
        }
        com.example.core.perf.DeviceMemoryStorageOptimizer.writeFastSnapshotJson(
            context,
            ROM_STORE_APPS_SNAPSHOT,
            arr.toString()
        )
    } catch (_: Throwable) {}
}

@Composable
private fun StoreHomeWidgetsQuickPinCard(
    installedCounts: Map<String, Int>,
    onPinWidget: (com.example.core.widget.MagicTuneWidgetDescriptor) -> Unit,
    onRefreshCounts: () -> Unit
) {
    val widgets = remember { com.example.core.widget.HomeWidgetPinHelper.allWidgets }
    var isExpanded by remember { mutableStateOf(true) }
    var showWeatherWidgetCustomizerDialog by remember { mutableStateOf(false) }
    val totalPinned = installedCounts.values.sum()

    if (showWeatherWidgetCustomizerDialog) {
        WeatherWidgetCustomizeDialog(
            onDismiss = { showWeatherWidgetCustomizerDialog = false }
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("store_widget_quick_pin_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1324)),
        border = BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.55f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(MagicEmerald.copy(alpha = 0.18f))
                            .border(1.dp, MagicEmerald.copy(alpha = 0.55f), RoundedCornerShape(9.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Thêm Widget MagicTune",
                            tint = MagicEmeraldLight,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MagicEmerald.copy(alpha = 0.22f))
                                    .border(0.8.dp, MagicEmerald.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "Ô #58",
                                    color = MagicEmeraldLight,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Text(
                                text = "KHO 7 WIDGET MÀN HÌNH CHÍNH",
                                color = Color.White,
                                fontSize = 11.8.sp,
                                fontWeight = FontWeight.Black,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(MagicEmerald.copy(alpha = 0.22f))
                                    .border(0.8.dp, MagicEmerald.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "FREE",
                                    color = MagicEmeraldLight,
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                        Text(
                            text = if (totalPinned > 0) "Đang ghim $totalPinned Widget • Đủ màu sắc • Chạm 1 lần để thêm"
                            else "7 Widget miễn phí • Đủ màu sắc (có Pin 2×2 đơn giản)",
                            color = if (totalPinned > 0) MagicEmeraldLight else TextSecondary,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onRefreshCounts,
                        modifier = Modifier.defaultMinSize(minWidth = 40.dp, minHeight = 40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Làm mới trạng thái Widget",
                            tint = MagicCyanLight,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Thu gọn danh sách Widget" else "Mở rộng danh sách Widget",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    widgets.forEachIndexed { widgetIdx, w ->
                        val accent = Color(w.accentHex)
                        val count = installedCounts[w.id] ?: 0
                        val isWeatherClockWidget = w.id == "widget_weather_calendar"
                        val iconVec = when (w.id) {
                            "widget_battery", "widget_battery_simple_2x2" -> Icons.Default.Star
                            "widget_memory" -> Icons.Default.Settings
                            "widget_weather_calendar" -> Icons.Default.Star
                            "widget_perpetual_calendar" -> Icons.Default.DateRange
                            "widget_app_search" -> Icons.Default.Search
                            else -> Icons.Default.Share
                        }
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(11.dp))
                                .background(MagicSurfaceDark)
                                .border(
                                    0.9.dp,
                                    if (count > 0) MagicEmerald.copy(alpha = 0.55f) else accent.copy(alpha = 0.4f),
                                    RoundedCornerShape(11.dp)
                                )
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(9.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(accent.copy(alpha = 0.16f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = iconVec,
                                        contentDescription = null,
                                        tint = accent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Text(
                                            text = "${widgetIdx + 1}. ${w.title}",
                                            color = Color.White,
                                            fontSize = 11.6.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(accent.copy(alpha = 0.2f))
                                                .padding(horizontal = 5.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = w.sizeBadge,
                                                color = accent,
                                                fontSize = 8.5.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MagicEmerald.copy(alpha = 0.18f))
                                                .padding(horizontal = 5.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = "FREE",
                                                color = MagicEmeraldLight,
                                                fontSize = 8.2.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                        if (count > 0) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(MagicEmerald.copy(alpha = 0.24f))
                                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = "✓ $count",
                                                    color = MagicEmeraldLight,
                                                    fontSize = 8.5.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = w.subtitle,
                                        color = TextSecondary,
                                        fontSize = 9.8.sp,
                                        lineHeight = 13.2.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Button(
                                    onClick = { onPinWidget(w) },
                                    modifier = Modifier
                                        .defaultMinSize(minWidth = 76.dp, minHeight = 46.dp)
                                        .testTag("pin_${w.id}_button"),
                                    shape = RoundedCornerShape(9.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = accent,
                                        contentColor = Color(0xFF020617)
                                    )
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Thêm ${w.title} ra Màn hình chính",
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (count > 0) "Thêm +" else "Thêm MH",
                                        fontSize = 10.2.sp,
                                        fontWeight = FontWeight.Black,
                                        maxLines = 1
                                    )
                                }
                            }

                            if (isWeatherClockWidget) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MagicCyan.copy(alpha = 0.12f))
                                        .border(0.8.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                                        .clickable { showWeatherWidgetCustomizerDialog = true }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                        .testTag("open_weather_widget_customizer_from_store"),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "🎛️ Ẩn/hiện mục & cỡ chữ Widget Thời Tiết",
                                        color = MagicCyanLight,
                                        fontSize = 9.6.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "Tuỳ chỉnh ➔",
                                        color = MagicAmberLight,
                                        fontSize = 9.6.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


