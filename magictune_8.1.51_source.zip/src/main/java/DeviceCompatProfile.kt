package com.example.core.compat

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.view.WindowManager

/**
 * Hồ sơ tương thích đa thế hệ thiết bị (Android 6.0 API 23 -> Android 17 API 36/37+).
 * Tự nhận diện máy cấu hình yếu / đời cũ và trạng thái nhiệt độ / tiết kiệm pin để giảm tải RAM/GPU/NPU.
 */
object DeviceCompatProfile {

    @Volatile
    private var cachedIsLowEnd: Boolean? = null

    fun isLowEndOrLegacyDevice(context: Context): Boolean {
        cachedIsLowEnd?.let { return it }
        val appCtx = context.applicationContext ?: context
        val detected = try {
            val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am?.getMemoryInfo(memInfo)
            val totalRamMb = if (memInfo.totalMem > 0L) memInfo.totalMem / (1024L * 1024L) else 4096L
            val isLowRamFlag = am?.isLowRamDevice == true
            val isLegacyOs = Build.VERSION.SDK_INT < Build.VERSION_CODES.O
            val fewCores = Runtime.getRuntime().availableProcessors() <= 4
            isLowRamFlag || isLegacyOs || totalRamMb <= 3200L || fewCores
        } catch (_: Throwable) {
            Build.VERSION.SDK_INT < Build.VERSION_CODES.O
        }
        cachedIsLowEnd = detected
        return detected
    }

    fun isDeviceWarmOrHot(context: Context): Boolean {
        if (com.example.core.perf.CpuHeatGuard.isHot()) return true
        return try {
            val pm = context.applicationContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
            pm?.isPowerSaveMode == true
        } catch (_: Exception) {
            false
        }
    }

    fun recommendedOcrMaxSidePx(context: Context): Int {
        return if (isLowEndOrLegacyDevice(context) || isDeviceWarmOrHot(context)) 768 else 900
    }

    fun recommendedProjectionScale(context: Context): Float {
        // Screen capture is used for OCR, so cap its pixel workload before allocating bitmaps.
        return if (isLowEndOrLegacyDevice(context) || isDeviceWarmOrHot(context)) 0.60f else 0.75f
    }

    fun recommendedContinuousProjectionIntervalMs(context: Context): Long {
        // Keep the capture pipeline near 1 fps during continuous scroll instead of
        // repeatedly converting full frames while the user is moving the page.
        return if (isLowEndOrLegacyDevice(context) || isDeviceWarmOrHot(context)) 1_200L else 800L
    }

    fun recommendedScrollScanDebounceMs(context: Context): Long {
        return when {
            isDeviceWarmOrHot(context) -> 1_200L
            isLowEndOrLegacyDevice(context) -> 900L
            else -> 650L
        }
    }

    fun recommendedLiveTranslateConcurrency(context: Context): Int {
        return if (isLowEndOrLegacyDevice(context) || isDeviceWarmOrHot(context)) 1 else 2
    }

    fun recommendedWaveFrameDelayMs(context: Context): Long {
        // The waveform is decorative; 4–5 fps remains readable while cutting redraw work.
        return if (isLowEndOrLegacyDevice(context) || isDeviceWarmOrHot(context)) 250L else 200L
    }

    fun overlayWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }
}
