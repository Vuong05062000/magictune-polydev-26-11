package com.example.core.receiver

import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.core.service.MagicTuneKeepAliveService
import com.example.core.widget.MagicTuneAppSearchWidgetProvider
import com.example.core.widget.MagicTunePrinterWidgetProvider
import com.example.core.widget.MagicTuneBatteryWidgetProvider
import com.example.core.widget.MagicTuneMemoryWidgetProvider
import com.example.core.widget.MagicTunePerpetualCalendarWidgetProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * MagicTuneBootReceiver: Lắng nghe sự kiện khởi động thiết bị hoặc mở khóa máy.
 * Tuân thủ 100% chính sách Background / Foreground Service của Android 14, 15, 16 và Android 17 (API 37):
 * Tuyệt đối không gọi startForegroundService trực tiếp từ BroadcastReceiver chạy ngầm,
 * mà cập nhật trực tiếp hệ thống AppWidget và chỉ kích hoạt dịch vụ khi ứng dụng đang hiển thị.
 *
 * TỐI ƯU HÓA ANR CHUẨN GOOGLE (goAsync):
 * Khởi động máy là thời điểm CPU bị quá tải nặng nề nhất. Sử dụng goAsync() để trả quyền điều khiển
 * về BroadcastQueue của hệ thống trong 0ms, toàn bộ tác vụ AppWidget & KeepAlive chạy ngầm trên Dispatchers.IO.
 */
class MagicTuneBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent == null) return
        val action = intent.action ?: return
        val appCtx = context.applicationContext ?: context

        val pendingResult = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                when (action) {
                    Intent.ACTION_BOOT_COMPLETED,
                    Intent.ACTION_LOCKED_BOOT_COMPLETED,
                    "android.intent.action.QUICKBOOT_POWERON",
                    "com.htc.intent.action.QUICKBOOT_POWERON",
                    Intent.ACTION_MY_PACKAGE_REPLACED,
                    MagicTuneKeepAliveService.ACTION_REVIVE_KEEPALIVE -> {
                        try {
                            updateActiveWidgetsOnly(appCtx)
                            // Luôn duy trì mở khóa vĩnh viễn tính năng sau khi khởi động lại máy
                            if (com.example.core.permission.AppPermissionChecker.isFirstTimeWlanActivated(appCtx)) {
                                com.example.core.permission.AppPermissionChecker.markWlanActivated(appCtx)
                            }
                            // Chế độ Tàng hình On-Demand: Tự động dọn sạch Trợ năng khi máy vừa khởi động để VNeID và Ngân hàng mở được ngay
                            com.example.core.service.MagicTuneCtsAccessibilityService.enforceComponentDisabled(appCtx)
                            com.example.core.service.MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(appCtx)
                            if (MagicTuneKeepAliveService.needsToRun(appCtx)) {
                                com.example.core.service.MagicTuneKeepAliveJobService.ensureScheduled(appCtx)
                                MagicTuneKeepAliveService.syncServiceNeed(
                                    appCtx,
                                    "Đang duy trì tiện ích MagicTune"
                                )
                            } else {
                                com.example.core.service.MagicTuneKeepAliveJobService.cancelAll(appCtx)
                                MagicTuneKeepAliveService.stop(appCtx)
                            }
                            if (com.example.core.service.SystemFloatingHudOverlay.isNavBridgeConfiguredActive(appCtx)) {
                                com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(appCtx)
                                com.example.core.service.SystemFloatingHudOverlay.refreshNavPillColors(appCtx)
                            }
                        } catch (t: Throwable) {
                            Log.w("MagicTuneBootReceiver", "Bỏ qua cập nhật ngầm từ receiver: ${t.message}")
                        }
                    }
                    Intent.ACTION_USER_PRESENT -> {
                        try {
                            updateActiveWidgetsOnly(appCtx)
                            if (com.example.core.service.MagicTuneCtsAccessibilityService.isServiceEnabledInSettings(appCtx)) {
                                com.example.core.service.MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(appCtx)
                            }
                            if (MagicTuneKeepAliveService.needsToRun(appCtx)) {
                                com.example.core.service.MagicTuneKeepAliveJobService.ensureScheduled(appCtx)
                                MagicTuneKeepAliveService.syncServiceNeed(
                                    appCtx,
                                    "Đang duy trì tiện ích MagicTune"
                                )
                            }
                        } catch (t: Throwable) {
                            Log.w("MagicTuneBootReceiver", "Bỏ qua xử lý mở khóa: ${t.message}")
                        }
                    }
                }
            } finally {
                try { pendingResult.finish() } catch (_: Throwable) {}
            }
        }
    }

    private fun updateActiveWidgetsOnly(context: Context) {
        val appWidgetManager = AppWidgetManager.getInstance(context)
        val batIds = appWidgetManager.getAppWidgetIds(ComponentName(context, MagicTuneBatteryWidgetProvider::class.java))
        for (id in batIds) {
            MagicTuneBatteryWidgetProvider.updateWidget(context, appWidgetManager, id)
        }
        com.example.core.widget.MagicTuneSimpleBatteryWidgetProvider.notifyAllWidgets(context)
        val memIds = appWidgetManager.getAppWidgetIds(ComponentName(context, MagicTuneMemoryWidgetProvider::class.java))
        for (id in memIds) {
            MagicTuneMemoryWidgetProvider.updateWidget(context, appWidgetManager, id)
        }
        val searchIds = appWidgetManager.getAppWidgetIds(ComponentName(context, MagicTuneAppSearchWidgetProvider::class.java))
        for (id in searchIds) {
            MagicTuneAppSearchWidgetProvider.updateWidget(context, appWidgetManager, id)
        }
        val printerIds = appWidgetManager.getAppWidgetIds(ComponentName(context, MagicTunePrinterWidgetProvider::class.java))
        for (id in printerIds) {
            MagicTunePrinterWidgetProvider.updateWidget(context, appWidgetManager, id)
        }
        val pcIds = appWidgetManager.getAppWidgetIds(ComponentName(context, MagicTunePerpetualCalendarWidgetProvider::class.java))
        for (id in pcIds) {
            MagicTunePerpetualCalendarWidgetProvider.updateWidget(context, appWidgetManager, id)
        }
    }
}
