package com.example.core.perf

import android.content.Context

internal class CpuHeatState {
    @Volatile var hot = false
        private set
    private var systemOnly = false
    private var criticalSince: Long? = null
    private var warned = false

    data class Result(val enteredHot: Boolean, val recovered: Boolean, val warn: Boolean)

    fun update(cpu: Double?, systemHot: Boolean, systemCritical: Boolean, now: Long): Result {
        val wasHot = hot
        if ((cpu != null && cpu >= 65.0) || (cpu == null && systemHot)) {
            if (!hot) systemOnly = cpu == null
            hot = true
        }
        if ((cpu != null && cpu < 65.0) || (cpu == null && systemOnly && !systemHot)) {
            hot = false
            systemOnly = false
            criticalSince = null
            warned = false
        }
        val critical = if (cpu != null) cpu >= 70.0 else systemCritical
        if (!critical) criticalSince = null
        else if (criticalSince == null) criticalSince = now
        val warn = hot && !warned && criticalSince?.let { now - it >= 30_000L } == true
        if (warn) warned = true
        return Result(!wasHot && hot, wasHot && !hot, warn)
    }
}

object CpuHeatGuard {
    fun isHot(): Boolean = false
    const val PAUSE_MESSAGE = ""

    fun start(context: Context) {
        // Heavy-task thermal lock disabled per user request; avoid background thermal polling to save CPU.
    }

    fun onScreenOn(context: Context) {
        // No-op: no thermal polling loop.
    }

    fun stop() {
        // No-op.
    }
}
