package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.platform.LocalClipboardManager
import com.example.core.adb.AdbDiagnosticReport
import com.example.core.adb.AdbNsdScanner
import com.example.core.adb.AdbPairingInputParser
import com.example.core.adb.AdbPairingNotificationManager
import com.example.core.adb.AdbTelemetrySnapshot
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WirelessAdbDialog(
    currentPort: Int,
    isConnected: Boolean,
    onDismiss: () -> Unit,
    onPair: (port: Int, code: String, onFinished: (Boolean, String) -> Unit) -> Unit = { _, _, _ -> },
    onConnect: (Int) -> Unit,
    onDisconnect: () -> Unit,
    onOpenDeveloperSettings: () -> Unit,
    onStartNotificationPairing: () -> Unit = {},
    isShizukuRunning: Boolean = false,
    isShizukuPermissionGranted: Boolean = false,
    isShizukuInstalled: Boolean = false,
    onRequestShizukuPermission: () -> Unit = {},
    onOpenShizukuApp: () -> Unit = {},
    onStartShizukuDirectly: () -> Unit = {},
    onResetRsaKeys: () -> Unit = {},
    telemetry: AdbTelemetrySnapshot = AdbTelemetrySnapshot(),
    diagnosticReport: AdbDiagnosticReport? = null,
    isRunningDiagnostics: Boolean = false,
    isFloatingKeypadEnabled: Boolean = false,
    onAutoConnect: () -> Unit = {},
    onPing: () -> Unit = {},
    onRunDiagnostics: () -> Unit = {},
    onToggleFloatingKeypad: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()
    val nsdScanner = remember { AdbNsdScanner.getInstance(context) }
    
    // Tối ưu hóa: Chỉ recompose khi port thay đổi, tuyệt đối không bị giật lag bởi statusText mDNS
    val pairingPort by remember(nsdScanner) {
        nsdScanner.state.map { it.pairingPort }.distinctUntilChanged()
    }.collectAsState(initial = nsdScanner.getBestPairingPort())

    val connectPort by remember(nsdScanner) {
        nsdScanner.state.map { it.connectPort }.distinctUntilChanged()
    }.collectAsState(initial = nsdScanner.getBestConnectPort())

    val dialogScrollState = rememberScrollState()
    val recentConnectPorts = remember(connectPort, isConnected) {
        nsdScanner.getRecentConnectPorts()
    }

    var selectedTab by remember { mutableIntStateOf(if (isConnected) 1 else 0) }
    var pairPortText by remember { mutableStateOf("") }
    var pairCodeText by remember { mutableStateOf("") }
    var showManualPortInput by remember { mutableStateOf(false) }
    var connectPortText by remember {
        mutableStateOf(if (isConnected && currentPort > 1024) currentPort.toString() else "")
    }

    var isPairingInProgress by remember { mutableStateOf(false) }
    var pairStatusMessage by remember { mutableStateOf<String?>(null) }
    var pairIsSuccess by remember { mutableStateOf<Boolean?>(null) }

    val handlePairAction: (Int, String) -> Unit = { port, code ->
        if (!isPairingInProgress && port in 1..65535 && code.length == 6) {
            isPairingInProgress = true
            pairStatusMessage = "⏳ Đang ghép nối mã PIN $code tới cổng $port..."
            pairIsSuccess = null
            onPair(port, code) { success, message ->
                isPairingInProgress = false
                pairIsSuccess = success
                pairStatusMessage = if (success) "🟢 Ghép nối thành công! Đang tự động kết nối..." else "❌ $message"
            }
        }
    }

    val notifPermLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) {
        onStartNotificationPairing()
    }

    DisposableEffect(Unit) {
        nsdScanner.isPairingUiActive = true
        nsdScanner.startDiscovery()
        onDispose {
            if (!AdbPairingNotificationManager.isNotificationPairingActive) {
                nsdScanner.isPairingUiActive = false
                nsdScanner.releaseMulticastLock()
                nsdScanner.stopDiscovery()
            }
        }
    }

    LaunchedEffect(pairingPort) {
        val discoveredPairingPort = pairingPort
        if (discoveredPairingPort != null && discoveredPairingPort in 1..65535) {
            pairPortText = discoveredPairingPort.toString()
            if (pairCodeText.length == 6 && !isPairingInProgress && pairIsSuccess != true) {
                handlePairAction(discoveredPairingPort, pairCodeText)
            }
        }
    }

    LaunchedEffect(connectPort) {
        val discoveredConnectPort = connectPort ?: nsdScanner.getBestConnectPort()
        if (discoveredConnectPort != null && discoveredConnectPort in 1..65535) {
            connectPortText = discoveredConnectPort.toString()
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.70f),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF070B14)),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, MagicCyan.copy(alpha = 0.6f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScrollWithScrollbar(scrollState = dialogScrollState, thumbColor = MagicCyan)
                        .padding(start = 16.dp, top = 16.dp, end = 20.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                // Đầu trang to rõ + Nút Đóng X lớn dễ bấm
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Wifi,
                            contentDescription = null,
                            tint = MagicCyan,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "TRUNG TÂM KẾT NỐI NHANH",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                softWrap = true
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MagicEmerald.copy(alpha = 0.25f))
                                    .border(1.dp, MagicEmerald, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "● WLAN ADB TRỰC TIẾP",
                                    color = MagicEmeraldLight,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "⚡ Chuẩn Gỡ Lỗi Không Dây Native Siêu Ổn Định",
                                color = MagicCyanLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                softWrap = true
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicSurfaceCard)
                            .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                            .clickable { onDismiss() }
                            .testTag("close_wireless_adb_dialog_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Đóng hộp thoại",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // Live Telemetry HUD (hiện trực tiếp Endpoint, RTT Latency, Cert SHA-256 & LAN adb connect)
                if (isConnected || connectPort != null || telemetry.lanIp != null) {
                    AdbTelemetryHudCard(
                        telemetry = telemetry,
                        isWirelessConnected = isConnected,
                        connectedPort = currentPort,
                        detectedConnectPort = connectPort,
                        onPing = onPing
                    )
                }

                // Chuyển đổi 2 tab trực tiếp: 1. Ghép nối mã 6 số | 2. Kết nối lại nhanh
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MagicSurfaceCard)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selectedTab == 0) MagicCyan else Color.Transparent)
                            .clickable { selectedTab = 0 }
                            .padding(vertical = 10.dp, horizontal = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "1. Ghép Nối Mã 6 Số",
                            color = if (selectedTab == 0) Color(0xFF020617) else TextSecondary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selectedTab == 1) MagicCyan else Color.Transparent)
                            .clickable { selectedTab = 1 }
                            .padding(vertical = 10.dp, horizontal = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "2. Kết Nối Nhanh",
                            color = if (selectedTab == 1) Color(0xFF020617) else TextSecondary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                if (selectedTab == 0) {
                    val detectedPort = pairingPort ?: pairPortText.toIntOrNull()

                    // Trạng thái tự động tìm cổng
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (detectedPort != null) MagicEmerald.copy(alpha = 0.15f)
                                else Color(0xFF0F172A)
                            )
                            .border(
                                1.dp,
                                if (detectedPort != null) MagicEmerald else MagicCyan.copy(alpha = 0.45f),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (detectedPort != null) MagicEmerald else MagicAmber)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (detectedPort != null) {
                                            "🟢 ĐÃ TỰ ĐỘNG TÌM THẤY CỔNG ($detectedPort)"
                                        } else {
                                            "⏳ Đang chờ bạn mở bảng Mã ghép đôi..."
                                        },
                                        color = if (detectedPort != null) MagicEmerald else MagicCyanLight,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        softWrap = true
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (detectedPort != null) {
                                            "Chỉ cần nhập 6 chữ số bên dưới là kết nối ngay!"
                                        } else {
                                            "Hãy bấm nút màu xanh lớn bên dưới để mở cài đặt lấy 6 số."
                                        },
                                        color = TextSecondary,
                                        fontSize = 12.sp,
                                        lineHeight = 16.sp,
                                        softWrap = true
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MagicSurfaceCard)
                                    .clickable { nsdScanner.refreshDiscovery() },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Tìm lại cổng",
                                    tint = MagicCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    // Nút BƯỚC 1: Bật thông báo nhập mã & Cửa sổ nổi & Mở cài đặt
                    Button(
                        onClick = {
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU &&
                                context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
                            ) {
                                notifPermLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                onStartNotificationPairing()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 76.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicCyan,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = null,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "BƯỚC 1: BẤM ĐỂ MỞ CÀI ĐẶT LẤY MÃ 6 SỐ",
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Mở 'Ghép nối bằng mã ghép đôi' ➔ Vuốt thanh Thông Báo xuống bấm 'NHẬP 6 SỐ' (Không thoát Cài đặt!)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF020617).copy(alpha = 0.85f),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    // Ô nhập mã 6 chữ số to rõ + Hỗ trợ Dán thông minh (PIN hoặc CỔNG+PIN)
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "BƯỚC 2: GÕ 6 CHỮ SỐ VÀO Ô DƯỚI ĐÂY:",
                            color = MagicEmerald,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Black,
                            softWrap = true
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .defaultMinSize(minHeight = 36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MagicCyan.copy(alpha = 0.15f))
                                    .clickable { showManualPortInput = !showManualPortInput }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (showManualPortInput) "Ẩn cổng ▲" else "Cổng: ${pairPortText.ifBlank { "Tự động" }} ▼",
                                    color = MagicCyanLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .defaultMinSize(minHeight = 36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MagicEmerald.copy(alpha = 0.15f))
                                    .border(1.dp, MagicEmerald.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                                    .clickable {
                                        val clipText = clipboardManager.getText()?.text.orEmpty()
                                        val parsed = AdbPairingInputParser.parse(clipText)
                                        if (parsed.port != null) {
                                            pairPortText = parsed.port.toString()
                                            showManualPortInput = true
                                        }
                                        if (!parsed.pin.isNullOrBlank()) {
                                            pairCodeText = parsed.pin
                                            val autoPort = parsed.port ?: pairPortText.toIntOrNull() ?: pairingPort ?: 0
                                            if (parsed.pin.length == 6 && autoPort in 1..65535 && !isPairingInProgress) {
                                                handlePairAction(autoPort, parsed.pin)
                                            }
                                        } else {
                                            android.widget.Toast.makeText(
                                                context,
                                                "Bộ nhớ tạm chưa có mã 6 số hoặc Cổng+PIN.",
                                                android.widget.Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                    .testTag("paste_pairing_code_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentPaste,
                                        contentDescription = "Dán mã ghép đôi",
                                        tint = MagicEmeraldLight,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Dán PIN / Cổng",
                                        color = MagicEmeraldLight,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 56.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                            .border(
                                2.dp,
                                if (pairCodeText.length == 6) MagicEmerald else MagicCyan.copy(alpha = 0.6f),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (pairCodeText.isEmpty()) {
                            Text(
                                text = "Gõ 6 số (hoặc Cổng 6_Số, VD: 38475 123456)",
                                color = TextMuted.copy(alpha = 0.7f),
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                        BasicTextField(
                            value = pairCodeText,
                            onValueChange = { rawInput ->
                                if (!isPairingInProgress) {
                                    val parsed = AdbPairingInputParser.parse(rawInput)
                                    if (parsed.port != null && parsed.pin != null) {
                                        pairPortText = parsed.port.toString()
                                        pairCodeText = parsed.pin
                                        showManualPortInput = true
                                        handlePairAction(parsed.port, parsed.pin)
                                    } else {
                                        val filtered = rawInput.filter { char -> char.isDigit() }.take(6)
                                        pairCodeText = filtered
                                        val autoPort = pairPortText.toIntOrNull() ?: pairingPort ?: 0
                                        if (filtered.length == 6 && autoPort in 1..65535) {
                                            handlePairAction(autoPort, filtered)
                                        }
                                    }
                                }
                            },
                            singleLine = true,
                            enabled = !isPairingInProgress,
                            cursorBrush = SolidColor(MagicEmerald),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            textStyle = TextStyle(
                                color = MagicEmerald,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 5.sp,
                                textAlign = TextAlign.Center
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pairing_pin_input")
                        )
                    }

                    if (pairStatusMessage != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    when (pairIsSuccess) {
                                        true -> MagicEmerald.copy(alpha = 0.2f)
                                        false -> Color(0xFFEF4444).copy(alpha = 0.2f)
                                        else -> MagicCyan.copy(alpha = 0.15f)
                                    }
                                )
                                .border(
                                    1.dp,
                                    when (pairIsSuccess) {
                                        true -> MagicEmerald
                                        false -> Color(0xFFEF4444)
                                        else -> MagicCyan
                                    },
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (isPairingInProgress) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = MagicCyan,
                                        strokeWidth = 2.dp
                                    )
                                }
                                Text(
                                    text = pairStatusMessage ?: "",
                                    color = when (pairIsSuccess) {
                                        true -> MagicEmerald
                                        false -> Color(0xFFFF6B6B)
                                        else -> MagicCyanLight
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Hướng dẫn xử lý khi ghép nối thất bại dù đã nhập đúng 6 số
                        if (pairIsSuccess == false) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B)),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber.copy(alpha = 0.7f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "💡 GỢI Ý KHẮC PHỤC KHI GHÉP NỐI THẤT BẠI:",
                                        color = MagicAmber,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "1. Tắt rồi bật lại công tắc 'Gỡ lỗi Wi-Fi' trong Cài đặt nhà phát triển để làm mới IP & Cổng kết nối.\n2. Bấm 'Thu hồi ủy quyền gỡ lỗi USB' ở danh sách cũ bên dưới, sau đó quay lại lấy mã 6 số mới và kết nối lại từ đầu.",
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontSize = 10.5.sp,
                                        lineHeight = 15.sp
                                    )
                                    Button(
                                        onClick = { onOpenDeveloperSettings() },
                                        modifier = Modifier.fillMaxWidth().heightIn(min = 36.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MagicAmber, contentColor = Color(0xFF020617))
                                    ) {
                                        Text("Mở Lại Cài Đặt Nhà Phát Triển", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    if (showManualPortInput) {
                        Text(
                            text = "CỔNG GHÉP NỐI (NẾU MUỐN NHẬP TAY 5 SỐ CUỐI):",
                            color = TextSecondary,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.Black)
                                .border(
                                    1.dp,
                                    if (pairPortText.isNotBlank()) MagicCyan else MagicBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(horizontal = 12.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (pairPortText.isEmpty()) {
                                Text(
                                    text = "Tự động điền hoặc gõ 5 số cổng (VD: 38475)",
                                    color = TextMuted.copy(alpha = 0.7f),
                                    fontSize = 13.sp
                                )
                            }
                            BasicTextField(
                                value = pairPortText,
                                onValueChange = { pairPortText = it.filter { char -> char.isDigit() }.take(5) },
                                singleLine = true,
                                enabled = !isPairingInProgress,
                                cursorBrush = SolidColor(MagicCyan),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                textStyle = TextStyle(color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    val effectivePort = pairPortText.toIntOrNull() ?: pairingPort ?: 0
                    Button(
                        onClick = {
                            if (effectivePort in 1..65535 && pairCodeText.length == 6) {
                                handlePairAction(effectivePort, pairCodeText)
                            } else if (effectivePort !in 1..65535) {
                                showManualPortInput = true
                            }
                        },
                        enabled = pairCodeText.length == 6 && !isPairingInProgress,
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 68.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isPairingInProgress) MagicCyan.copy(alpha = 0.6f) else MagicEmerald,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (isPairingInProgress) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color(0xFF020617),
                                    strokeWidth = 2.5.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "ĐANG GHÉP NỐI XÁC THỰC...",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                            } else {
                                Icon(imageVector = Icons.Default.Key, contentDescription = null, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "BẤM KẾT NỐI NGAY",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else if (selectedTab == 1) {
                    // TAB 1: KẾT NỐI LẠI NHANH
                    val detectedConnectPort = connectPort ?: connectPortText.toIntOrNull()

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (detectedConnectPort != null) MagicEmerald.copy(alpha = 0.15f)
                                else Color(0xFF0F172A)
                            )
                            .border(
                                1.dp,
                                if (detectedConnectPort != null) MagicEmerald else MagicBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (detectedConnectPort != null) {
                                    "🟢 ĐÃ TỰ ĐỘNG TÌM THẤY CỔNG KẾT NỐI ($detectedConnectPort)"
                                } else {
                                    "📡 Đang tự động tìm cổng kết nối Wi-Fi..."
                                },
                                color = if (detectedConnectPort != null) MagicEmerald else MagicCyanLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                softWrap = true
                            )
                            Text(
                                text = "Sau khi đã nhập 6 số lần đầu, những lần sau máy sẽ tự động nhận diện mà không cần nhập lại mã.",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                                softWrap = true
                            )
                        }
                    }

                    // Nút 1-Chạm Tự Dò Đa Tầng + Recent Ports Chips
                    Button(
                        onClick = onAutoConnect,
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 56.dp)
                            .testTag("auto_connect_wlan_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicEmerald,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "⚡ TỰ DÒ CỔNG & KẾT NỐI NGAY (1-CHẠM)",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (recentConnectPorts.isNotEmpty()) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Cổng vừa dùng gần đây (Chạm để nối nhanh):",
                                color = TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                recentConnectPorts.forEach { rp ->
                                    Box(
                                        modifier = Modifier
                                            .defaultMinSize(minHeight = 36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MagicCyan.copy(alpha = 0.14f))
                                            .border(1.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                                            .clickable {
                                                connectPortText = rp.toString()
                                                onConnect(rp)
                                            }
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = ":$rp",
                                            color = MagicCyanLight,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Button(
                        onClick = onOpenDeveloperSettings,
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF0F172A),
                            contentColor = MagicCyanLight
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.4f))
                    ) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Mở Cài Đặt Gỡ Lỗi Wi-Fi", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 50.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                            .border(
                                1.dp,
                                if (connectPortText.isNotBlank()) MagicCyan else MagicBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (connectPortText.isEmpty()) {
                            Text(
                                text = "Cổng tự động điền khi bật Gỡ lỗi Wi-Fi",
                                color = TextMuted.copy(alpha = 0.7f),
                                fontSize = 13.5.sp
                            )
                        }
                        BasicTextField(
                            value = connectPortText,
                            onValueChange = { connectPortText = it.filter { char -> char.isDigit() }.take(5) },
                            singleLine = true,
                            cursorBrush = SolidColor(MagicCyan),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            textStyle = TextStyle(color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val port = connectPortText.toIntOrNull() ?: connectPort ?: 5555
                                onConnect(port)
                            },
                            enabled = connectPortText.isNotBlank() || connectPort != null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 64.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicCyan,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(imageVector = Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "KẾT NỐI CỔNG ĐÃ CHỌN",
                                        fontSize = 14.5.sp,
                                        fontWeight = FontWeight.Black,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = "Cổng mục tiêu: ${connectPortText.ifBlank { connectPort?.toString() ?: "Tự động" }}",
                                        fontSize = 11.5.sp,
                                        color = Color(0xFF020617).copy(alpha = 0.85f),
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }

                        if (isConnected) {
                            Button(
                                onClick = onDisconnect,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFEF4444),
                                    contentColor = Color.White
                                )
                            ) {
                                Text(text = "Ngắt Kết Nối", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        AdbDiagnosticReportCard(
                            report = diagnosticReport,
                            isRunning = isRunningDiagnostics,
                            onRunDiagnostics = onRunDiagnostics,
                            onResetRsaKeys = onResetRsaKeys
                        )
                    }
                }

                // Khoảng đệm an toàn dưới cùng (tránh bị phím điều hướng hệ thống / thanh cử chỉ che khuất)
                Spacer(modifier = Modifier.navigationBarsPadding())
                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }
}
}
