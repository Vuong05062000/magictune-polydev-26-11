package com.example.core.widget

import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.view.View
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.core.perf.DeviceMemoryStorageOptimizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Widget Tìm kiếm & Mở nhanh ứng dụng + Khay Ứng dụng mở gần đây ngoài màn hình chính
 */
class MagicTuneAppSearchWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        if (action == Intent.ACTION_USER_PRESENT ||
            action == Intent.ACTION_SCREEN_ON ||
            action == AppWidgetManager.ACTION_APPWIDGET_OPTIONS_CHANGED ||
            action == AppWidgetManager.ACTION_APPWIDGET_UPDATE ||
            action == Intent.ACTION_CONFIGURATION_CHANGED ||
            action == "com.magictune.ACTION_REFRESH_RECENT_WIDGET" ||
            action == Intent.ACTION_PACKAGE_ADDED ||
            action == Intent.ACTION_PACKAGE_REMOVED
        ) {
            refreshAllWidgets(context)
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        if (appWidgetIds.isEmpty()) return
        val pendingResult = try {
            goAsync()
        } catch (_: Throwable) {
            null
        }
        val appCtx = context.applicationContext ?: context
        widgetIoScope.launch {
            try {
                for (appWidgetId in appWidgetIds) {
                    updateWidget(appCtx, appWidgetManager, appWidgetId)
                }
            } catch (_: Throwable) {
            } finally {
                try {
                    pendingResult?.finish()
                } catch (_: Throwable) {}
            }
        }
    }

    companion object {
        private const val PREFS_NAME = "magictune_widget_prefs"
        private const val KEY_RECENT_APPS = "recent_launched_apps"

        private val widgetIoScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        private val iconBitmapRamCache = java.util.concurrent.ConcurrentHashMap<String, Bitmap>()

        private val DEFAULT_POPULAR_PACKAGES = listOf(
            "com.zing.zalo",
            "com.facebook.katana",
            "com.facebook.orca",
            "com.ss.android.ugc.trill",
            "com.google.android.youtube",
            "com.google.android.apps.maps",
            "com.google.android.googlequicksearchbox",
            "com.android.chrome",
            "com.android.vending",
            "com.android.settings"
        )

        private fun isHomeLauncher(context: Context, pkg: String): Boolean {
            if (pkg.isBlank()) return true
            return try {
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                val resolveInfo = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                val defaultHome = resolveInfo?.activityInfo?.packageName
                pkg == defaultHome || pkg.contains(".launcher", ignoreCase = true) ||
                    pkg == "com.hihonor.android.launcher" || pkg == "com.huawei.android.launcher" ||
                    pkg == "com.google.android.apps.nexuslauncher"
            } catch (_: Throwable) {
                false
            }
        }

        fun recordAppLaunch(context: Context, packageName: String) {
            if (packageName.isBlank() || packageName == context.packageName || packageName == "com.android.systemui" || isHomeLauncher(context, packageName)) return
            val appCtx = context.applicationContext ?: context
            widgetIoScope.launch {
                try {
                    val prefs = appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    val saved = prefs.getString(KEY_RECENT_APPS, "") ?: ""
                    val current = saved.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
                    current.remove(packageName)
                    current.add(0, packageName)
                    val trimmed = current.take(15)
                    prefs.edit().putString(KEY_RECENT_APPS, trimmed.joinToString(",")).apply()
                    refreshAllWidgetsSync(appCtx)
                } catch (_: Throwable) {}
            }
        }

        fun getRecentApps(context: Context): List<String> {
            val pm = context.packageManager
            val ownPkg = context.packageName
            val candidateList = mutableListOf<String>()

            // 1. Ưu tiên hàng đầu: Các app vừa được ghi nhận mở tức thì trong SharedPreferences
            try {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val saved = prefs.getString(KEY_RECENT_APPS, "") ?: ""
                val savedList = saved.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                for (pkg in savedList) {
                    if (pkg != ownPkg && pkg != "com.android.systemui" && !isHomeLauncher(context, pkg) && !candidateList.contains(pkg)) {
                        candidateList.add(pkg)
                        if (candidateList.size >= 15) break
                    }
                }
            } catch (_: Throwable) {}

            // 2. TRUY VẤN SỰ KIỆN USAGE_EVENTS THEO THỜI GIAN THỰC (REAL-TIME RECENT APPS)
            // Lấy chính xác các app vừa chạy tiền cảnh (ACTIVITY_RESUMED / MOVE_TO_FOREGROUND) trong 24h qua
            try {
                val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                if (usm != null) {
                    val now = System.currentTimeMillis()
                    val events = usm.queryEvents(now - 24 * 3600 * 1000L, now)
                    if (events != null) {
                        val event = UsageEvents.Event()
                        val lastUsedMap = mutableMapOf<String, Long>()
                        while (events.hasNextEvent()) {
                            events.getNextEvent(event)
                            val type = event.eventType
                            if (type == UsageEvents.Event.ACTIVITY_RESUMED ||
                                type == 1 /* UsageEvents.Event.MOVE_TO_FOREGROUND */
                            ) {
                                val p = event.packageName
                                if (!p.isNullOrBlank() && p != ownPkg && p != "com.android.systemui" && !isHomeLauncher(context, p)) {
                                    lastUsedMap[p] = event.timeStamp
                                }
                            }
                        }
                        if (lastUsedMap.isNotEmpty()) {
                            val sortedEvents = lastUsedMap.entries.sortedByDescending { it.value }.map { it.key }
                            for (pkg in sortedEvents) {
                                if (!candidateList.contains(pkg)) {
                                    candidateList.add(pkg)
                                    if (candidateList.size >= 15) break
                                }
                            }
                        }
                    }
                }
            } catch (_: Throwable) {}

            // 3. Nếu chưa đủ 10 app, thử truy vấn queryUsageStats
            if (candidateList.size < 10) {
                try {
                    val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                    if (usm != null) {
                        val now = System.currentTimeMillis()
                        val stats = usm.queryUsageStats(
                            UsageStatsManager.INTERVAL_BEST,
                            now - 7 * 86_400_000L,
                            now
                        )
                        if (!stats.isNullOrEmpty()) {
                            val sorted = stats
                                .filter { it.lastTimeUsed > 0 && it.packageName != ownPkg && it.packageName != "com.android.systemui" && !isHomeLauncher(context, it.packageName) }
                                .sortedByDescending { it.lastTimeUsed }
                            for (st in sorted) {
                                val p = st.packageName
                                if (!candidateList.contains(p)) {
                                    candidateList.add(p)
                                    if (candidateList.size >= 15) break
                                }
                            }
                        }
                    }
                } catch (_: Throwable) {}
            }

            // 4. Bù thêm các gói phổ biến
            for (pkg in DEFAULT_POPULAR_PACKAGES) {
                if (!candidateList.contains(pkg)) {
                    candidateList.add(pkg)
                }
            }

            // 5. Lọc danh sách app thực tế đã cài đặt và có Intent mở (Launcher activity)
            val validInstalled = mutableListOf<String>()
            for (pkg in candidateList) {
                if (pkg == ownPkg || pkg == "com.android.systemui" || isHomeLauncher(context, pkg)) continue
                try {
                    if (pm.getLaunchIntentForPackage(pkg) != null) {
                        if (!validInstalled.contains(pkg)) {
                            validInstalled.add(pkg)
                        }
                    }
                } catch (_: Throwable) {}
                if (validInstalled.size >= 10) break
            }

            // 6. Nếu máy chưa mở đủ app hoặc thiếu app phổ biến, bù bằng các launcher app đã cài trên máy để luôn đủ 10 app
            if (validInstalled.size < 10) {
                val cachedApps = GestureLauncherOverlay.peekOrHydrateInstalledApps(context)
                if (cachedApps.isNotEmpty()) {
                    for (app in cachedApps) {
                        val pkg = app.packageName
                        if (pkg != ownPkg && pkg != "com.android.systemui" && !isHomeLauncher(context, pkg) && !validInstalled.contains(pkg)) {
                            try {
                                if (pm.getLaunchIntentForPackage(pkg) != null) {
                                    validInstalled.add(pkg)
                                    if (validInstalled.size >= 10) break
                                }
                            } catch (_: Throwable) {}
                        }
                    }
                }
            }

            if (validInstalled.size < 10) {
                try {
                    val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                        addCategory(Intent.CATEGORY_LAUNCHER)
                    }
                    val allApps = pm.queryIntentActivities(mainIntent, 0)
                    for (info in allApps) {
                        val pkg = info.activityInfo?.packageName ?: continue
                        if (pkg != ownPkg && pkg != "com.android.systemui" && !isHomeLauncher(context, pkg) && !validInstalled.contains(pkg)) {
                            try {
                                if (pm.getLaunchIntentForPackage(pkg) != null) {
                                    validInstalled.add(pkg)
                                    if (validInstalled.size >= 10) break
                                }
                            } catch (_: Throwable) {}
                        }
                    }
                } catch (_: Throwable) {}
            }

            return validInstalled.take(10)
        }

        fun refreshAllWidgets(context: Context) {
            val appCtx = context.applicationContext ?: context
            widgetIoScope.launch {
                refreshAllWidgetsSync(appCtx)
            }
        }

        private fun refreshAllWidgetsSync(context: Context) {
            try {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(
                    ComponentName(context, MagicTuneAppSearchWidgetProvider::class.java)
                )
                if (ids != null && ids.isNotEmpty()) {
                    for (id in ids) {
                        updateWidget(context, manager, id)
                    }
                }
            } catch (_: Exception) {}
        }

        private fun getOrLoadWidgetIconBitmap(context: Context, pm: android.content.pm.PackageManager, pkg: String): Bitmap? {
            iconBitmapRamCache[pkg]?.takeIf { !it.isRecycled }?.let { return it }
            DeviceMemoryStorageOptimizer.loadIconFromDisk(context, pkg)?.let { diskBmp ->
                iconBitmapRamCache[pkg] = diskBmp
                return diskBmp
            }
            return try {
                val appInfo = pm.getApplicationInfo(pkg, 0)
                val icon = pm.getApplicationIcon(appInfo)
                val bmp = drawableToBitmap(icon)
                iconBitmapRamCache[pkg] = bmp
                DeviceMemoryStorageOptimizer.saveIconToDisk(context, pkg, bmp)
                bmp
            } catch (_: Throwable) {
                null
            }
        }

        private fun drawableToBitmap(drawable: Drawable): Bitmap {
            if (drawable is BitmapDrawable && drawable.bitmap != null && !drawable.bitmap.isRecycled) {
                val src = drawable.bitmap
                if (src.width <= 128 && src.height <= 128) {
                    return src
                }
            }
            val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth.coerceAtMost(112) else 96
            val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight.coerceAtMost(112) else 96
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            return bitmap
        }

        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val views = RemoteViews(context.packageName, R.layout.widget_app_search)
            val pm = context.packageManager
            val widgetOptions = appWidgetManager.getAppWidgetOptions(appWidgetId)
            val widgetHeightDp = widgetOptions
                ?.getInt(if (context.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 64) ?: 64
            val showRecentApps = widgetHeightDp >= 120
            // Two rows need enough vertical space for the search bar and app labels.
            val showSecondRecentRow = widgetHeightDp >= 150
            views.setViewVisibility(R.id.widget_recent_apps_container, if (showRecentApps) View.VISIBLE else View.GONE)
            views.setViewVisibility(R.id.widget_recent_row_1, if (showRecentApps) View.VISIBLE else View.GONE)
            views.setViewVisibility(R.id.widget_recent_row_2, if (showSecondRecentRow) View.VISIBLE else View.GONE)

            // 1. Nút tìm kiếm chính: Mở AppSearchActivity
            val searchIntent = Intent(context, AppSearchActivity::class.java).apply {
                action = "com.example.ACTION_WIDGET_OPEN_SEARCH"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val searchPendingIntent = PendingIntent.getActivity(
                context,
                1001,
                searchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_search_touch_area, searchPendingIntent)
            views.setOnClickPendingIntent(R.id.widget_search_bar_root, searchPendingIntent)
            views.setOnClickPendingIntent(R.id.widget_search_hint, searchPendingIntent)

            // 2. Nút bên cạnh (✍️ widget_btn_magic_live): Mở tính năng Vẽ Tìm App ngay lập tức
            val drawAppIntent = Intent(context, AppSearchActivity::class.java).apply {
                action = "com.example.ACTION_WIDGET_OPEN_GESTURE_DRAW"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("OPEN_GESTURE_OVERLAY", true)
            }
            val drawAppPendingIntent = PendingIntent.getActivity(
                context,
                1004,
                drawAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_btn_magic_live, drawAppPendingIntent)

            val liveIntent = Intent(context, MagicLiveLockscreenActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val livePendingIntent = PendingIntent.getActivity(
                context, 1005, liveIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_btn_magiclive_chat, livePendingIntent)

            // 3. Nút Bánh Răng (⚙️ widget_btn_apps): Mở nhanh trang Tab Cài Đặt Chữ (Tab 6)
            val gestureSettingsIntent = Intent(context, MainActivity::class.java).apply {
                action = "com.example.ACTION_WIDGET_OPEN_GESTURE_SETTINGS"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("TARGET_TAB", "GESTURE_SETTINGS")
            }
            val gestureSettingsPendingIntent = PendingIntent.getActivity(
                context,
                1005,
                gestureSettingsIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_btn_apps, gestureSettingsPendingIntent)

            // 4. Populate 10 Recent App Slots with Real Full-Color App Icons (or Pure-White Text-Only mode)
            val slotIds = listOf(
                Triple(R.id.widget_recent_app_1, R.id.widget_recent_icon_1, R.id.widget_recent_name_1),
                Triple(R.id.widget_recent_app_2, R.id.widget_recent_icon_2, R.id.widget_recent_name_2),
                Triple(R.id.widget_recent_app_3, R.id.widget_recent_icon_3, R.id.widget_recent_name_3),
                Triple(R.id.widget_recent_app_4, R.id.widget_recent_icon_4, R.id.widget_recent_name_4),
                Triple(R.id.widget_recent_app_5, R.id.widget_recent_icon_5, R.id.widget_recent_name_5),
                Triple(R.id.widget_recent_app_6, R.id.widget_recent_icon_6, R.id.widget_recent_name_6),
                Triple(R.id.widget_recent_app_7, R.id.widget_recent_icon_7, R.id.widget_recent_name_7),
                Triple(R.id.widget_recent_app_8, R.id.widget_recent_icon_8, R.id.widget_recent_name_8),
                Triple(R.id.widget_recent_app_9, R.id.widget_recent_icon_9, R.id.widget_recent_name_9),
                Triple(R.id.widget_recent_app_10, R.id.widget_recent_icon_10, R.id.widget_recent_name_10)
            )

            val cachedLabelByPkg = GestureLauncherOverlay.peekOrHydrateInstalledApps(context)
                .associate { it.packageName to it.label }
            val recents = getRecentApps(context)
            for (i in slotIds.indices) {
                val (slotId, iconId, labelId) = slotIds[i]
                val pkg = recents.getOrNull(i)
                if (pkg != null) {
                    try {
                        val launchIntent = pm.getLaunchIntentForPackage(pkg)
                        if (launchIntent != null) {
                            val label = cachedLabelByPkg[pkg] ?: run {
                                val appInfo = pm.getApplicationInfo(pkg, 0)
                                pm.getApplicationLabel(appInfo).toString()
                            }
                            val trampolineIntent = Intent(context, AppSearchActivity::class.java).apply {
                                action = AppSearchActivity.ACTION_LAUNCH_PINNED_APP
                                putExtra(AppSearchActivity.EXTRA_PINNED_PACKAGE, pkg)
                                data = android.net.Uri.parse("magictune-pin://$pkg")
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            }
                            val pi = PendingIntent.getActivity(
                                context,
                                2000 + i,
                                trampolineIntent,
                                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                            )
                            views.setViewVisibility(slotId, View.VISIBLE)
                            views.setViewVisibility(iconId, View.VISIBLE)
                            val iconBmp = getOrLoadWidgetIconBitmap(context, pm, pkg)
                            if (iconBmp != null) {
                                views.setImageViewBitmap(iconId, iconBmp)
                            }
                            views.setTextViewText(labelId, label)
                            views.setOnClickPendingIntent(slotId, pi)
                            continue
                        }
                    } catch (_: Exception) {}
                }
                views.setViewVisibility(slotId, View.GONE)
            }

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
