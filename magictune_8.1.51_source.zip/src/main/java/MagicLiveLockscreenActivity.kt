package com.example.core.widget

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager

class MagicLiveLockscreenActivity : Activity() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var hasTriggered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            } else {
                @Suppress("DEPRECATION")
                window.addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                )
            }
        } catch (_: Throwable) {}
        handleUnlockAndLaunchMagicLive()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        hasTriggered = false
        handleUnlockAndLaunchMagicLive()
    }

    private fun handleUnlockAndLaunchMagicLive() {
        if (hasTriggered) return
        hasTriggered = true
        val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && km != null && km.isKeyguardLocked) {
            KeyguardDismissApi26.requestDismiss(this, km) {
                launchOverlayAndFinishNow()
            }
        } else {
            launchOverlayAndFinishNow()
        }
    }

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.O)
    private object KeyguardDismissApi26 {
        fun requestDismiss(activity: Activity, km: KeyguardManager, onDone: () -> Unit) {
            km.requestDismissKeyguard(activity, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() { onDone() }
                override fun onDismissCancelled() { activity.finish() }
                override fun onDismissError() { activity.finish() }
            })
        }
    }

    private fun launchOverlayAndFinishNow() {
        mainHandler.post {
            try {
                val reacquireMicOnly = intent?.getBooleanExtra(EXTRA_REACQUIRE_MIC_ONLY, false) == true
                if (!reacquireMicOnly) {
                    when (intent?.getStringExtra("pinned_overlay_action")) {
                        "double_power_folder" -> DoublePowerDockOverlay.show(applicationContext)
                        "draw" -> GestureLauncherOverlay.show(applicationContext)
                        "translate" -> if (com.example.core.permission.AppPermissionChecker.canUseCircle(applicationContext)) {
                            GoogleLiveTranslateOverlay.start(applicationContext)
                        } else {
                            android.widget.Toast.makeText(this, "Cần cấp quyền đọc màn hình trong MagicTune.", android.widget.Toast.LENGTH_LONG).show()
                        }
                        "google_circle" -> {
                            val ready = com.example.core.permission.AppPermissionChecker.canUseCircle(applicationContext)
                            if (!ready || !CircleToSearchWindowOverlay.show(applicationContext, googleSearch = true)) {
                                android.widget.Toast.makeText(this,
                                    "Cần quyền đọc màn hình và hiển thị trên ứng dụng khác để mở Khoanh tìm Google.",
                                    android.widget.Toast.LENGTH_LONG).show()
                            }
                        }
                        "circle" -> if (com.example.core.permission.AppPermissionChecker.canUseCircle(applicationContext)) {
                            com.example.core.service.SystemFloatingHudOverlay.triggerConfiguredAssistantNow(applicationContext, "CIRCLE_TO_SEARCH")
                        }
                        else -> MagicLiveFloatingOverlay.showAndStartListening(applicationContext)
                    }
                }
            } catch (_: Throwable) {}
            finishSilently()
        }
    }

    private fun finishSilently() {
        try {
            finish()
            @Suppress("DEPRECATION")
            overridePendingTransition(0, 0)
        } catch (_: Throwable) {}
    }

    companion object {
        private const val EXTRA_REACQUIRE_MIC_ONLY = "extra_reacquire_mic_only"

        fun launchFromOverlay(context: Context, reacquireMicOnly: Boolean = false): Boolean {
            return try {
                val intent = Intent(context, MagicLiveLockscreenActivity::class.java).apply {
                    addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION
                    )
                    putExtra(EXTRA_REACQUIRE_MIC_ONLY, reacquireMicOnly)
                }
                context.startActivity(intent)
                true
            } catch (_: Throwable) {
                false
            }
        }
    }
}
