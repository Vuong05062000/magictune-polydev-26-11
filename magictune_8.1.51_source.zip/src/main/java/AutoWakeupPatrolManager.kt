package com.example.core.service

import android.content.Context
import android.os.SystemClock
import com.example.core.license.LicenseManager
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * AutoWakeupPatrolManager (v6.8 - Tích hợp AI Chẩn Đoán & Đánh Thức Động cho Gmail & Meta):
 * Hệ thống Tuần Tra & Đánh Thức AI Cấp Phần Cứng & Phần Mềm trên MagicOS / Honor.
 *
 * Khắc phục triệt để lỗi "tịt thông báo / ngủ đông sâu" kinh niên của Gmail, Messenger, Instagram, Threads, WhatsApp, Zalo trên Honor
 * (Bỏ qua app Facebook chính com.facebook.katana để tránh chạy ngầm tiêu hao pin):
 * 1. Thu thập Telemetry thực tế (Standby Bucket, AppOps, Doze Whitelist, trạng thái tiến trình FCM/Sync/FBNS) của Gmail & các app Meta.
 * 2. Kết hợp AI phân tích điểm nghẽn trên thiết bị, tự động sinh lệnh gỡ khóa bổ sung và điều chỉnh nhịp tuần tra thích ứng.
 * 3. Đánh thức xuyên trạng thái Force-Stop (`--include-stopped-packages`) cho Google SyncAdapter (Gmail) và FBNS/MQTT Push (Messenger, Instagram, Threads, WhatsApp).
 * 4. Cấp đặc quyền TARE VIP (`cmd tare set-vip`), `SCHEDULE_EXACT_ALARM`, `RUN_ANY_IN_BACKGROUND`, `WAKE_LOCK`, `AUTO_START`.
 */
object AutoWakeupPatrolManager {

    private const val PREFS_NAME = "magictune_wakeup_prefs"
    private const val KEY_ENABLED = "auto_wakeup_enabled"
    private const val KEY_LAST_PULSE = "last_wakeup_pulse_ms"
    private const val KEY_LAST_AI_DIAGNOSIS = "last_ai_wakeup_diagnosis"
    private const val KEY_ADAPTIVE_INTERVAL_MS = "adaptive_wakeup_interval_ms"

    // Chu kỳ tuần tra tối ưu pin: 60 phút (3.600.000 ms) để không làm nóng máy hay đánh thức CPU liên tục
    private const val DEFAULT_PULSE_INTERVAL_MS = 60 * 60 * 1000L
    private const val AGGRESSIVE_PULSE_INTERVAL_MS = 30 * 60 * 1000L

    private val patrolScope = CoroutineScope(Dispatchers.IO)
    private var lastRunElapsed = 0L

    fun isAutoWakeupEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_ENABLED, false) // Mặc định TẮT để tránh đánh thức nền liên tục gây nóng máy & hao pin
    }

    fun setAutoWakeupEnabled(context: Context, enabled: Boolean) {
        val appCtx = context.applicationContext ?: context
        val prefs = appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val wasEnabled = prefs.getBoolean(KEY_ENABLED, false)
        // Always disabled: periodic app wakeups can keep the CPU/modem active and add heat.
        prefs.edit().putBoolean(KEY_ENABLED, false).remove(KEY_LAST_PULSE).apply()
        if (!wasEnabled) return

        // Remove exemptions left by older versions once, only when migrating an enabled patrol.
        patrolScope.launch {
            try {
                val shell = ShellEngine.getInstance(appCtx)
                if (!shell.state.value.isAdbReady) return@launch
                val managedApps = listOf(
                    appCtx.packageName,
                    "com.google.android.gm",
                    "com.zing.zalo",
                    "com.facebook.orca",
                    "com.instagram.android",
                    "com.instagram.barcelona",
                    "com.whatsapp",
                    "com.whatsapp.w4b",
                    "org.telegram.messenger",
                    "org.telegram.plus",
                    "com.viber.voip"
                ).distinct()
                val cleanup = managedApps.flatMap { pkg ->
                    listOf(
                        "cmd deviceidle whitelist -$pkg >/dev/null 2>&1 || true",
                        "cmd appops set $pkg RUN_IN_BACKGROUND default >/dev/null 2>&1 || true",
                        "cmd appops set $pkg RUN_ANY_IN_BACKGROUND default >/dev/null 2>&1 || true",
                        "cmd appops set $pkg WAKE_LOCK default >/dev/null 2>&1 || true",
                        "cmd appops set $pkg SCHEDULE_EXACT_ALARM default >/dev/null 2>&1 || true",
                        "cmd appops set $pkg AUTO_START default >/dev/null 2>&1 || true"
                    )
                }
                shell.execute(cleanup.joinToString(" ; "), isBackground = true)
            } catch (_: Throwable) {}
        }
    }

    fun getLastAiWakeupDiagnosis(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(
            KEY_LAST_AI_DIAGNOSIS,
            "Tuần tra đánh thức nền đã tắt để tránh CPU thức dậy định kỳ và làm nóng máy."
        ).orEmpty()
    }

    fun getCurrentPatrolIntervalMinutes(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val ms = prefs.getLong(KEY_ADAPTIVE_INTERVAL_MS, DEFAULT_PULSE_INTERVAL_MS)
        return ((ms / 60000L).toInt()).coerceIn(5, 30)
    }

    /**
     * Danh sách App Ngân Hàng, Ví Điện Tử và App giao tiếp/mua sắm trọng yếu tại Việt Nam
     */
    val VIETNAM_BANKING_AND_ESSENTIAL_APPS = listOf(
        // Ngân hàng & Ví điện tử Việt Nam
        "com.VCB",                    // Vietcombank Digimi
        "vn.com.techcombank.bb.app",  // Techcombank Mobile
        "com.mbmobile",               // MB Bank
        "com.vpb.vpbankonline",       // VPBank NEO
        "com.vnpay.bidv",             // BIDV SmartBanking
        "com.vnpay.Agribank",         // Agribank E-Mobile Banking
        "com.tpb.mb.gprsandroid",     // TPBank Mobile
        "vn.com.acb.acblap",          // ACB ONE
        "com.vnpay.vietinbank",       // VietinBank iPay
        "vn.com.sacombank.mbanking",  // Sacombank mBanking
        "com.shb.mobile",             // SHB Mobile
        "com.ocb.omni",               // OCB OMNI
        "com.vnpay.vpbank",           // VPBank Cake
        "vn.tpay",                    // Timo Digital Bank
        "com.mservice.momopay",       // MoMo
        "vn.com.vng.zalopay",         // ZaloPay
        "vn.viettel.viettelpay",      // Viettel Money
        "com.vnpay.wallet",           // VNPAY
        // Ứng dụng liên lạc, mua sắm, công việc quốc tế phổ biến
        "com.viber.voip",             // Viber
        "com.microsoft.teams",        // MS Teams
        "com.microsoft.office.outlook",// Outlook
        "com.Slack",                  // Slack
        "com.discord",                // Discord
        "jp.naver.line.android",      // Line
        "com.shopee.vn",              // Shopee
        "com.lazada.android",         // Lazada
        "com.grabtaxi.passenger",     // Grab
        "com.tiktok.android",         // TikTok
        "com.zhiliaoapp.musically"    // TikTok Asia
    )

    private fun isPkgInstalled(context: Context, pkg: String): Boolean {
        return try {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun getFullTargetPatrolApps(context: Context, myPkg: String): List<String> {
        // H2 FIX: Chỉ tuần tra các app trọng yếu ĐANG CÀI TRÊN MÁY, bỏ qua app Facebook chính (com.facebook.katana) để tiết kiệm pin nhưng vẫn giữ đủ các app Meta khác.
        val baseList = mutableSetOf(
            myPkg,
            "com.google.android.gm",
            "com.google.android.gms",
            "com.google.android.gsf",
            "com.facebook.orca",
            "com.facebook.services",
            "com.instagram.android",
            "com.instagram.barcelona",
            "com.whatsapp",
            "com.whatsapp.w4b",
            "com.zing.zalo",
            "org.telegram.messenger",
            "org.telegram.plus"
        )
        baseList.addAll(VIETNAM_BANKING_AND_ESSENTIAL_APPS)
        return baseList.filter { (it == myPkg || isPkgInstalled(context, it)) && it != "com.facebook.katana" }
    }

    /**
     * Xây dựng danh sách lệnh đánh thức đa tầng chuyên sâu (9 Lớp Vũ Khí Hạt Nhân) cho Gmail & Facebook:
     * 1. Khống chế PowerGenius, iAware, Bastet, SmartSocket.
     * 2. Vô hiệu hóa Cgroup v2 Cached Apps Freezer & Phantom Process Killer (ngăn đóng băng tiến trình nền trên Android 14/15/16).
     * 3. Mở khóa Tường lửa Mạng Ngầm theo UID (NetPolicy restrict-background-whitelist & app-idle-whitelist) chống ngắt socket khi tắt màn hình.
     * 4. Chống ngủ đông sâu (App Hibernation = false, Standby Bucket = ACTIVE, Doze Whitelist, TARE VIP = true).
     * 5. Bật cưỡng bức Master Auto-Sync & phá gom cụm 0s cho JobScheduler / SyncManager / AlarmManager.
     * 6. Cấp đầy đủ AppOps cả cấp Package và --uid (RUN_IN_BACKGROUND, RUN_ANY_IN_BACKGROUND, WAKE_LOCK, SCHEDULE_EXACT_ALARM, AUTO_START).
     * 7. Đánh thức xuyên trạng thái Force-Stop (--include-stopped-packages) cho Gmail SyncAdapter, Google FCM Heartbeat và Facebook FBNS/MQTT.
     */
    private fun buildDeepGmailFacebookWakeupCommands(context: Context, myPkg: String): List<String> {
        val shell = ShellEngine.getInstance(context.applicationContext)
        val caps = shell.getCapabilitiesSnapshot()
        val criticalApps = getFullTargetPatrolApps(context, myPkg)
            .filter { shell.isPackageInstalledQuick(it) }

        val cmds = mutableListOf<String>()

        // 1. Giữ app_standby_enabled & cached_apps_freezer hoạt động bình thường cho các app ít dùng để bảo vệ pin,
        // chỉ mở khóa từng app thiết yếu thay vì tắt tiết kiệm pin toàn hệ thống.
        cmds.add("settings put global app_standby_enabled 1 2>/dev/null || true")
        cmds.add("settings put global cached_apps_freezer enabled 2>/dev/null || true")
        cmds.add("device_config put activity_manager_native_boot use_freezer true 2>/dev/null || true")
        cmds.add("settings delete global job_scheduler_constants 2>/dev/null || true")
        cmds.add("device_config delete jobscheduler min_ready_non_active_jobs_count 2>/dev/null || true")
        cmds.add("device_config delete jobscheduler max_non_active_job_batch_delay_ms 2>/dev/null || true")
        cmds.add("device_config delete tare enable_tare_mode 2>/dev/null || true")

        // 2. Bật đồng bộ hóa tự động hệ thống qua ContentResolver API + global settings (thay cho lệnh lỗi thời cmd content set-master-sync-automatically)
        try {
            android.content.ContentResolver.setMasterSyncAutomatically(true)
        } catch (_: Throwable) {}
        cmds.add(shell.buildSafeMasterSyncCmd(true))

        // 3. Bật Banner nổi + Màn hình khóa cho thông báo quan trọng
        cmds.add("settings put system gentle_notification_enabled 0")
        cmds.add("settings put system hw_notification_gentle_switch 0")
        cmds.add("settings put global heads_up_notifications_enabled 1")
        cmds.add("settings put system notification_banner_enabled 1")
        cmds.add("settings put system lock_screen_notification_style 0")
        cmds.add("settings put system lock_screen_details_notification 1")
        cmds.add("settings put secure lock_screen_show_notifications 1")
        cmds.add("settings put secure lock_screen_allow_private_notifications 1")
        cmds.add("settings put system lock_screen_show_notifications 1")
        cmds.add("settings put system notification_cooldown_enabled 0")

        // 6. Mở khóa toàn diện AppOps, TARE VIP (có pre-flight check), Anti-Hibernation, Doze Whitelist & NetPolicy UID
        val pm = context.packageManager
        val canHibernateCmd = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
            (!caps.probed || caps.hasAppHibernationService)
        for (pkg in criticalApps) {
            cmds.add("am set-standby-bucket --user 0 $pkg active >/dev/null 2>&1 || true")
            cmds.add("cmd activity set-inactive --user 0 $pkg false >/dev/null 2>&1 || true")
            if (canHibernateCmd) {
                cmds.add("cmd app_hibernation set-state --user 0 $pkg false >/dev/null 2>&1 || true")
            }
            cmds.add("cmd deviceidle whitelist +$pkg >/dev/null 2>&1 || dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true")
            val tareCmd = shell.buildSafeTareVipCmd(pkg, true)
            if (tareCmd != "true") cmds.add(tareCmd)
            for (op in listOf(
                "RUN_IN_BACKGROUND",
                "RUN_ANY_IN_BACKGROUND",
                "START_FOREGROUND",
                "POST_NOTIFICATION",
                "WAKE_LOCK",
                "SCHEDULE_EXACT_ALARM",
                "USE_EXACT_ALARM",
                "TURN_SCREEN_ON",
                "GET_USAGE_STATS",
                "AUTO_START",
                "BOOT_COMPLETED",
                "SYSTEM_ALERT_WINDOW"
            )) {
                val opCmd = shell.buildSafeAppOpsCmd(pkg, op, "allow")
                if (opCmd != "true") cmds.add(opCmd)
            }
            val revokeIgnoreCmd = shell.buildSafeAppOpsCmd(pkg, "AUTO_REVOKE_PERMISSIONS_IF_UNUSED", "ignore")
            if (revokeIgnoreCmd != "true") cmds.add(revokeIgnoreCmd)

            // Đưa UID thực tế của Gmail, Facebook, GMS vào danh sách miễn trừ tường lửa mạng ngầm khi tắt màn hình
            try {
                val uid = pm.getApplicationInfo(pkg, 0).uid
                if (uid > 1000) {
                    cmds.add("cmd netpolicy add restrict-background-whitelist $uid >/dev/null 2>&1 || true")
                    cmds.add("cmd netpolicy add app-idle-whitelist $uid >/dev/null 2>&1 || true")
                }
            } catch (_: Throwable) {}
        }

        // 7. Tầng 1 Đa Không Gian (chỉ chạy trên User tồn tại & gói có trong ROM) + Bật tiến trình FCM
        val gmsInstalled = shell.isPackagePresentInRom("com.google.android.gms")
        val gsfInstalled = shell.isPackagePresentInRom("com.google.android.gsf")
        for (u in listOf(0, 10, 128)) {
            if (!shell.isUserActive(u)) continue
            if (gmsInstalled) {
                cmds.add(shell.buildSafeEnablePackageCmd("com.google.android.gms", u))
                cmds.add("am set-standby-bucket --user $u com.google.android.gms active 2>/dev/null || true")
            }
            if (gsfInstalled) {
                cmds.add(shell.buildSafeEnablePackageCmd("com.google.android.gsf", u))
            }
        }
        val fcmComponents = listOf(
            "com.google.android.gm/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "com.google.android.gm/com.google.firebase.messaging.FirebaseMessagingService",
            "com.facebook.orca/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "com.facebook.orca/com.google.firebase.messaging.FirebaseMessagingService",
            "com.instagram.android/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "com.instagram.android/com.google.firebase.messaging.FirebaseMessagingService",
            "com.instagram.barcelona/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "com.instagram.barcelona/com.google.firebase.messaging.FirebaseMessagingService",
            "com.whatsapp/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "com.whatsapp/com.google.firebase.messaging.FirebaseMessagingService"
        )
        for (comp in fcmComponents) {
            if (shell.isPackageInstalledQuick(comp.substringBefore('/'))) {
                cmds.add("pm enable --user 0 $comp 2>/dev/null || true")
            }
        }

        // 8. Tầng 6: Xử lý lỗi mất âm thanh thông báo Gmail (Sound Fallback từ MediaStore + mở khóa âm lượng Stream 5)
        cmds.add(
            "CUR_SND=\$(settings get system notification_sound 2>/dev/null || echo \"\"); " +
                "if [ -z \"\$CUR_SND\" ] || [ \"\$CUR_SND\" = \"null\" ] || [ \"\$CUR_SND\" = \"silent\" ] || [ \"\$CUR_SND\" = \"0\" ]; then " +
                "FIRST_ID=\$(content query --uri content://media/internal/audio/media --projection _id:is_notification 2>/dev/null | grep 'is_notification=1' | head -n 1 | sed -n 's/.*_id=\\([0-9]*\\).*/\\1/p' || echo \"\"); " +
                "if [ -z \"\$FIRST_ID\" ]; then FIRST_ID=\$(content query --uri content://media/internal/audio/media --projection _id 2>/dev/null | head -n 1 | sed -n 's/.*_id=\\([0-9]*\\).*/\\1/p' || echo \"\"); fi; " +
                "if [ -n \"\$FIRST_ID\" ]; then settings put system notification_sound \"content://media/internal/audio/media/\$FIRST_ID\" >/dev/null 2>&1 || true; else settings put system notification_sound \"content://settings/system/notification_sound\" >/dev/null 2>&1 || true; fi; " +
                "fi || true"
        )
        cmds.add("cmd media_session volume --stream 5 --set 12 2>/dev/null || media volume --stream 5 --set 12 2>/dev/null || true")

        // 9. Xung nhịp đánh thức trực tiếp Gmail SyncAdapter, Google FCM Heartbeat & Facebook FBNS/MQTT (--include-stopped-packages)
        cmds.add("am broadcast -a com.google.android.gms.gcm.ACTION_HEARTBEAT_NOW -p com.google.android.gms --include-stopped-packages 2>/dev/null")
        cmds.add("am broadcast -a com.google.android.intent.action.GCM_RECONNECT -p com.google.android.gms --include-stopped-packages 2>/dev/null")
        cmds.add("am broadcast -a com.google.android.c2dm.intent.RECEIVE -p com.google.android.gms --ei google.delivered_priority 1 --include-stopped-packages 2>/dev/null")
        // Đánh thức Gmail đồng bộ hòm thư tức thì kể cả khi đang bị hệ thống dừng cưỡng bức
        cmds.add("am broadcast -a com.google.android.c2dm.intent.RECEIVE -p com.google.android.gm --ei google.delivered_priority 1 --include-stopped-packages 2>/dev/null")
        cmds.add("am broadcast -a android.intent.action.SYNC -p com.google.android.gm --include-stopped-packages 2>/dev/null")
        cmds.add("am broadcast -a android.accounts.LOGIN_ACCOUNTS_CHANGED -p com.google.android.gm --include-stopped-packages 2>/dev/null")
        cmds.add("am broadcast -a android.net.conn.CONNECTIVITY_CHANGE -p com.google.android.gm --include-stopped-packages 2>/dev/null")
        // Đánh thức các app Meta (Messenger, Instagram, Threads, WhatsApp, Meta Services) & Zalo qua kênh FCM + FBNS/MQTT (bỏ qua app Facebook chính để tiết kiệm pin)
        for (metaPkg in listOf("com.facebook.orca", "com.instagram.android", "com.instagram.barcelona", "com.whatsapp", "com.whatsapp.w4b")) {
            if (shell.isPackageInstalledQuick(metaPkg)) {
                cmds.add("am broadcast -a com.google.android.c2dm.intent.RECEIVE -p $metaPkg --ei google.delivered_priority 1 --include-stopped-packages 2>/dev/null")
                cmds.add("am broadcast -a com.facebook.rti.fbns.intent.RECEIVE -p $metaPkg --include-stopped-packages 2>/dev/null")
                cmds.add("am broadcast -a android.net.conn.CONNECTIVITY_CHANGE -p $metaPkg --include-stopped-packages 2>/dev/null")
            }
        }
        if (shell.isPackageInstalledQuick("com.facebook.services")) {
            cmds.add("am broadcast -a com.facebook.rti.fbns.intent.RECEIVE -p com.facebook.services --include-stopped-packages 2>/dev/null")
        }
        cmds.add("am broadcast -a android.net.conn.CONNECTIVITY_CHANGE -p com.zing.zalo --include-stopped-packages 2>/dev/null")

        return cmds
    }

    /**
     * Kịch bản AI Đặc Trị Khắc Phục Triệt Để 100% Thông Báo & Đánh Thức Gmail + Facebook:
     * Thực thi đồng bộ (Suspend) để trả về báo cáo chẩn đoán AI chi tiết cho giao diện và nhật ký.
     */
    suspend fun performAiSmartGmailFacebookWakeupSync(context: Context): String = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        val shell = ShellEngine.getInstance(appCtx)

        if (!shell.state.value.isAdbReady) {
            return@withContext "⚠️ Chưa kết nối Gỡ lỗi WLAN / Shizuku! Vui lòng ghép nối Gỡ lỗi Wi-Fi trước khi chạy Đánh thức AI Gmail & Meta."
        }

        // Bước 1: Thu thập trạng thái thực tế của Gmail & các app Meta (trừ app Facebook chính) trước khi đánh thức
        val preTelemetry = try {
            val diagCmd = """
                echo "=== BUCKETS ==="
                am get-standby-bucket com.google.android.gm 2>/dev/null
                am get-standby-bucket com.facebook.orca 2>/dev/null
                am get-standby-bucket com.instagram.android 2>/dev/null
                am get-standby-bucket com.whatsapp 2>/dev/null
                echo "=== APPOPS_GMAIL ==="
                cmd appops get com.google.android.gm RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK AUTO_START 2>/dev/null
                echo "=== APPOPS_META ==="
                cmd appops get com.facebook.orca RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK AUTO_START 2>/dev/null
                cmd appops get com.instagram.android RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK AUTO_START 2>/dev/null
                echo "=== DOZE ==="
                dumpsys deviceidle whitelist | grep -E "com.google.android.gm|com.facebook.orca|com.instagram.android|com.instagram.barcelona|com.whatsapp" 2>/dev/null
            """.trimIndent()
            shell.execute(diagCmd).output.take(1200)
        } catch (_: Throwable) {
            ""
        }

        // Bước 2: Chạy kịch bản đánh thức đa tầng cho Gmail, Messenger, Instagram, Threads, WhatsApp & GMS
        val wakeupCmds = buildDeepGmailFacebookWakeupCommands(appCtx, appCtx.packageName)
        shell.execute(wakeupCmds.joinToString("\n"))
        lastRunElapsed = SystemClock.elapsedRealtime()

        // Bước 3: Kết hợp AI phân tích Telemetry thực tế của Gmail & Facebook để tinh chỉnh chu kỳ & sinh lệnh bổ sung nếu cần
        val aiReport = analyzeAndOptimizeWakeupWithAi(appCtx, preTelemetry, shell)

        appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putLong(KEY_LAST_PULSE, System.currentTimeMillis())
            .putString(KEY_LAST_AI_DIAGNOSIS, aiReport)
            .apply()

        aiReport
    }

    /**
     * Kịch bản AI Đặc Trị Khắc Phục Triệt Để 100% Thông Báo Gmail & Facebook Honor (Bất đồng bộ).
     */
    fun performHonorNotificationDeepFix(context: Context, onComplete: ((Boolean) -> Unit)? = null) {
        patrolScope.launch {
            try {
                val report = performAiSmartGmailFacebookWakeupSync(context)
                onComplete?.invoke(report.isNotBlank())
            } catch (_: Exception) {
                onComplete?.invoke(false)
            }
        }
    }

    /**
     * Phân tích trạng thái ngủ đông của Gmail & Facebook bằng AI để tự động sinh lệnh cứu hộ chuyên sâu
     * và điều chỉnh tần suất đánh thức thích ứng trên ROM MagicOS.
     */
    private suspend fun analyzeAndOptimizeWakeupWithAi(
        context: Context,
        telemetrySnapshot: String,
        shell: ShellEngine
    ): String {
        val wasRestricted = telemetrySnapshot.contains("ignore", ignoreCase = true) ||
            telemetrySnapshot.contains("deny", ignoreCase = true) ||
            telemetrySnapshot.contains("rare", ignoreCase = true) ||
            telemetrySnapshot.contains("restricted", ignoreCase = true) ||
            telemetrySnapshot.contains("frequent", ignoreCase = true) ||
            telemetrySnapshot.contains("working_set", ignoreCase = true)

        // Nếu phát hiện hệ thống MagicOS từng hạ Bucket hoặc chặn AppOps của Gmail/Facebook -> Rút ngắn chu kỳ tuần tra xuống 2 phút
        val targetIntervalMs = if (wasRestricted) AGGRESSIVE_PULSE_INTERVAL_MS else DEFAULT_PULSE_INTERVAL_MS
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putLong(KEY_ADAPTIVE_INTERVAL_MS, targetIntervalMs)
            .apply()

        val apiKey = LicenseManager.getLoadBalancedGroqApiKey(context).ifBlank {
            try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }
        }

        if (apiKey.isNotBlank() && apiKey != "GROQ_API_KEY_DEFAULT_VALUE") {
            val models = listOf("openai/gpt-oss-120b", "qwen/qwen3.8-27b", "llama-3.3-70b-versatile", "llama-3.1-8b-instant")
            val systemPrompt = """
                Bạn là Hệ thống AI Điều Phối Đánh Thức Ứng Dụng Ngầm của MagicTune trên điện thoại Honor MagicOS.
                Tuyệt đối KHÔNG nhắc đến tên bất kỳ mô hình AI hay nhà cung cấp nào (không nhắc Groq, Llama, Qwen, OpenAI...).
                Nhiệm vụ:
                1. Phân tích thông số Telemetry của Gmail (com.google.android.gm) và các app Meta (Messenger com.facebook.orca, Instagram com.instagram.android, Threads com.instagram.barcelona, WhatsApp com.whatsapp) — bỏ qua app Facebook chính (com.facebook.katana) để tiết kiệm pin.
                2. Nếu thấy bất kỳ quyền nào bị 'ignore'/'deny' hoặc bucket khác '10 (ACTIVE)', hãy kèm 1 dòng lệnh sửa ở cuối theo cú pháp [SHELL_FIX: <lệnh shell an toàn>].
                3. Trả về đúng 1-2 câu Tiếng Việt ngắn gọn, súc tích báo cáo trạng thái đã đánh thức Gmail (SyncAdapter/FCM) và các app Meta (Messenger/Instagram/Threads/WhatsApp), ghim mức ACTIVE (10) và đặt chu kỳ tuần tra AI thích ứng (${targetIntervalMs / 60000} phút/lần).
            """.trimIndent()

            val userPrompt = "Dữ liệu Telemetry Gmail & các app Meta trước khi đánh thức:\n${telemetrySnapshot.ifBlank { "Standby Bucket & AppOps đang được kiểm soát bởi MagicOS." }}\nHãy xác nhận kết quả đánh thức thông minh."

            for (model in models) {
                var conn: HttpURLConnection? = null
                try {
                    val url = URL("https://api.groq.com/openai/v1/chat/completions")
                    conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 4500
                        readTimeout = 7000
                        doOutput = true
                        doInput = true
                        setRequestProperty("Authorization", "Bearer $apiKey")
                        setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    }

                    val messages = JSONArray().apply {
                        put(JSONObject().put("role", "system").put("content", systemPrompt))
                        put(JSONObject().put("role", "user").put("content", userPrompt))
                    }
                    val payload = JSONObject().apply {
                        put("model", model)
                        put("temperature", 0.15)
                        put("max_tokens", 160)
                        put("messages", messages)
                    }

                    conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                    if (conn.responseCode in 200..299) {
                        val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val rawReply = JSONObject(body)
                            .optJSONArray("choices")
                            ?.optJSONObject(0)
                            ?.optJSONObject("message")
                            ?.optString("content", "")
                            .orEmpty()
                            .replace(Regex("<think>[\\s\\S]*?</think>"), "")
                            .replace("**", "")
                            .trim()

                        if (rawReply.isNotBlank()) {
                            // Nếu AI đề xuất lệnh shell cứu hộ bổ sung -> Thực thi an toàn qua pre-flight
                            val fixMatch = Regex("""\[SHELL_FIX:\s*([^\]]+)\]""").find(rawReply)
                            val extraCmd = fixMatch?.groupValues?.getOrNull(1)?.trim().orEmpty()
                            val allowExtraCmd = extraCmd.isNotBlank() && (
                                extraCmd.startsWith("cmd appops") ||
                                    extraCmd.startsWith("am ") ||
                                    extraCmd.startsWith("dumpsys deviceidle") ||
                                    (extraCmd.startsWith("cmd tare") && shell.getCapabilitiesSnapshot().hasTareService)
                                )
                            if (allowExtraCmd) {
                                try {
                                    shell.execute(extraCmd)
                                } catch (_: Throwable) {}
                            }

                            val cleanSummary = rawReply
                                .replace(Regex("""\[SHELL_FIX:[^\]]*\]"""), "")
                                .replace(Regex("(?i)\\b(groq|grock|llama[-\\s\\d.a-z]*|qwen[-\\s\\d.a-z]*|openai|pollinations)\\b"), "Magic AI")
                                .trim()
                            if (cleanSummary.isNotBlank()) {
                                return cleanSummary
                            }
                        }
                    } else if (conn.responseCode == 429 || conn.responseCode == 401) {
                        LicenseManager.markGroqApiKeyCooldown(apiKey)
                    }
                } catch (_: Throwable) {
                } finally {
                    try { conn?.disconnect() } catch (_: Throwable) {}
                }
            }
        }

        val intervalMin = targetIntervalMs / 60000L
        return "🤖 AI Đánh Thức Thông Minh đã kích hoạt kênh đồng bộ ngầm cho Gmail & các app Meta (Messenger, Instagram, Threads, WhatsApp), bỏ qua app Facebook chính để chống hao pin, ghim Standby Bucket mức ACTIVE (10) và tuần tra tự động mỗi $intervalMin phút."
    }

    /**
     * Gửi xung nhịp định kỳ đánh thức ngầm các ứng dụng bị MagicOS dìm (Gmail, FCM, Messenger, Instagram, Threads, WhatsApp, Zalo... trừ app Facebook chính)
     */
    fun performSilentPulseIfDue(context: Context) {
        if (!isAutoWakeupEnabled(context)) return
        val pm = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
        if (pm != null && !pm.isInteractive) return

        // BẢO VỆ NHIỆT ĐỘ & PIN: Tự động ngủ sâu 100% khi pin ấm (>= 37.5°C) hoặc pin yếu (<= 20% khi không sạc)
        val currentBatt = com.example.core.widget.BatteryInfoReader.peekLastSnapshot()
        if (currentBatt != null && (currentBatt.tempCelsius >= 37.5 || (!currentBatt.isCharging && currentBatt.batteryPct <= 20))) {
            return
        }

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val intervalMs = prefs.getLong(KEY_ADAPTIVE_INTERVAL_MS, DEFAULT_PULSE_INTERVAL_MS).coerceAtLeast(30 * 60 * 1000L)
        val now = SystemClock.elapsedRealtime()
        if (now - lastRunElapsed < intervalMs && lastRunElapsed != 0L) {
            return
        }
        lastRunElapsed = now

        patrolScope.launch {
            try {
                val appCtx = context.applicationContext
                val shell = ShellEngine.getInstance(appCtx)
                if (!shell.state.value.isAdbReady) return@launch
                val coreChatApps = listOf(
                    appCtx.packageName,
                    "com.google.android.gm",
                    "com.zing.zalo",
                    "com.facebook.orca",
                    "com.instagram.android",
                    "com.instagram.barcelona",
                    "com.whatsapp",
                    "com.whatsapp.w4b",
                    "org.telegram.messenger"
                ).distinct().filter { it == appCtx.packageName || isPkgInstalled(appCtx, it) }

                if (coreChatApps.isEmpty()) return@launch
                val pkgSpaceList = coreChatApps.joinToString(" ")
                // Chỉ xử lý từng app nếu app đó chưa nằm trong whitelist hoặc bị hạ khỏi mức active (10), tránh spam shell
                val smartCmd = """
                    WL="${'$'}(dumpsys deviceidle whitelist 2>/dev/null || true)"
                    for p in $pkgSpaceList; do
                        case "${'$'}WL" in
                            *"${'$'}p"*) ;;
                            *) dumpsys deviceidle whitelist +"${'$'}p" >/dev/null 2>&1 || true ;;
                        esac
                        B="${'$'}(am get-standby-bucket "${'$'}p" 2>/dev/null || true)"
                        case "${'$'}B" in
                            *10*|*active*) ;;
                            *) am set-standby-bucket "${'$'}p" active >/dev/null 2>&1 || true ;;
                        esac
                    done
                """.trimIndent()
                shell.execute(smartCmd)

                prefs.edit()
                    .putLong(KEY_LAST_PULSE, System.currentTimeMillis())
                    .apply()
            } catch (_: Exception) {}
        }
    }
}
