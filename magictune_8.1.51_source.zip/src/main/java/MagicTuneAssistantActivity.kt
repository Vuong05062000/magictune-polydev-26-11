package com.example.core.assistant

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import com.example.core.widget.MagicLiveFloatingOverlay
import com.example.core.widget.MagicLiveLockscreenActivity

/**
 * Activity tiếp nhận sự kiện ASSIST & VOICE_ASSIST từ hệ điều hành Honor MagicOS.
 * Hoạt động ngay cả khi điện thoại đang KHÓA MÀN HÌNH (ShowWhenLocked + TurnScreenOn).
 */
class MagicTuneAssistantActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Cấu hình hiển thị đè trên màn hình khóa và bật màn hình sáng
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }

        // Kích hoạt theo chế độ người dùng lựa chọn (Khoanh tròn tìm kiếm hoặc Trợ lý Magic)
        val mode = com.example.core.service.SystemFloatingHudOverlay.getActiveNavModMode(this)
        if (mode == "CIRCLE_TO_SEARCH") {
            com.example.core.widget.CircleToSearchOverlayActivity.launch(this)
        } else {
            val launched = MagicLiveFloatingOverlay.showAndStartListening(this)
            if (!launched) {
                MagicLiveLockscreenActivity.launchFromOverlay(this)
            }
        }

        finish()
    }
}
