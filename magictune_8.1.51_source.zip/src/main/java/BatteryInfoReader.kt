package com.example.core.widget

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

typealias LiveBatteryData = BatteryChargeData

data class BatteryChargeData(
    val batteryPct: Int,
    val isCharging: Boolean,
    val currentWatts: Double,
    val dischargingWatts: Double = 0.8,
    val peakSessionWatts: Double = currentWatts,
    val currentMa: Int = 300,
    val voltageV: Double = 4.0,
    val tempCelsius: Double = 32.0,
    val cycleCount: Int = 0,
    val minutesToFull: Int = 0,
    val minutesTo100: Int = 0,
    val speedTitle: String = "",
    val speedSubtitle: String = "",
    val phoneDisplayName: String = "",
    val healthLabel: String = "Tốt (Good)",
    val pluggedTypeLabel: String = "Đang xả pin",
    val technology: String = "Li-SiC",
    val designCapacityMah: Int = 5000,
    val remainingCapacityMah: Int = 4000,
    val estimatedScreenOnHours: Int = 6,
    val estimatedScreenOnMins: Int = 30,
    val estimatedStandbyHours: Int = 30,
    val isSlowCharge: Boolean = false,
    val estimatedUsageText: String = "",
    val cpuThermalCelsius: Double = 0.0,
    val chargeCounterUah: Long = 0L,
    val isFullySaturated: Boolean = false,
    val saturationRemainingMinutes: Int = 0,
    val isBatteryTemperatureAvailable: Boolean = true
) {
    val temperatureC: Double
        get() = tempCelsius
}

object BatteryInfoReader {
    private const val PREFS_NAME = "magictune_battery_widget_prefs"
    private const val KEY_CHARGE_START_REALTIME = "charge_start_elapsed_realtime"
    private const val KEY_LAST_SUMMARY = "last_charge_summary_text"
    private const val KEY_WAS_CHARGING = "was_charging_state"
    private const val KEY_PEAK_WATTS = "peak_session_watts"
    private const val KEY_LAST_COOL_REPORT = "last_cool_report_text"
    private const val KEY_LAST_COOL_TIME_MS = "last_cool_report_time_ms"
    private const val KEY_FULL_100_TIME_REALTIME = "full_100_elapsed_realtime"
    const val SATURATION_TRICKLE_MINUTES = 15
    const val SATURATION_TRICKLE_MS = SATURATION_TRICKLE_MINUTES * 60 * 1000L

    @Volatile var forceConnected: Boolean = false
    @Volatile var forceDisconnected: Boolean = false
    @Volatile var forceConnectedTimeMs: Long = 0L
    @Volatile var forceDisconnectedTimeMs: Long = 0L
    @Volatile var chargeStartElapsedRealtime: Long = 0L
    @Volatile var full100ElapsedRealtime: Long = 0L
    @Volatile var hasObservedHardwareMa: Boolean = false
    @Volatile var lastChargeSummaryText: String = ""
    @Volatile var peakSessionWatts: Double = 0.0
    @Volatile private var cachedDesignCapacityMah: Int = -1
    @Volatile private var isPersistedStateRestored: Boolean = false
    @Volatile private var discoveredThermalTempPaths: List<String>? = null
    @Volatile private var lastCpuThermalCelsius: Double = 0.0
    @Volatile private var lastCpuThermalReadMs: Long = 0L
    @Volatile private var cachedCycleCount: Int = -1
    @Volatile private var lastCycleCountReadMs: Long = 0L
    @Volatile private var powerProfileLookupFailed: Boolean = false
    @Volatile private var lastReadSnapshot: LiveBatteryData? = null
    private val unavailableSysfsPaths = java.util.Collections.synchronizedSet(HashSet<String>())

    fun peekLastSnapshot(): LiveBatteryData? = lastReadSnapshot

    fun restorePersistedState(context: Context) {
        if (isPersistedStateRestored) return
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val wasCharging = prefs.getBoolean(KEY_WAS_CHARGING, false)
            if (chargeStartElapsedRealtime == 0L) {
                chargeStartElapsedRealtime = prefs.getLong(KEY_CHARGE_START_REALTIME, 0L)
            }
            if (lastChargeSummaryText.isBlank()) {
                lastChargeSummaryText = prefs.getString(KEY_LAST_SUMMARY, "").orEmpty()
            }
            // Chỉ khôi phục đỉnh W nếu phiên sạc trước đó vẫn đang tiếp diễn thực sự
            if (wasCharging && peakSessionWatts <= 0.0) {
                peakSessionWatts = prefs.getFloat(KEY_PEAK_WATTS, 0f).toDouble()
            } else if (!wasCharging) {
                peakSessionWatts = 0.0
            }
            isPersistedStateRestored = true
        } catch (_: Throwable) {}
    }

    /**
     * Gọi ngay khi rút sạc để xoá sạch phiên sạc cũ, xoá mốc Đỉnh W của củ sạc cũ.
     */
    fun onPowerDisconnected(context: Context) {
        forceDisconnected = true
        forceConnected = false
        val nowElapsed = SystemClock.elapsedRealtime()
        forceDisconnectedTimeMs = nowElapsed
        full100ElapsedRealtime = 0L
        hasObservedHardwareMa = false

        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val wasCharging = prefs.getBoolean(KEY_WAS_CHARGING, false)
            if (wasCharging || chargeStartElapsedRealtime > 0L) {
                val elapsedMins = if (chargeStartElapsedRealtime in 1..nowElapsed) {
                    ((nowElapsed - chargeStartElapsedRealtime) / 60000L).toInt().coerceAtLeast(1)
                } else 1
                val peakStr = if (peakSessionWatts >= 2.0) String.format(Locale.US, " • Đỉnh %.1fW", peakSessionWatts) else ""
                lastChargeSummaryText = "⚡ Sạc gần nhất: ${elapsedMins}p$peakStr"
            }
            chargeStartElapsedRealtime = 0L
            peakSessionWatts = 0.0
            prefs.edit()
                .putLong(KEY_CHARGE_START_REALTIME, 0L)
                .putLong(KEY_FULL_100_TIME_REALTIME, 0L)
                .putBoolean(KEY_WAS_CHARGING, false)
                .putFloat(KEY_PEAK_WATTS, 0f)
                .putString(KEY_LAST_SUMMARY, lastChargeSummaryText)
                .apply()
        } catch (_: Throwable) {}
    }

    /**
     * Gọi ngay khi cắm củ sạc mới để khởi tạo phiên sạc độc lập, không mang theo đỉnh W của củ sạc cũ.
     */
    fun onPowerConnected(context: Context) {
        forceConnected = true
        forceDisconnected = false
        val nowElapsed = SystemClock.elapsedRealtime()
        forceConnectedTimeMs = nowElapsed
        chargeStartElapsedRealtime = nowElapsed
        full100ElapsedRealtime = 0L
        hasObservedHardwareMa = false
        peakSessionWatts = 0.0 // Bắt đầu từ 0 cho củ sạc mới!

        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putLong(KEY_CHARGE_START_REALTIME, chargeStartElapsedRealtime)
                .putBoolean(KEY_WAS_CHARGING, true)
                .putFloat(KEY_PEAK_WATTS, 0f)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun readSysfsLong(path: String): Long? {
        if (path in unavailableSysfsPaths) return null
        return try {
            val file = File(path)
            if (file.exists() && file.canRead()) {
                file.readText().trim().toLongOrNull()
            } else {
                unavailableSysfsPaths.add(path)
                null
            }
        } catch (_: Throwable) {
            unavailableSysfsPaths.add(path)
            null
        }
    }

    fun readAvailableRamMb(context: Context): Int {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager ?: return 0
            val mi = android.app.ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            (mi.availMem / (1024L * 1024L)).toInt().coerceAtLeast(0)
        } catch (_: Throwable) {
            0
        }
    }

    fun readCpuThermalCelsius(batteryFallbackC: Double = 0.0, forceFresh: Boolean = false): Double {
        val now = SystemClock.elapsedRealtime()
        if (!forceFresh && lastCpuThermalCelsius > 0.0 && (now - lastCpuThermalReadMs) < 15_000L) {
            return lastCpuThermalCelsius
        }
        val paths = discoveredThermalTempPaths ?: run {
            val matched = mutableListOf<String>()
            try {
                val baseDir = File("/sys/class/thermal")
                val zones = baseDir.listFiles { f -> f.isDirectory && f.name.startsWith("thermal_zone") }
                if (zones != null) {
                    for (z in zones.sortedBy { it.name }.take(20)) {
                        val typeFile = File(z, "type")
                        val typeName = try {
                            if (typeFile.canRead()) typeFile.readText().trim().lowercase(Locale.ROOT) else ""
                        } catch (_: Throwable) { "" }
                        if (typeName.contains("cpu") || typeName.contains("soc") || typeName.contains("tsens") ||
                            typeName.contains("ap") || typeName.contains("gpu") || typeName.contains("skin")
                        ) {
                            val tempFile = File(z, "temp")
                            if (tempFile.canRead()) {
                                matched.add(tempFile.absolutePath)
                                if (matched.size >= 3) break
                            }
                        }
                    }
                }
            } catch (_: Throwable) {}
            discoveredThermalTempPaths = matched
            matched
        }
        var maxTemp = 0.0
        for (p in paths) {
            val raw = readSysfsLong(p) ?: continue
            val c = when {
                raw > 1000L -> raw.toDouble() / 1000.0
                raw > 120L -> raw.toDouble() / 10.0
                else -> raw.toDouble()
            }
            if (c in 18.0..95.0 && c > maxTemp) {
                maxTemp = c
            }
        }
        val result = if (maxTemp > 0.0) maxTemp else batteryFallbackC
        lastCpuThermalCelsius = result
        lastCpuThermalReadMs = now
        return result
    }

    fun saveCoolingTelemetryReport(context: Context, summary: String) {
        try {
            val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(KEY_LAST_COOL_REPORT, summary)
                .putLong(KEY_LAST_COOL_TIME_MS, System.currentTimeMillis())
                .apply()
        } catch (_: Throwable) {}
    }

    fun getRecentCoolingTelemetryReport(context: Context, maxAgeMs: Long = 180_000L): String? {
        return try {
            val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val text = prefs.getString(KEY_LAST_COOL_REPORT, null)?.trim().orEmpty()
            val savedAt = prefs.getLong(KEY_LAST_COOL_TIME_MS, 0L)
            if (text.isNotEmpty() && savedAt > 0L && (System.currentTimeMillis() - savedAt) in 0L..maxAgeMs) {
                text
            } else {
                null
            }
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Đọc trực tiếp thanh ghi Coulomb Counter phần cứng (µAh) từ Fuel Gauge IC (~0.15ms, 0 vòng lặp, 0 tốn pin).
     * Độ mịn gấp ~70-100 lần bước nhảy 1% số nguyên (VD: 1% pin 7200mAh = 72mAh, còn µAh đo tới từng ~1mAh).
     */
    private var chargeCounterReadAtMs = -1_000L
    private var cachedHardwareChargeCounterUah = 0L

    @Synchronized
    fun readHardwareChargeCounterUah(context: Context): Long {
        val now = SystemClock.elapsedRealtime()
        if (now - chargeCounterReadAtMs < 1_000L) return cachedHardwareChargeCounterUah
        cachedHardwareChargeCounterUah = try {
            val manager = context.applicationContext.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val value = manager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) ?: 0
            if (value > 100_000 && value != Int.MIN_VALUE) value.toLong() else 0L
        } catch (_: Exception) {
            0L
        }
        chargeCounterReadAtMs = now
        return cachedHardwareChargeCounterUah
    }

    private fun readDesignCapacityMah(context: Context): Int {
        val cached = cachedDesignCapacityMah
        if (cached > 0) return cached

        val sysfsPaths = listOf(
            "/sys/class/power_supply/battery/charge_full_design",
            "/sys/class/power_supply/battery/charge_full",
            "/sys/class/power_supply/bms/charge_full_design"
        )
        for (path in sysfsPaths) {
            val raw = readSysfsLong(path) ?: continue
            val mah = when {
                raw > 1_000_000L -> (raw / 1000L).toInt() // µAh -> mAh
                raw in 2000L..15000L -> raw.toInt()       // mAh
                else -> 0
            }
            if (mah in 2500..12000) {
                cachedDesignCapacityMah = mah
                return mah
            }
        }
        val fallback = if (!powerProfileLookupFailed) {
            try {
                val powerProfileClass = Class.forName("com.android.internal.os.PowerProfile")
                val constructor = powerProfileClass.getConstructor(Context::class.java)
                val profile = constructor.newInstance(context)
                val cap = (powerProfileClass.getMethod("getBatteryCapacity").invoke(profile) as? Double)?.roundToInt() ?: 5000
                if (cap in 2500..12000) cap else 5000
            } catch (_: Throwable) {
                powerProfileLookupFailed = true
                val model = Build.MODEL.uppercase(Locale.ROOT)
                when {
                    model.contains("BVL") || model.contains("PTP") || model.contains("MAG") -> 5600
                    else -> 5000
                }
            }
        } else {
            val model = Build.MODEL.uppercase(Locale.ROOT)
            when {
                model.contains("BVL") || model.contains("PTP") || model.contains("MAG") -> 5600
                else -> 5000
            }
        }
        cachedDesignCapacityMah = fallback
        return fallback
    }

    private fun readHardwareCurrentMa(bm: BatteryManager?): Int {
        // BatteryManager CURRENT_NOW/CURRENT_AVERAGE are specified in microamps.
        val rawNow = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0
        val rawAvg = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE) ?: 0
        val chosenRaw = if (rawNow != 0 && rawNow != Int.MIN_VALUE) rawNow else if (rawAvg != 0 && rawAvg != Int.MIN_VALUE) rawAvg else 0
        if (chosenRaw != 0) {
            val absVal = abs(chosenRaw.toLong())
            return (absVal / 1000L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        }

        // Standard power_supply current_now nodes use microamps too; avoid guessing by magnitude.
        val microampSysfsPaths = listOf(
            "/sys/class/power_supply/battery/current_now",
            "/sys/devices/platform/huawei_batt_info/current_now",
            "/sys/class/power_supply/usb/current_now"
        )
        for (path in microampSysfsPaths) {
            val v = readSysfsLong(path) ?: continue
            if (v == Long.MIN_VALUE) continue
            val absV = abs(v)
            if (absV > 0L) return (absV / 1000L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        }

        // This vendor-specific ibus node is not part of Android's standard API and may report mA.
        val ibus = readSysfsLong("/sys/class/hw_power/charger/charge_data/ibus")
        if (ibus != null && ibus != Long.MIN_VALUE) {
            val absIbus = abs(ibus)
            if (absIbus > 0L) {
                return (if (absIbus > 25_000L) absIbus / 1000L else absIbus)
                    .coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            }
        }
        return 0
    }

    fun read(
        context: Context,
        stickyIntent: Intent? = null,
        lightweight: Boolean = false
    ): LiveBatteryData {
        if (!lightweight) {
            restorePersistedState(context)
        }
        val intent = stickyIntent ?: try {
            context.applicationContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (_: Throwable) {
            null
        }

        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val batteryPct = if (level >= 0 && scale > 0) {
            ((level * 100f) / scale.toFloat()).roundToInt().coerceIn(0, 100)
        } else {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            (bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 80).coerceIn(0, 100)
        }

        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
            ?: BatteryManager.BATTERY_STATUS_UNKNOWN
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val rawCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL ||
            plugged != 0

        val isCharging = when {
            forceDisconnected -> false
            forceConnected -> true
            else -> rawCharging
        }

        val rawVoltage = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val voltageMv = when {
            rawVoltage > 10000 -> rawVoltage / 1000
            rawVoltage in 1..15 -> rawVoltage * 1000 // Một số máy trả về đơn vị V nguyên
            rawVoltage > 0 -> rawVoltage
            else -> {
                val sysV = readSysfsLong("/sys/class/power_supply/battery/voltage_now") ?: 0L
                if (sysV > 100_000L) (sysV / 1000L).toInt() else 4000
            }
        }
        val voltageV = (voltageMv.toDouble() / 1000.0).coerceIn(3.2, 19.5)

        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val isBatteryTemperatureAvailable = tempTenths in 1..2000
        // Keep a neutral internal fallback for legacy calculations, but expose availability so UI never
        // presents a fabricated 31°C value as a sensor reading.
        val tempCelsius = if (isBatteryTemperatureAvailable) tempTenths / 10.0 else 31.0

        val cycleCount = if (lightweight) {
            0
        } else {
            val nowCycleMs = SystemClock.elapsedRealtime()
            if (cachedCycleCount >= 0 && (nowCycleMs - lastCycleCountReadMs) < 1_800_000L) {
                cachedCycleCount
            } else {
                val measured = try {
                    val rawCycle = if (Build.VERSION.SDK_INT >= 34) {
                        intent?.getIntExtra("android.os.extra.CYCLE_COUNT", -1) ?: -1
                    } else -1
                    if (rawCycle >= 0) {
                        rawCycle
                    } else {
                        val sysCycle = readSysfsLong("/sys/class/power_supply/battery/cycle_count")
                            ?: readSysfsLong("/sys/class/hw_power/charger/charge_data/cycle_count")
                            ?: 0L
                        sysCycle.toInt().coerceAtLeast(0)
                    }
                } catch (_: Throwable) {
                    0
                }
                cachedCycleCount = measured
                lastCycleCountReadMs = nowCycleMs
                measured
            }
        }

        val healthInt = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_GOOD)
            ?: BatteryManager.BATTERY_HEALTH_GOOD
        val healthLabel = when (healthInt) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Tốt (Good)"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Quá nhiệt!"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Chai pin"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Quá áp!"
            BatteryManager.BATTERY_HEALTH_COLD -> "Quá lạnh"
            else -> "Tốt (Ổn định)"
        }

        val pluggedTypeLabel = when {
            !isCharging -> "Đang xả pin"
            plugged and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0 -> "Sạc Không Dây Qi"
            plugged and BatteryManager.BATTERY_PLUGGED_AC != 0 -> "Củ sạc AC / SuperCharge"
            plugged and BatteryManager.BATTERY_PLUGGED_USB != 0 -> "Cổng USB / PD"
            else -> "Nguồn sạc trực tiếp"
        }

        val rawTech = if (lightweight) "" else intent?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY).orEmpty().trim()
        val technology = if (rawTech.isNotBlank()) rawTech else "Li-SiC"

        // Ở chế độ siêu nhẹ (Widget MH chính): khi KHÔNG sạc bỏ qua hoàn toàn đọc dòng phần cứng / sysfs / charge counter
        val bm = if (!lightweight || isCharging) {
            context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        } else {
            null
        }
        val measuredMa = if (!lightweight || isCharging) readHardwareCurrentMa(bm) else 0
        val chargeCounterUah = readHardwareChargeCounterUah(context)

        val designCapacityMah = readDesignCapacityMah(context)
        val remainingCapacityMah = if (lightweight) {
            ((designCapacityMah * batteryPct) / 100.0).roundToInt().coerceIn(50, designCapacityMah)
        } else {
            val rawCounterUah = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) ?: 0
            if (rawCounterUah > 100_000) {
                (rawCounterUah / 1000).coerceIn(50, designCapacityMah)
            } else {
                ((designCapacityMah * batteryPct) / 100.0).roundToInt().coerceIn(50, designCapacityMah)
            }
        }

        val nowElapsed = SystemClock.elapsedRealtime()

        // 1. Quản lý thời gian từ lúc chạm mốc 100%
        val elapsedFullMs = if (isCharging && batteryPct >= 100) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            var full100Time = full100ElapsedRealtime
            if (full100Time <= 0L || full100Time > nowElapsed) {
                full100Time = prefs.getLong(KEY_FULL_100_TIME_REALTIME, 0L)
                if (full100Time <= 0L || full100Time > nowElapsed) {
                    full100Time = nowElapsed
                    prefs.edit().putLong(KEY_FULL_100_TIME_REALTIME, full100Time).apply()
                }
                full100ElapsedRealtime = full100Time
            }
            (nowElapsed - full100Time).coerceAtLeast(0L)
        } else {
            if (full100ElapsedRealtime > 0L) {
                full100ElapsedRealtime = 0L
                try {
                    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit().putLong(KEY_FULL_100_TIME_REALTIME, 0L).apply()
                } catch (_: Throwable) {}
            }
            0L
        }

        val remTrickleMs = (SATURATION_TRICKLE_MS - elapsedFullMs).coerceAtLeast(0L)
        val saturationRemainingMins = if (isCharging && batteryPct >= 100) {
            ((remTrickleMs + 59999L) / 60000L).toInt().coerceIn(0, SATURATION_TRICKLE_MINUTES)
        } else {
            0
        }

        val isStatusFull = (status == BatteryManager.BATTERY_STATUS_FULL)
        if (measuredMa > 0) {
            hasObservedHardwareMa = true
        }

        // 2. Tính toán dòng thực tế (mA), công suất sạc (W) và trạng thái bão hòa thực tế (isFullySaturated)
        // CƠ CHẾ: Nạp tiếp đến khi dòng sạc đo được giảm về mức <= 1.0W (thay vì 0W vì máy ở chế độ ngủ/standby vẫn tiêu thụ ~0.5W - 1.0W nuôi bo mạch).
        // Nếu dòng sạc vẫn còn > 1.0W (1.5W, 2W, 3W...) thì VẪN TIẾP TỤC SẠC cho cell pin hấp thụ no ion thực sự.
        val (effectiveMa, currentWatts, isFullySaturated) = if (!isCharging) {
            val eff = if (measuredMa in 40..4500) measuredMa else 285
            Triple(eff, 0.0, false)
        } else if (batteryPct >= 100) {
            val effMa = if (measuredMa > 0) measuredMa else if (isStatusFull) 180 else 320
            val rawWatts = (effMa.toDouble() / 1000.0) * voltageV
            val roundedWatts = ((rawWatts * 10.0).roundToInt() / 10.0)

            // Ngưỡng bão hòa thực tế: công suất sạc giảm về <= 1.0W (hoặc dòng đo được <= 235mA @ ~4.3V)
            val isCurrentAtOrBelowOneWatt = if (hasObservedHardwareMa) {
                // Máy có cảm biến dòng: công suất đo được <= 1.0W hoặc dòng <= 235mA (hoặc hệ thống báo FULL và công suất <= 1.2W)
                (rawWatts <= 1.05) || (effMa <= 235) || (isStatusFull && (rawWatts <= 1.25 || effMa <= 280))
            } else {
                // Máy không có cảm biến dòng phần cứng: dựa vào tín hiệu BATTERY_STATUS_FULL từ kernel hoặc ngâm tối thiểu 15-20p
                isStatusFull || (elapsedFullMs >= 20 * 60 * 1000L)
            }

            if (isCurrentAtOrBelowOneWatt) {
                // DÒNG ĐIỆN ĐÃ VỀ <= 1W: Cell pin đã thực sự bão hòa 100% dung lượng hóa học!
                val satWatts = roundedWatts.coerceIn(0.0, 1.0)
                Triple(effMa, satWatts, true)
            } else {
                // DÒNG ĐIỆN VẪN CÒN > 1W: Tiếp tục nạp bù ion cho đầy thực sự!
                val activeWatts = roundedWatts.coerceAtLeast(1.1)
                Triple(effMa, activeWatts, false)
            }
        } else {
            val eff = if (measuredMa >= 120) measuredMa else if (plugged == BatteryManager.BATTERY_PLUGGED_USB) 950 else 1800
            val calcWatts = (eff.toDouble() / 1000.0) * voltageV
            val watts = when {
                calcWatts >= 1.0 -> calcWatts.coerceAtMost(100.0)
                plugged == BatteryManager.BATTERY_PLUGGED_AC -> 10.0
                plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS -> 7.5
                else -> 5.0
            }
            Triple(eff, watts, false)
        }

        val calculatedWatts = (effectiveMa.toDouble() / 1000.0) * voltageV

        val dischargingWatts = if (!isCharging) {
            calculatedWatts.coerceIn(0.6, 18.0)
        } else {
            0.0
        }

        val minutesTo100 = if (!isCharging || batteryPct >= 100) 0 else {
            val remainingPct = (100 - batteryPct).coerceAtLeast(1)
            val ratePerPct = when {
                currentWatts >= 40.0 -> 0.52
                currentWatts >= 22.0 -> 0.85
                currentWatts >= 12.0 -> 1.25
                else -> 1.85
            }
            (remainingPct * ratePerPct).roundToInt().coerceAtLeast(1)
        }
        val minutesToFull = when {
            !isCharging -> 0
            batteryPct >= 100 && isFullySaturated -> 0
            batteryPct >= 100 -> saturationRemainingMins.coerceAtLeast(1)
            else -> minutesTo100 + SATURATION_TRICKLE_MINUTES
        }

        val speedTitle = when {
            !isCharging -> "🔋 Đang dùng Pin"
            batteryPct >= 100 && !isFullySaturated -> {
                if (saturationRemainingMins > 0) {
                    "⚡ Sạc Ngâm Bù Ion 100%"
                } else {
                    String.format(Locale.US, "⚡ Sạc Bù Ion (%.1fW)", currentWatts)
                }
            }
            batteryPct >= 100 && isFullySaturated -> "✅ Đã Sạc No 100% Thực Tế"
            currentWatts >= 35.0 -> "🚀 Sạc Siêu Nhanh Max"
            currentWatts >= 18.0 -> "⚡ Sạc Nhanh SuperCharge"
            else -> "🔌 Đang sạc tiêu chuẩn"
        }

        val speedSubtitle = when {
            !isCharging -> String.format(Locale.US, "Tiêu thụ: -%dmA (~%.1fW)", effectiveMa, dischargingWatts)
            batteryPct >= 100 && !isFullySaturated -> {
                if (saturationRemainingMins > 0) {
                    String.format(Locale.US, "Nạp bù ion (~%dp • +%dmA ~%.1fW • Chờ dòng về ≤ 1W)", saturationRemainingMins, effectiveMa, currentWatts)
                } else {
                    String.format(Locale.US, "Dòng vào còn +%dmA (~%.1fW) • Tiếp tục sạc đến khi về ≤ 1W", effectiveMa, currentWatts)
                }
            }
            batteryPct >= 100 && isFullySaturated -> String.format(Locale.US, "Dòng sạc đã về ≤ 1W (%.1fW) • Đã ngắt dòng an toàn, hãy rút sạc", currentWatts)
            else -> String.format(Locale.US, "+%dmA • %.2fV • %s", effectiveMa, voltageV, pluggedTypeLabel)
        }

        // Ước tính thời gian sáng màn hình (Screen-On) & thời gian chờ (Standby) theo đúng dung lượng pin thực (VD: 5000mAh -> ~9h40p, 7200mAh -> ~13h50p)
        val capacityRatio = (designCapacityMah.coerceIn(2500, 12000) / 5000.0)
        val totalActiveMinutes = (batteryPct * 5.8 * capacityRatio).roundToInt().coerceIn(0, 20 * 60)
        val estimatedScreenOnHours = totalActiveMinutes / 60
        val estimatedScreenOnMins = totalActiveMinutes % 60
        val estimatedStandbyHours = ((batteryPct * 0.46 * capacityRatio).roundToInt()).coerceIn(1, 96)

        // Chỉ cập nhật trạng thái phiên sạc & đọc cảm biến CPU/tên máy ở chế độ đầy đủ (Widget nhẹ bỏ qua để 0 tốn I/O & 0 đọc sysfs thermal)
        if (!lightweight) {
            try {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val wasCharging = prefs.getBoolean(KEY_WAS_CHARGING, false)
                val nowElapsed = SystemClock.elapsedRealtime()

                if (isCharging) {
                    if (!wasCharging || chargeStartElapsedRealtime <= 0L || chargeStartElapsedRealtime > nowElapsed || peakSessionWatts <= 0.0) {
                        chargeStartElapsedRealtime = nowElapsed
                        peakSessionWatts = currentWatts
                        prefs.edit()
                            .putLong(KEY_CHARGE_START_REALTIME, chargeStartElapsedRealtime)
                            .putBoolean(KEY_WAS_CHARGING, true)
                            .putFloat(KEY_PEAK_WATTS, peakSessionWatts.toFloat())
                            .apply()
                    } else if (currentWatts > peakSessionWatts) {
                        val prevSaved = peakSessionWatts
                        peakSessionWatts = currentWatts
                        if (currentWatts - prevSaved >= 0.4) {
                            prefs.edit()
                                .putFloat(KEY_PEAK_WATTS, peakSessionWatts.toFloat())
                                .apply()
                        }
                    }
                } else {
                    if (wasCharging || chargeStartElapsedRealtime != 0L || peakSessionWatts != 0.0) {
                        if (wasCharging) {
                            val elapsedMins = if (chargeStartElapsedRealtime in 1..nowElapsed) {
                                ((nowElapsed - chargeStartElapsedRealtime) / 60000L).toInt().coerceAtLeast(1)
                            } else 1
                            val peakStr = if (peakSessionWatts >= 2.0) String.format(Locale.US, " • Đỉnh %.1fW", peakSessionWatts) else ""
                            lastChargeSummaryText = "⚡ Sạc gần nhất: ${elapsedMins}p (lên ${batteryPct}%$peakStr)"
                        }
                        chargeStartElapsedRealtime = 0L
                        peakSessionWatts = 0.0
                        prefs.edit()
                            .putLong(KEY_CHARGE_START_REALTIME, 0L)
                            .putBoolean(KEY_WAS_CHARGING, false)
                            .putFloat(KEY_PEAK_WATTS, 0f)
                            .putString(KEY_LAST_SUMMARY, lastChargeSummaryText)
                            .apply()
                    }
                }
            } catch (_: Throwable) {}
        }

        val phoneDisplayName = if (lightweight) "" else MagicLiveActionExecutor.getCommercialDeviceName(context)
        val cpuThermalC = if (lightweight) tempCelsius else readCpuThermalCelsius(tempCelsius)

        val result = LiveBatteryData(
            batteryPct = batteryPct,
            isCharging = isCharging,
            currentWatts = currentWatts,
            dischargingWatts = dischargingWatts,
            peakSessionWatts = peakSessionWatts.coerceAtLeast(currentWatts),
            currentMa = effectiveMa,
            voltageV = voltageV,
            tempCelsius = tempCelsius,
            cycleCount = cycleCount,
            minutesToFull = minutesToFull,
            minutesTo100 = minutesTo100,
            speedTitle = speedTitle,
            speedSubtitle = speedSubtitle,
            phoneDisplayName = phoneDisplayName,
            healthLabel = healthLabel,
            pluggedTypeLabel = pluggedTypeLabel,
            technology = technology,
            designCapacityMah = designCapacityMah,
            remainingCapacityMah = remainingCapacityMah,
            estimatedScreenOnHours = estimatedScreenOnHours,
            estimatedScreenOnMins = estimatedScreenOnMins,
            estimatedStandbyHours = estimatedStandbyHours,
            cpuThermalCelsius = cpuThermalC,
            chargeCounterUah = chargeCounterUah,
            isFullySaturated = isFullySaturated,
            saturationRemainingMinutes = saturationRemainingMins,
            isBatteryTemperatureAvailable = isBatteryTemperatureAvailable
        )
        lastReadSnapshot = result
        return result
    }
}
