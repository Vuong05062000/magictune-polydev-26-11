package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalMinimumInteractiveComponentSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.LogItem
import com.example.data.LogType
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicPurple
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun TerminalBottomSheet(
    logs: List<LogItem>,
    onDismiss: () -> Unit,
    onClearLogs: () -> Unit,
    onRunCommand: (String) -> Unit,
    onCancelOldCommands: () -> Unit = {},
    onOpenCrashReport: (() -> Unit)? = null,
    onOpenPerformanceReport: (() -> Unit)? = null
) {
    var commandInput by remember { mutableStateOf("") }
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val lazyListState = rememberLazyListState()
    val chipScrollState = rememberScrollState()

    val redErrorPairs = remember(logs) {
        val pairs = mutableListOf<Pair<String, String>>()
        var lastCmd = ""
        for (item in logs) {
            val msg = item.message.trim()
            if (item.type == LogType.COMMAND || msg.startsWith("> ") || msg.startsWith("$ ")) {
                lastCmd = msg.removePrefix("> ").removePrefix("$ ").trim()
            } else if (item.type == LogType.ERROR) {
                val bracketCmd = Regex("""\[([^\]]+)]""").find(msg)?.groupValues?.getOrNull(1)?.trim().orEmpty()
                val effectiveCmd = bracketCmd.ifBlank { lastCmd.ifBlank { "ADB_SHELL_CMD" } }
                pairs.add(effectiveCmd to msg)
            }
        }
        pairs
    }

    // Auto-scroll to bottom when new logs arrive
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            try {
                lazyListState.animateScrollToItem(logs.size - 1)
            } catch (_: Exception) {}
        }
    }

    val quickCommands = listOf(
        "adb devices",
        "pm list packages -3",
        "settings get global adb_enabled",
        "dumpsys battery",
        "getprop ro.build.version.release",
        "wm density",
        "pm list packages -d"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        // Căn giữa màn hình hoàn hảo, có khoảng đệm trên/dưới và phím điều hướng hệ thống
        Box(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 12.dp, vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            // Dùng gần toàn bộ chiều cao khả dụng để vùng console không ép các nút xuống ngoài màn hình.
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.92f),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF070B14)), // SOLID OPAQUE DARK
                border = BorderStroke(1.5.dp, MagicCyan.copy(alpha = 0.75f))
            ) {
                CompositionLocalProvider(LocalMinimumInteractiveComponentSize provides 0.dp) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                    // Header Bar với tiêu đề to rõ + Badge trạng thái + Nút Đóng X
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(RoundedCornerShape(7.dp))
                                    .background(MagicCyan.copy(alpha = 0.2f))
                                    .border(1.dp, MagicCyan, RoundedCornerShape(7.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Terminal,
                                    contentDescription = null,
                                    tint = MagicCyan,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "TRUNG TÂM TERMINAL ADB",
                                        color = Color.White,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MagicEmerald.copy(alpha = 0.25f))
                                            .border(1.dp, MagicEmerald, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 5.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = "● Shell Active",
                                            color = MagicEmeraldLight,
                                            fontSize = 8.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Text(
                                    text = "Bảng thực thi câu lệnh ADB & Theo dõi Log hệ thống",
                                    color = MagicCyanLight,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Normal
                                )
                            }
                        }

                        // Nút Đóng X (-40% chiều cao/kích thước)
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF1E293B))
                                .border(1.dp, MagicBorder, RoundedCornerShape(6.dp))
                                .clickable { onDismiss() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Đóng",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    // Thanh gợi ý lệnh nhanh (Quick Command Chips: giảm chiều cao -40%)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(chipScrollState),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        quickCommands.forEach { cmdText ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF0F172A))
                                    .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                    .clickable {
                                        commandInput = cmdText
                                        onRunCommand(cmdText)
                                    }
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(10.dp))
                                    Text(text = cmdText, color = MagicCyanLight, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Cửa sổ Console Hacker Terminal (100% Solid Black Box - Mở rộng tối đa chiều cao để hiển thị nhiều dòng mã lệnh hơn)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = true)
                            .heightIn(min = 96.dp, max = 520.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.Black), // SOLID OPAQUE BLACK
                        border = BorderStroke(1.2.dp, MagicBorder)
                    ) {
                        Box(modifier = Modifier.padding(8.dp)) {
                            if (logs.isEmpty()) {
                                Box(
                                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "Sẵn sàng nhận câu lệnh shell...\nVí dụ: adb devices, pm list packages, getprop",
                                        color = TextMuted,
                                        fontSize = 11.5.sp,
                                        fontFamily = FontFamily.Monospace,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                LazyColumn(
                                    state = lazyListState,
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    items(logs, key = { it.id }) { entry ->
                                        val (textColor, prefix) = when (entry.type) {
                                            LogType.COMMAND -> Pair(MagicCyanLight, "❯ ")
                                            LogType.SUCCESS -> Pair(MagicEmeraldLight, "✔ ")
                                            LogType.ERROR -> Pair(Color(0xFFFF6B6B), "✖ ")
                                            LogType.INFO -> Pair(Color.White.copy(alpha = 0.9f), "ℹ ")
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text(
                                                text = entry.timestamp,
                                                color = TextMuted,
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = "$prefix${entry.message}",
                                                color = textColor,
                                                fontSize = 10.5.sp,
                                                fontFamily = FontFamily.Monospace,
                                                lineHeight = 14.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Ô nhập liệu Lệnh ADB với tiền tố >$ (-40% chiều cao: 48dp -> 28dp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black)
                                .border(1.dp, if (commandInput.isNotBlank()) MagicCyan else MagicBorder, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Text(text = ">$", color = MagicEmerald, fontSize = 11.5.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black)
                                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                                    if (commandInput.isEmpty()) {
                                        Text(
                                            text = "Nhập lệnh ADB shell...",
                                            color = TextMuted,
                                            fontSize = 10.5.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    BasicTextField(
                                        value = commandInput,
                                        onValueChange = { commandInput = it },
                                        singleLine = true,
                                        cursorBrush = SolidColor(MagicCyan),
                                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                                        keyboardActions = KeyboardActions(
                                            onGo = {
                                                if (commandInput.isNotBlank()) {
                                                    onRunCommand(commandInput.trim())
                                                    commandInput = ""
                                                    focusManager.clearFocus()
                                                }
                                            }
                                        ),
                                        textStyle = TextStyle(color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                if (commandInput.isNotBlank()) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Xóa",
                                        tint = Color.White,
                                        modifier = Modifier.size(13.dp).clickable { commandInput = "" }
                                    )
                                }
                            }
                        }

                        // Nút Chạy Lệnh (-40% chiều cao: 48dp -> 28dp)
                        Button(
                            onClick = {
                                if (commandInput.isNotBlank()) {
                                    onRunCommand(commandInput.trim())
                                    commandInput = ""
                                    focusManager.clearFocus()
                                }
                            },
                            enabled = commandInput.isNotBlank(),
                            modifier = Modifier.height(28.dp),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(text = "Chạy", fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                    }

                    // Thanh công cụ Copy Nhanh Lệnh Lỗi Đỏ (-40% chiều cao: 40dp -> 24dp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = {
                                if (redErrorPairs.isEmpty()) {
                                    Toast.makeText(context, "🎉 Hiện không có dòng lệnh lỗi đỏ nào trong Hộp Lệnh ADB!", Toast.LENGTH_SHORT).show()
                                } else {
                                    val devId = com.example.core.license.LicenseManager.getDeviceId(context)
                                    val reportText = buildString {
                                        appendLine("=== BÁO CÁO LỆNH LỖI ĐỎ ADB (${redErrorPairs.size} LỖI) ===")
                                        appendLine("Thiết bị: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} | ID: $devId")
                                        appendLine("Android: ${android.os.Build.VERSION.RELEASE}")
                                        appendLine("----------------------------------------")
                                        redErrorPairs.forEachIndexed { idx, (cmd, err) ->
                                            appendLine("${idx + 1}. Lệnh: $cmd")
                                            appendLine("   Lỗi: $err")
                                        }
                                    }.trim()
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                    if (clipboard != null) {
                                        clipboard.setPrimaryClip(ClipData.newPlainText("ADB Red Error Logs", reportText))
                                        Toast.makeText(
                                            context,
                                            "📋 Đã sao chép toàn bộ ${redErrorPairs.size} lệnh lỗi đỏ!",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    } else {
                                        Toast.makeText(context, "Không truy cập được Clipboard", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(26.dp),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF2A1215),
                                contentColor = Color(0xFFFF6B6B)
                            ),
                            border = BorderStroke(1.dp, Color(0xFFFF6B6B).copy(alpha = 0.7f))
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(11.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Copy Lỗi Đỏ (${redErrorPairs.size})",
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    // Hàng nút chức năng dưới cùng: Dừng tiến trình + Xóa Log + Hộp Đen (-40% chiều cao: 40dp -> 24dp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = onCancelOldCommands,
                            modifier = Modifier.weight(1f).height(24.dp),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = MagicAmber),
                            border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
                        ) {
                            Icon(imageVector = Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(11.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(text = "Hủy Tiến Trình", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onClearLogs,
                            modifier = Modifier.weight(1f).height(24.dp),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = Color(0xFFFF6B6B)),
                            border = BorderStroke(1.dp, Color(0xFFFF6B6B).copy(alpha = 0.5f))
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(11.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(text = "Xóa Log", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                        }

                        if (onOpenCrashReport != null) {
                            Button(
                                onClick = onOpenCrashReport,
                                modifier = Modifier.weight(0.9f).height(24.dp),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A1215), contentColor = Color(0xFFFF8585)),
                                border = BorderStroke(1.dp, Color(0xFFFF8585).copy(alpha = 0.6f))
                            ) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(11.dp), tint = Color(0xFFFF8585))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(text = "Hộp Đen", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (onOpenPerformanceReport != null) {
                            Button(
                                onClick = onOpenPerformanceReport,
                                modifier = Modifier.weight(1f).height(24.dp),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF102B2A), contentColor = MagicCyan),
                                border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                            ) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(11.dp), tint = MagicCyan)
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(text = "Nhiệt & Pin", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
}
