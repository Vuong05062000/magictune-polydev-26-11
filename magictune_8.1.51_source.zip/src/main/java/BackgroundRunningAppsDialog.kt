package com.example.ui.components



import android.content.Intent

import android.net.Uri

import android.provider.Settings

import android.widget.Toast

import androidx.activity.compose.BackHandler

import androidx.compose.animation.AnimatedVisibility

import androidx.compose.animation.expandVertically

import androidx.compose.animation.fadeIn

import androidx.compose.animation.fadeOut

import androidx.compose.animation.shrinkVertically

import androidx.compose.foundation.BorderStroke

import androidx.compose.foundation.background

import androidx.compose.foundation.border

import androidx.compose.foundation.clickable

import androidx.compose.foundation.horizontalScroll

import androidx.compose.foundation.layout.Arrangement

import androidx.compose.foundation.layout.Box

import androidx.compose.foundation.layout.Column

import androidx.compose.foundation.layout.ExperimentalLayoutApi

import androidx.compose.foundation.layout.FlowRow

import androidx.compose.foundation.layout.PaddingValues

import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight

import androidx.compose.foundation.layout.Spacer

import androidx.compose.foundation.layout.defaultMinSize

import androidx.compose.foundation.layout.fillMaxHeight

import androidx.compose.foundation.layout.fillMaxSize

import androidx.compose.foundation.layout.fillMaxWidth

import androidx.compose.foundation.layout.height

import androidx.compose.foundation.layout.heightIn

import androidx.compose.foundation.layout.padding

import androidx.compose.foundation.layout.size

import androidx.compose.foundation.layout.width

import androidx.compose.foundation.lazy.LazyColumn

import androidx.compose.foundation.lazy.items

import androidx.compose.foundation.lazy.itemsIndexed

import androidx.compose.foundation.lazy.rememberLazyListState

import androidx.compose.foundation.rememberScrollState

import androidx.compose.runtime.snapshotFlow

import kotlinx.coroutines.Dispatchers

import kotlinx.coroutines.flow.first

import kotlinx.coroutines.withContext

import androidx.compose.foundation.shape.CircleShape

import androidx.compose.foundation.shape.RoundedCornerShape

import androidx.compose.material.icons.Icons

import androidx.compose.material.icons.automirrored.filled.ArrowBack

import androidx.compose.material.icons.filled.BatteryAlert

import androidx.compose.material.icons.filled.BatteryChargingFull

import androidx.compose.material.icons.filled.Bolt

import androidx.compose.material.icons.filled.Clear

import androidx.compose.material.icons.filled.Close

import androidx.compose.material.icons.filled.DeleteSweep

import androidx.compose.material.icons.filled.ExpandLess

import androidx.compose.material.icons.filled.ExpandMore

import androidx.compose.material.icons.filled.Memory

import androidx.compose.material.icons.filled.NotificationsActive

import androidx.compose.material.icons.filled.Refresh

import androidx.compose.material.icons.filled.Search

import androidx.compose.material.icons.filled.Settings

import androidx.compose.material.icons.filled.Shield

import androidx.compose.material.icons.filled.Stop

import androidx.compose.material.icons.filled.Warning

import androidx.compose.material3.Button

import androidx.compose.material3.ButtonDefaults

import androidx.compose.material3.Card

import androidx.compose.material3.CardDefaults

import androidx.compose.material3.CircularProgressIndicator

import androidx.compose.material3.FilterChip

import androidx.compose.material3.FilterChipDefaults

import androidx.compose.material3.HorizontalDivider

import androidx.compose.material3.Icon

import androidx.compose.material3.IconButton

import androidx.compose.material3.LinearProgressIndicator

import androidx.compose.material3.OutlinedButton

import androidx.compose.material3.OutlinedTextField

import androidx.compose.material3.OutlinedTextFieldDefaults

import androidx.compose.material3.Surface

import androidx.compose.material3.Text

import androidx.compose.runtime.Composable

import androidx.compose.runtime.LaunchedEffect

import androidx.compose.runtime.getValue

import androidx.compose.runtime.mutableStateOf

import androidx.compose.runtime.remember

import androidx.compose.runtime.rememberCoroutineScope

import androidx.compose.runtime.setValue

import androidx.compose.ui.Alignment

import androidx.compose.ui.Modifier

import androidx.compose.ui.draw.clip

import androidx.compose.ui.graphics.Brush

import androidx.compose.ui.graphics.Color

import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.platform.testTag

import androidx.compose.ui.text.font.FontWeight

import androidx.compose.ui.text.style.TextOverflow

import androidx.compose.ui.unit.dp

import androidx.compose.ui.unit.sp

import com.example.core.permission.AppPermissionChecker

import com.example.core.widget.AppIconImage

import com.example.core.widget.BackgroundAppDrainEntry

import com.example.core.widget.BackgroundDrainInspector

import com.example.core.widget.BackgroundDrainScanReport

import com.example.ui.theme.MagicAmber

import com.example.ui.theme.MagicAmberLight

import com.example.ui.theme.MagicBorder

import com.example.ui.theme.MagicCyan

import com.example.ui.theme.MagicCyanLight

import com.example.ui.theme.MagicEmerald

import com.example.ui.theme.MagicEmeraldLight

import com.example.ui.theme.MagicPurple

import com.example.ui.theme.MagicPurpleLight

import com.example.ui.theme.MagicRose

import com.example.ui.theme.MagicRoseLight

import com.example.ui.theme.MagicSurfaceCard

import com.example.ui.theme.MagicSurfaceDark

import com.example.ui.theme.TextMuted

import com.example.ui.theme.TextSecondary

import com.example.core.ai.AiAutopilotConfig

import com.example.core.ai.AiBatteryDoctorEngine

import com.example.core.ai.AiPowerAutopilotManager

import com.example.core.ai.AiUltraPowerProfile

import com.example.core.ai.DrainRateAnalytics

import com.example.core.ai.PowerExecutionResult

import kotlinx.coroutines.delay

import kotlinx.coroutines.launch

import java.util.Locale



private enum class DrainFilterTab(val label: String) {

    ALL("Tất cả"),

    HIGH_DRAIN("🔥 Tải nặng"),

    SERVICES_NET("⚙️ Dịch vụ nền"),

    USER_APPS("📦 App cài thêm"),

    PROTECTED("🛡️ VIP Bảo vệ")

}



private enum class DrainSortMode(val label: String) {

    SCORE("⚡ Mức tải"),

    RAM("🧠 RAM")

}



@OptIn(ExperimentalLayoutApi::class)

@Composable

fun BackgroundDrainMonitorScreen(

    onNavigateBack: () -> Unit,

    onOpenWlanConnection: () -> Unit = {}

) {

    val context = LocalContext.current

    val coroutineScope = rememberCoroutineScope()

    val listState = rememberLazyListState()

    // Tuyệt đối chỉ đọc RAM @Volatile trong remember (0ms), đẩy đọc ROM JSON & Debug.getPss() sang Dispatchers.IO

    val initialRamReport = remember { BackgroundDrainInspector.peekRamCachedReportOnly() }

    var report by remember { mutableStateOf(initialRamReport) }

    var isScanning by remember { mutableStateOf(initialRamReport == null) }

    var isRefreshingInBg by remember { mutableStateOf(false) }

    var isWorkingAction by remember { mutableStateOf(false) }

    var isUpdatingAutopilot by remember { mutableStateOf(false) }

    var lastActionBanner by remember { mutableStateOf<String?>(null) }



    var searchQuery by remember { mutableStateOf("") }

    var selectedFilter by remember { mutableStateOf(DrainFilterTab.ALL) }

    var selectedSort by remember { mutableStateOf(DrainSortMode.SCORE) }

    var expandedPkg by remember { mutableStateOf<String?>(null) }

    var showAllDrainEntries by remember { mutableStateOf(false) }

    // Chỉ đo điện năng nội bộ MagicTune (Ô #43) khi người dùng CHỦ ĐỘNG bấm mở thẻ (tránh gọi Debug.getPss() mỗi lần mở Tab 7)

    var selfPowerSnapshot by remember {

        mutableStateOf<com.example.core.perf.MagicTuneSelfPowerGovernor.SelfPowerSnapshot?>(null)

    }



    // Trạng thái Siêu Tiết Kiệm Pin & Tự Động 24/7 + Cảm biến Fuel Gauge µAh tức thì (0ms từ RAM cache)

    var liveBatterySnapshot by remember {

        mutableStateOf(com.example.core.widget.BatteryInfoReader.peekLastSnapshot())

    }

    var activeUltraPowerProfile by remember { mutableStateOf(AiUltraPowerProfile.NONE) }

    var autopilotConfig by remember { mutableStateOf(AiAutopilotConfig()) }

    var drainAnalytics by remember {

        mutableStateOf(AiPowerAutopilotManager.peekRamCachedAnalyticsOnly())

    }

    var isExecutingAiPower by remember { mutableStateOf(false) }

    var executingAiLabel by remember { mutableStateOf<String?>(null) }

    var lastAiExecutionResult by remember { mutableStateOf<PowerExecutionResult?>(null) }



    BackHandler {

        onNavigateBack()

    }



    suspend fun refreshAutopilotAndAnalytics(forceSample: Boolean = false) {

        try {

            val profileFallback = activeUltraPowerProfile

            val (freshBatt, triple) = withContext(Dispatchers.IO) {

                val b = try { com.example.core.widget.BatteryInfoReader.read(context, lightweight = true) } catch (_: Throwable) { null }

                if (forceSample && b != null) {

                    try { AiPowerAutopilotManager.recordLiveFuelGaugeCheckpoint(context, force = true, preloadedBattery = b) } catch (_: Throwable) {}

                }

                val c = try { AiPowerAutopilotManager.getConfig(context) } catch (_: Throwable) { AiAutopilotConfig() }

                val a = try {

                    AiPowerAutopilotManager.getDrainRateAnalytics(context, lightweightRead = true, preloadedBattery = b)

                } catch (_: Throwable) { null }

                val p = try { AiBatteryDoctorEngine.getActiveUltraPowerProfile(context) } catch (_: Throwable) { profileFallback }

                b to Triple(c, a, p)

            }

            val (cfg, analytics, profileNow) = triple

            if (freshBatt != null) liveBatterySnapshot = freshBatt

            autopilotConfig = cfg

            if (analytics != null) drainAnalytics = analytics

            activeUltraPowerProfile = profileNow

        } catch (e: kotlinx.coroutines.CancellationException) {

            throw e

        } catch (_: Throwable) {}

    }



    suspend fun runScanNow(silent: Boolean = false, syncWidgets: Boolean = false) {

        if (isRefreshingInBg) return

        if (!silent && report == null) isScanning = true

        isRefreshingInBg = true

        try {

            // 1. Đọc Fuel Gauge µAh & tốc độ tụt pin tức thì (<2ms) TRƯỚC khi quét tiến trình nền -> nhanh gấp 10 lần!

            refreshAutopilotAndAnalytics(forceSample = !silent)

            // 2. Quét danh sách app chạy ngầm nhẹ song song phía sau

            val res = kotlinx.coroutines.withTimeoutOrNull(4_500L) {

                try {

                    BackgroundDrainInspector.scanBackgroundApps(context, lightweightLiveTick = silent)

                } catch (_: Throwable) {

                    null

                }

            }

            if (res != null) {

                report = res

                if (lastActionBanner?.startsWith("⚠️ Quét") == true) lastActionBanner = null

            } else {

                lastActionBanner = "⚠️ Quét chưa hoàn tất; đang giữ kết quả cũ. Hãy thử lại khi thiết bị rảnh."

            }

            // 3. Chỉ đồng bộ lại Widget sau khi UI Tab 7 đã ổn định khi người dùng chủ động bấm Làm mới (tránh bão Binder/Bitmap lúc mở lần đầu)

            if (syncWidgets) {

                coroutineScope.launch(Dispatchers.IO) {

                    try {

                        delay(600L)

                        com.example.core.widget.MagicTuneBatteryWidgetProvider.notifyAllWidgetsFast(context)

                        com.example.core.widget.MagicTuneSimpleBatteryWidgetProvider.notifyAllWidgets(context)

                    } catch (_: Throwable) {}

                }

            }

        } catch (e: kotlinx.coroutines.CancellationException) {

            throw e

        } catch (t: Throwable) {

            lastActionBanner = "⚠️ Quét chưa hoàn tất: ${t.localizedMessage ?: "lỗi không xác định"}. Đang giữ kết quả cũ."

        } finally {

            isScanning = false

            isRefreshingInBg = false

        }

    }



    LaunchedEffect(Unit) {

        try {

            // Nhịp 1 (0ms chờ): Đọc Fuel Gauge µAh + RAM cache tốc độ xả + ROM snapshot ngay lập tức (<3ms)

            val (liveBatt, hydrated) = withContext(Dispatchers.IO) {

                val batt = try { com.example.core.widget.BatteryInfoReader.read(context, lightweight = true) } catch (_: Throwable) { null }

                val diskDrain = if (report == null) {

                    try { BackgroundDrainInspector.hydrateCachedReport(context) } catch (_: Throwable) { null }

                } else null

                val savedProfile = try { AiBatteryDoctorEngine.getActiveUltraPowerProfile(context) } catch (_: Throwable) { AiUltraPowerProfile.NONE }

                val savedAutopilot = try { AiPowerAutopilotManager.getConfig(context) } catch (_: Throwable) { AiAutopilotConfig() }

                val savedAnalytics = try {

                    AiPowerAutopilotManager.getDrainRateAnalytics(context, lightweightRead = true, preloadedBattery = batt)

                } catch (_: Throwable) { null }

                batt to Pair(diskDrain to savedProfile, savedAutopilot to savedAnalytics)

            }

            val (diskDrain, savedProfile) = hydrated.first

            val (savedAutopilot, savedAnalytics) = hydrated.second

            if (liveBatt != null) liveBatterySnapshot = liveBatt

            if (diskDrain != null && report == null) {

                report = diskDrain

                isScanning = false

            }

            activeUltraPowerProfile = savedProfile

            autopilotConfig = savedAutopilot

            if (savedAnalytics != null) drainAnalytics = savedAnalytics



            // Nếu RAM vừa quét danh sách app trong 5 phút gần đây -> hiển thị tức thì 0ms, không quét lại làm lag/nóng máy

            if (BackgroundDrainInspector.hasFreshRamReport(300_000L)) {

                isScanning = false

                isRefreshingInBg = false

            } else {

                // Chờ 380ms cho khung hình đầu & hiệu ứng chuyển Tab 7 hoàn tất mượt mà rồi mới quét ngầm danh sách app

                delay(380L)

                runScanNow(silent = report != null, syncWidgets = false)

            }

        } catch (e: kotlinx.coroutines.CancellationException) {

            throw e

        } catch (_: Throwable) {

            isScanning = false

            isRefreshingInBg = false

        }

    }



    val currentReport = report

    Column(

        modifier = Modifier

            .fillMaxSize()

            .background(Color(0xFF060B16))

            .blockInputWhileBusy(isScanning || isRefreshingInBg || isWorkingAction || isExecutingAiPower || isUpdatingAutopilot)

            .testTag("background_drain_dedicated_screen")

    ) {

        // 1. HEADER BAR TRANG CHUYÊN DỤNG

        Row(

            modifier = Modifier

                .fillMaxWidth()

                .background(

                    Brush.horizontalGradient(

                        listOf(Color(0xFF0B1426), Color(0xFF101935), Color(0xFF18112B))

                    )

                )

                .padding(horizontal = 10.dp, vertical = 10.dp),

            horizontalArrangement = Arrangement.SpaceBetween,

            verticalAlignment = Alignment.CenterVertically

        ) {

            IconButton(

                onClick = onNavigateBack,

                modifier = Modifier

                    .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)

                    .testTag("back_from_bg_drain_screen")

            ) {

                Icon(

                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,

                    contentDescription = "Quay lại trang trước",

                    tint = Color.White,

                    modifier = Modifier.size(21.dp)

                )

            }



            Column(

                modifier = Modifier

                    .weight(1f)

                    .padding(end = 6.dp),

                verticalArrangement = Arrangement.spacedBy(2.dp)

            ) {

                Row(

                    verticalAlignment = Alignment.CenterVertically,

                    horizontalArrangement = Arrangement.spacedBy(6.dp)

                ) {

                    Text(

                        text = "🔋 Pin & Soi App Ngầm",

                        color = Color.White,

                        fontSize = 15.sp,

                        fontWeight = FontWeight.Black,

                        maxLines = 1,

                        overflow = TextOverflow.Ellipsis,

                        modifier = Modifier.weight(1f, fill = false)

                    )

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(6.dp))

                            .background(if (currentReport?.isDeepAdbScan == true) MagicEmerald.copy(alpha = 0.22f) else MagicAmber.copy(alpha = 0.22f))

                            .padding(horizontal = 6.dp, vertical = 2.dp)

                    ) {

                        Text(

                            text = if (currentReport?.isDeepAdbScan == true) "SIÊU MÁT" else "CƠ BẢN",

                            color = if (currentReport?.isDeepAdbScan == true) MagicEmeraldLight else MagicAmberLight,

                            fontSize = 9.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                }

                            Text(

                                text = currentReport?.let {

                                    "Chế độ quét nhẹ • ${it.totalBgAppsRunning} app nền (${it.scannedAtLabel})"

                                } ?: "Đang tải danh sách app chạy ngầm...",

                                color = MagicCyanLight,

                                fontSize = 10.sp,

                                fontWeight = FontWeight.SemiBold,

                                maxLines = 1,

                                overflow = TextOverflow.Ellipsis

                            )

                        }



                        IconButton(

                            onClick = {

                                if (!isRefreshingInBg) {

                                    coroutineScope.launch {

                                        try {

                                            runScanNow(silent = false, syncWidgets = true)

                                        } catch (e: kotlinx.coroutines.CancellationException) {

                                            throw e

                                        } catch (_: Throwable) {}

                                    }

                                }

                            },

                            modifier = Modifier

                                .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)

                                .testTag("refresh_bg_drain_screen")

                        ) {

                            Icon(

                                imageVector = Icons.Default.Refresh,

                                contentDescription = "Quét lại app chạy ngầm",

                                tint = MagicCyanLight,

                                modifier = Modifier.size(20.dp)

                            )

                        }

                    }



                    HorizontalDivider(color = MagicBorder.copy(alpha = 0.55f))



                    // 2. NỘI DUNG CHÍNH — Ghi nhớ thống kê 1 lần duy nhất O(N) & debounce tìm kiếm 150ms chống đơ

                    val allEntries = currentReport?.entries.orEmpty()

                    val entryStats = remember(allEntries) {

                        var high = 0

                        var svc = 0

                        var user = 0

                        var prot = 0

                        var stoppable = 0

                        for (e in allEntries) {

                            if (e.isHighDrain) high++

                            if (e.hasActiveService) svc++

                            if (e.isUserApp) user++

                            if (e.isProtected) prot++

                            else if (

                                e.isHighDrain &&

                                e.packageName != context.packageName &&

                                !BackgroundDrainInspector.isSystemFamilyOrManagerApp(e.packageName) &&

                                !BackgroundDrainInspector.isCallingOrMessagingApp(context, e.packageName) &&

                                !BackgroundDrainInspector.isUserWhitelisted(context, e.packageName)

                            ) stoppable++

                        }

                        DrainListPrecomputedStats(

                            countAll = allEntries.size,

                            countHigh = high,

                            countSvc = svc,

                            countUser = user,

                            countProt = prot,

                            stoppableCount = stoppable

                        )

                    }

                    var debouncedSearchQuery by remember { mutableStateOf("") }

                    LaunchedEffect(searchQuery) {

                        if (searchQuery.isNotBlank()) delay(150L)

                        debouncedSearchQuery = searchQuery

                    }

                    val filteredEntries = remember(allEntries, debouncedSearchQuery, selectedFilter, selectedSort) {

                        val q = debouncedSearchQuery.trim().lowercase(Locale.US)

                        val step1 = allEntries.filter { e ->

                            val matchesFilter = when (selectedFilter) {

                                DrainFilterTab.ALL -> true

                                DrainFilterTab.HIGH_DRAIN -> e.isHighDrain

                                DrainFilterTab.SERVICES_NET -> e.hasActiveService

                                DrainFilterTab.USER_APPS -> e.isUserApp

                                DrainFilterTab.PROTECTED -> e.isProtected

                            }

                            val matchesSearch = q.isBlank() ||

                                e.appName.lowercase(Locale.US).contains(q) ||

                                e.packageName.lowercase(Locale.US).contains(q)

                            matchesFilter && matchesSearch

                        }.distinctBy { it.packageName }

                        when (selectedSort) {

                            DrainSortMode.SCORE -> step1.sortedWith(

                                compareByDescending<BackgroundAppDrainEntry> { it.isHighDrain }.thenByDescending { it.drainScore }

                            )

                            DrainSortMode.RAM -> step1.sortedByDescending { it.ramMb }

                        }

                    }

                    val visibleEntries = remember(filteredEntries, showAllDrainEntries, debouncedSearchQuery) {

                        if (showAllDrainEntries || debouncedSearchQuery.isNotBlank() || filteredEntries.size <= 10) {

                            filteredEntries

                        } else {

                            filteredEntries.take(10)

                        }

                    }



                    // Giữ cố định LazyColumn từ khung hình 0 (không gỡ/dựng lại cả cây UI khi nạp lần đầu) để Ô #42 Sáng màn/Tắt màn & Ô #44 hiển thị tức thì, tuyệt đối không văng app

                    LazyColumn(

                        state = listState,

                        modifier = Modifier

                            .fillMaxWidth()

                            .weight(1f),

                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),

                        verticalArrangement = Arrangement.spacedBy(8.dp)

                    ) {

                        // Ô #42: SIÊU TIẾT KIỆM PIN & TỰ ĐỘNG 24/7

                        item(key = "ai_battery_doctor_hero", contentType = "ai_battery_doctor") {

                            AiBatteryDoctorCard(

                                activeProfile = activeUltraPowerProfile,

                                autopilotConfig = autopilotConfig,

                                drainAnalytics = drainAnalytics,

                                isExecutingPowerPlan = isExecutingAiPower,

                                executingLabel = executingAiLabel,

                                lastExecutionResult = lastAiExecutionResult,

                                onActivateProfile = { profile ->

                                    if (!isExecutingAiPower) {

                                        activeUltraPowerProfile = profile

                                        isExecutingAiPower = true

                                        coroutineScope.launch {

                                            executingAiLabel = if (profile == AiUltraPowerProfile.NONE) {

                                                "Đang khôi phục mặc định..."

                                            } else {

                                                "Đang bật ${profile.label}..."

                                            }

                                            try {

                                                val res = AiBatteryDoctorEngine.activateUltraPowerSaverPreset(

                                                    context = context,

                                                    profile = profile,

                                                    drainReport = report

                                                )

                                                lastAiExecutionResult = res

                                                lastActionBanner = res.summary

                                                Toast.makeText(

                                                    context,

                                                    res.summary,

                                                    if (res.success) Toast.LENGTH_SHORT else Toast.LENGTH_LONG

                                                ).show()

                                                refreshAutopilotAndAnalytics()

                                            } catch (e: kotlinx.coroutines.CancellationException) {

                                                throw e

                                            } catch (t: Throwable) {

                                                val errorMsg = "⚠️ Không thể áp dụng ${profile.label}: ${t.localizedMessage ?: "lỗi không xác định"}"

                                                lastActionBanner = errorMsg

                                                Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()

                                                refreshAutopilotAndAnalytics()

                                            } finally {

                                                isExecutingAiPower = false

                                                executingAiLabel = null

                                            }

                                        }

                                    }

                                },

                                onUpdateAutopilotRule = { ruleId, enabled ->

                                    isUpdatingAutopilot = true

                                    coroutineScope.launch {

                                        try {

                                            val updated = withContext(Dispatchers.IO) {

                                                AiPowerAutopilotManager.updateConfig(context) { cur ->

                                                    when (ruleId) {

                                                        "screen_off_doze" -> cur.copy(screenOffDeepDozeEnabled = enabled)

                                                        "night_standby" -> cur.copy(nightUltraStandbyEnabled = enabled)

                                                        "low_batt_survival" -> cur.copy(lowBatterySurvivalEnabled = enabled)

                                                        "thermal_spike" -> cur.copy(thermalSpikeGuardEnabled = false)

                                                        else -> cur

                                                    }

                                                }

                                            }

                                            autopilotConfig = updated

                                            val analytics = withContext(Dispatchers.IO) {

                                                try { AiPowerAutopilotManager.getDrainRateAnalytics(context, lightweightRead = true) } catch (_: Throwable) { drainAnalytics }

                                            }

                                            if (analytics != null) drainAnalytics = analytics

                                            val statusTxt = if (enabled) "Đã bật" else "Đã tắt"

                                            val labelTxt = when (ruleId) {

                                                "screen_off_doze" -> "Ngủ Đông 45s"

                                                "night_standby" -> "Chống Tụt Pin Đêm"

                                                "low_batt_survival" -> "Sinh Tồn ≤20%"

                                                "thermal_spike" -> "Hạ nhiệt tự động nền (đã tắt)"

                                                else -> "Tự Động 24/7"

                                            }

                                            Toast.makeText(context, "$statusTxt $labelTxt", Toast.LENGTH_SHORT).show()

                                        } catch (e: kotlinx.coroutines.CancellationException) {

                                            throw e

                                        } catch (t: Throwable) {

                                            val errorMsg = "⚠️ Không cập nhật được chế độ tự động: ${t.localizedMessage ?: "lỗi không xác định"}"

                                            lastActionBanner = errorMsg

                                            Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()

                                        } finally {

                                            isUpdatingAutopilot = false

                                        }

                                    }

                                },

                                onToggleAllAutopilot = { enableAll ->

                                    isUpdatingAutopilot = true

                                    coroutineScope.launch {

                                        try {

                                            val updated = withContext(Dispatchers.IO) {

                                                if (enableAll) {

                                                    AiPowerAutopilotManager.enableAllRecommendedAutopilot(context)

                                                } else {

                                                    AiPowerAutopilotManager.disableAllAutopilot(context)

                                                }

                                            }

                                            autopilotConfig = updated

                                            refreshAutopilotAndAnalytics()

                                            val msg = if (enableAll) {

                                                "✓ Đã bật 3/3 chế độ Tự Động 24/7"

                                            } else {

                                                "Đã tắt toàn bộ Tự Động 24/7"

                                            }

                                            lastActionBanner = msg

                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

                                        } catch (e: kotlinx.coroutines.CancellationException) {

                                            throw e

                                        } catch (t: Throwable) {

                                            val errorMsg = "⚠️ Không cập nhật được chế độ tự động: ${t.localizedMessage ?: "lỗi không xác định"}"

                                            lastActionBanner = errorMsg

                                            Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()

                                        } finally {

                                            isUpdatingAutopilot = false

                                        }

                                    }

                                }

                            )

                        }



                        // Ô #43: ĐIỀU KHIỂN CHẾ ĐỘ NỀN NỘI BỘ MAGICTUNE (LAZY — 0 ĐO ĐẠC KHI CHƯA BẤM MỞ)

                        item(key = "magictune_self_power_governor", contentType = "self_governor") {

                            MagicTuneSelfPowerGovernorCard(

                                snapshot = selfPowerSnapshot,

                                onRequestLoadSnapshot = {

                                    if (selfPowerSnapshot == null) {

                                        coroutineScope.launch {

                                            try {

                                                val snapLoaded = withContext(Dispatchers.IO) {

                                                    try { com.example.core.perf.MagicTuneSelfPowerGovernor.captureSnapshot(context) } catch (_: Throwable) { null }

                                                }

                                                if (snapLoaded != null) selfPowerSnapshot = snapLoaded

                                            } catch (e: kotlinx.coroutines.CancellationException) {

                                                throw e

                                            } catch (_: Throwable) {}

                                        }

                                    }

                                },

                                onSelectMode = { mode ->

                                    coroutineScope.launch {

                                        try {

                                            val (msg, nextSnap) = withContext(Dispatchers.IO) {

                                                val m = com.example.core.perf.MagicTuneSelfPowerGovernor.applySelfPowerMode(context, mode)

                                                val s = com.example.core.perf.MagicTuneSelfPowerGovernor.captureSnapshot(context)

                                                m to s

                                            }

                                            selfPowerSnapshot = nextSnap

                                            lastActionBanner = msg

                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

                                        } catch (e: kotlinx.coroutines.CancellationException) {

                                            throw e

                                        } catch (_: Throwable) {}

                                    }

                                },

                                onToggleModule = { modId, enable ->

                                    coroutineScope.launch {

                                        try {

                                            val (msg, nextSnap) = withContext(Dispatchers.IO) {

                                                val m = com.example.core.perf.MagicTuneSelfPowerGovernor.toggleSelfModule(context, modId, enable)

                                                val s = com.example.core.perf.MagicTuneSelfPowerGovernor.captureSnapshot(context)

                                                m to s

                                            }

                                            selfPowerSnapshot = nextSnap

                                            lastActionBanner = msg

                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

                                        } catch (e: kotlinx.coroutines.CancellationException) {

                                            throw e

                                        } catch (_: Throwable) {}

                                    }

                                },

                                onHibernateSelfNow = {

                                    coroutineScope.launch {

                                        try {

                                            val (msg, nextSnap) = withContext(Dispatchers.IO) {

                                                val m = com.example.core.perf.MagicTuneSelfPowerGovernor.hibernateSelfBackgroundNow(

                                                    context = context,

                                                    closeFloatingOverlays = false

                                                )

                                                val s = com.example.core.perf.MagicTuneSelfPowerGovernor.captureSnapshot(context)

                                                m to s

                                            }

                                            selfPowerSnapshot = nextSnap

                                            lastActionBanner = msg

                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

                                        } catch (e: kotlinx.coroutines.CancellationException) {

                                            throw e

                                        } catch (_: Throwable) {}

                                    }

                                }

                            )

                        }



                        // Ô #44: TỔNG QUAN PIN, NHIỆT ĐỘ & RAM (CẬP NHẬT TỨC THÌ <2ms TỪ FUEL GAUGE µAh, ĐỒNG BỘ 100% VỚI WIDGET)

                        if (currentReport != null || liveBatterySnapshot != null) {

                            item(key = "telemetry_dashboard", contentType = "dashboard") {

                                TelemetryExecutiveDashboard(

                                    report = currentReport,

                                    liveBattery = liveBatterySnapshot,

                                    drainAnalytics = drainAnalytics,

                                    onRequestUsagePermission = {

                                        AppPermissionChecker.requestUsageStatsPermission(context)

                                    },

                                    onOpenWlanConnection = onOpenWlanConnection

                                )

                            }

                        }



                            // THÔNG BÁO KẾT QUẢ THAO TÁC GẦN NHẤT

                            if (!lastActionBanner.isNullOrBlank()) {

                                item(key = "last_action_banner", contentType = "banner") {

                                    Row(

                                        modifier = Modifier

                                            .fillMaxWidth()

                                            .clip(RoundedCornerShape(10.dp))

                                            .background((if (lastActionBanner?.startsWith("⚠️") == true) MagicAmber else MagicEmerald).copy(alpha = 0.14f))

                                            .border(1.dp, (if (lastActionBanner?.startsWith("⚠️") == true) MagicAmber else MagicEmerald).copy(alpha = 0.5f), RoundedCornerShape(10.dp))

                                            .padding(horizontal = 10.dp, vertical = 8.dp),

                                        verticalAlignment = Alignment.CenterVertically,

                                        horizontalArrangement = Arrangement.SpaceBetween

                                    ) {

                                        Text(

                                            text = lastActionBanner.orEmpty(),

                                            color = if (lastActionBanner?.startsWith("⚠️") == true) MagicAmberLight else MagicEmeraldLight,

                                            fontSize = 11.sp,

                                            fontWeight = FontWeight.Bold,

                                            modifier = Modifier.weight(1f)

                                        )

                                        IconButton(

                                            onClick = { lastActionBanner = null },

                                            modifier = Modifier.size(28.dp)

                                        ) {

                                            Icon(Icons.Default.Close, "Ẩn thông báo", tint = if (lastActionBanner?.startsWith("⚠️") == true) MagicAmberLight else MagicEmeraldLight, modifier = Modifier.size(16.dp))

                                        }

                                    }

                                }

                            }



                            // Ô #45: DANH SÁCH ỨNG DỤNG CHẠY NGẦM (TÌM KIẾM + LỌC + SẮP XẾP)

                            item(key = "search_and_filters", contentType = "filters") {

                                Column(

                                    modifier = Modifier.fillMaxWidth(),

                                    verticalArrangement = Arrangement.spacedBy(8.dp)

                                ) {

                                    Row(

                                        verticalAlignment = Alignment.CenterVertically,

                                        horizontalArrangement = Arrangement.spacedBy(6.dp)

                                    ) {

                                        Box(

                                            modifier = Modifier

                                                .clip(RoundedCornerShape(5.dp))

                                                .background(MagicCyan.copy(alpha = 0.2f))

                                                .border(0.8.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(5.dp))

                                                .padding(horizontal = 6.dp, vertical = 1.dp)

                                        ) {

                                            Text("Ô #45", color = MagicCyanLight, fontSize = 9.5.sp, fontWeight = FontWeight.Black)

                                        }

                                        Text(

                                            text = "DANH SÁCH APP CHẠY NGẦM (${filteredEntries.size})",

                                            color = MagicCyanLight,

                                            fontSize = 11.5.sp,

                                            fontWeight = FontWeight.Black

                                        )

                                    }

                                    OutlinedTextField(

                                        value = searchQuery,

                                        onValueChange = { searchQuery = it },

                                        modifier = Modifier

                                            .fillMaxWidth()

                                            .testTag("bg_drain_search_input"),

                                        placeholder = {

                                            Text("Tìm tên ứng dụng hoặc tên gói...", fontSize = 11.5.sp, color = TextMuted)

                                        },

                                        singleLine = true,

                                        shape = RoundedCornerShape(12.dp),

                                        leadingIcon = {

                                            Icon(Icons.Default.Search, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(18.dp))

                                        },

                                        trailingIcon = {

                                            if (searchQuery.isNotBlank()) {

                                                IconButton(onClick = { searchQuery = "" }) {

                                                    Icon(Icons.Default.Clear, contentDescription = "Xóa tìm kiếm", tint = TextSecondary, modifier = Modifier.size(18.dp))

                                                }

                                            }

                                        },

                                        colors = OutlinedTextFieldDefaults.colors(

                                            focusedContainerColor = MagicSurfaceDark,

                                            unfocusedContainerColor = MagicSurfaceDark,

                                            focusedBorderColor = MagicCyan,

                                            unfocusedBorderColor = MagicBorder,

                                            focusedTextColor = Color.White,

                                            unfocusedTextColor = Color.White

                                        )

                                    )



                                    // Hàng Filter Chips có số lượng thực (đã tính sẵn trong entryStats)

                                    Row(

                                        modifier = Modifier

                                            .fillMaxWidth()

                                            .horizontalScroll(rememberScrollState()),

                                        horizontalArrangement = Arrangement.spacedBy(6.dp)

                                    ) {

                                        DrainFilterTab.entries.forEach { tab ->

                                            val count = when (tab) {

                                                DrainFilterTab.ALL -> entryStats.countAll

                                                DrainFilterTab.HIGH_DRAIN -> entryStats.countHigh

                                                DrainFilterTab.SERVICES_NET -> entryStats.countSvc

                                                DrainFilterTab.USER_APPS -> entryStats.countUser

                                                DrainFilterTab.PROTECTED -> entryStats.countProt

                                            }

                                            val selected = selectedFilter == tab

                                            FilterChip(

                                                selected = selected,

                                                onClick = { selectedFilter = tab },

                                                label = {

                                                    Text(

                                                        text = "${tab.label} ($count)",

                                                        fontSize = 10.5.sp,

                                                        fontWeight = FontWeight.Bold

                                                    )

                                                },

                                                colors = FilterChipDefaults.filterChipColors(

                                                    selectedContainerColor = when (tab) {

                                                        DrainFilterTab.HIGH_DRAIN -> MagicRose.copy(alpha = 0.3f)

                                                        DrainFilterTab.PROTECTED -> MagicEmerald.copy(alpha = 0.28f)

                                                        else -> MagicCyan.copy(alpha = 0.28f)

                                                    },

                                                    selectedLabelColor = Color.White,

                                                    containerColor = MagicSurfaceDark,

                                                    labelColor = TextSecondary

                                                ),

                                                border = FilterChipDefaults.filterChipBorder(

                                                    enabled = true,

                                                    selected = selected,

                                                    borderColor = MagicBorder,

                                                    selectedBorderColor = when (tab) {

                                                        DrainFilterTab.HIGH_DRAIN -> MagicRose

                                                        DrainFilterTab.PROTECTED -> MagicEmerald

                                                        else -> MagicCyan

                                                    }

                                                )

                                            )

                                        }

                                    }



                                    // Hàng Sắp xếp nhanh

                                    Row(

                                        modifier = Modifier

                                            .fillMaxWidth()

                                            .horizontalScroll(rememberScrollState()),

                                        horizontalArrangement = Arrangement.spacedBy(6.dp),

                                        verticalAlignment = Alignment.CenterVertically

                                    ) {

                                        Text(

                                            text = "Xếp theo:",

                                            color = TextMuted,

                                            fontSize = 10.5.sp,

                                            fontWeight = FontWeight.Bold

                                        )

                                        DrainSortMode.entries.forEach { mode ->

                                            val isCur = selectedSort == mode

                                            Box(

                                                modifier = Modifier

                                                    .clip(RoundedCornerShape(8.dp))

                                                    .background(if (isCur) MagicPurple.copy(alpha = 0.28f) else MagicSurfaceDark)

                                                    .border(

                                                        1.dp,

                                                        if (isCur) MagicPurpleLight else MagicBorder.copy(alpha = 0.6f),

                                                        RoundedCornerShape(8.dp)

                                                    )

                                                    .clickable { selectedSort = mode }

                                                    .padding(horizontal = 9.dp, vertical = 5.dp)

                                            ) {

                                                Text(

                                                    text = mode.label,

                                                    color = if (isCur) Color.White else TextSecondary,

                                                    fontSize = 10.sp,

                                                    fontWeight = FontWeight.Bold

                                                )

                                            }

                                        }

                                    }

                                }

                            }



                            if (isScanning && currentReport == null) {

                                item(key = "loading_drain_list", contentType = "loading") {

                                    Row(

                                        modifier = Modifier

                                            .fillMaxWidth()

                                            .clip(RoundedCornerShape(12.dp))

                                            .background(MagicSurfaceCard)

                                            .border(1.dp, MagicBorder.copy(alpha = 0.6f), RoundedCornerShape(12.dp))

                                            .padding(horizontal = 14.dp, vertical = 16.dp),

                                        verticalAlignment = Alignment.CenterVertically,

                                        horizontalArrangement = Arrangement.spacedBy(10.dp)

                                    ) {

                                        CircularProgressIndicator(

                                            color = MagicCyan,

                                            strokeWidth = 2.4.dp,

                                            modifier = Modifier.size(20.dp)

                                        )

                                        Text(

                                            text = "Đang nạp nhanh danh sách app chạy ngầm...",

                                            color = MagicCyanLight,

                                            fontSize = 11.5.sp,

                                            fontWeight = FontWeight.Bold

                                        )

                                    }

                                }

                            } else if (filteredEntries.isEmpty()) {

                                item(key = "empty_drain_list", contentType = "empty") {

                                    Box(

                                        modifier = Modifier

                                            .fillMaxWidth()

                                            .padding(vertical = 36.dp),

                                        contentAlignment = Alignment.Center

                                    ) {

                                        Text(

                                            text = if (allEntries.isEmpty()) "✅ Không phát hiện app chạy ngầm gây hao pin lúc này!"

                                            else "Không có app nào khớp bộ lọc / từ khóa hiện tại.",

                                            color = MagicEmeraldLight,

                                            fontSize = 12.sp,

                                            fontWeight = FontWeight.Bold

                                        )

                                    }

                                }

                            } else {

                                itemsIndexed(

                                    items = visibleEntries,

                                    key = { _, entry -> "drain_entry_${entry.packageName}" },

                                    contentType = { _, _ -> "bg_drain_entry_pro" }

                                ) { _, entry ->

                                    val isExpanded = expandedPkg == entry.packageName

                                    BackgroundDrainEntryCard(

                                        entry = entry,

                                        isExpanded = isExpanded,

                                        isBusy = isWorkingAction,

                                        onToggleExpand = {

                                            expandedPkg = if (isExpanded) null else entry.packageName

                                        },

                                        onDeepSleepKeepNotif = {

                                            coroutineScope.launch {

                                                isWorkingAction = true

                                                try {

                                                    val (_, msg) = BackgroundDrainInspector.stopBackgroundApp(

                                                        context = context,

                                                        packageName = entry.packageName,

                                                        deepSleep = true

                                                    )

                                                    lastActionBanner = msg

                                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

                                                    runScanNow(silent = true)

                                                } catch (e: kotlinx.coroutines.CancellationException) {

                                                    throw e

                                                } catch (_: Throwable) {

                                                } finally {

                                                    isWorkingAction = false

                                                }

                                            }

                                        },

                                        onForceStop = {

                                            coroutineScope.launch {

                                                isWorkingAction = true

                                                try {

                                                    val (_, msg) = BackgroundDrainInspector.forceStopApp(context, entry.packageName)

                                                    lastActionBanner = msg

                                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

                                                    runScanNow(silent = true)

                                                } catch (e: kotlinx.coroutines.CancellationException) {

                                                    throw e

                                                } catch (_: Throwable) {

                                                } finally {

                                                    isWorkingAction = false

                                                }

                                            }

                                        },

                                        onRestoreNormal = {

                                            coroutineScope.launch {

                                                isWorkingAction = true

                                                try {

                                                    val (_, msg) = BackgroundDrainInspector.restoreBackgroundNormal(context, entry.packageName)

                                                    lastActionBanner = msg

                                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

                                                    runScanNow(silent = true)

                                                } catch (e: kotlinx.coroutines.CancellationException) {

                                                    throw e

                                                } catch (_: Throwable) {

                                                } finally {

                                                    isWorkingAction = false

                                                }

                                            }

                                        },

                                        onToggleVipWhitelist = {

                                            coroutineScope.launch {

                                                try {

                                                    val added = withContext(Dispatchers.IO) {

                                                        BackgroundDrainInspector.toggleUserWhitelistPackage(context, entry.packageName)

                                                    }

                                                    val msg = if (added) {

                                                        "🛡️ Đã thêm ${entry.appName} vào danh sách VIP Bảo Vệ!"

                                                    } else {

                                                        "🔓 Đã gỡ ${entry.appName} khỏi danh sách VIP!"

                                                    }

                                                    lastActionBanner = msg

                                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

                                                    runScanNow(silent = true)

                                                } catch (e: kotlinx.coroutines.CancellationException) {

                                                    throw e

                                                } catch (_: Throwable) {}

                                            }

                                        },

                                        onOpenAppInfo = {

                                            try {

                                                val intent = Intent(

                                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,

                                                    Uri.parse("package:${entry.packageName}")

                                                ).apply {

                                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

                                                }

                                                context.startActivity(intent)

                                            } catch (_: Throwable) {

                                                AppPermissionChecker.openAppDetailsSettings(context)

                                            }

                                        }

                                    )

                                }



                                // Nút Xem thêm / Thu gọn để giữ Tab 7 cực nhẹ khi có nhiều app chạy ngầm

                                if (searchQuery.isBlank() && filteredEntries.size > 10) {

                                    item(key = "toggle_show_all_drain_entries", contentType = "pagination_btn") {

                                        OutlinedButton(

                                            onClick = { showAllDrainEntries = !showAllDrainEntries },

                                            modifier = Modifier

                                                .fillMaxWidth()

                                                .defaultMinSize(minHeight = 36.dp)

                                                .testTag("toggle_show_all_drain_entries_btn"),

                                            shape = RoundedCornerShape(10.dp),

                                            border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.55f))

                                        ) {

                                            val hiddenCount = (filteredEntries.size - 10).coerceAtLeast(0)

                                            Text(

                                                text = if (showAllDrainEntries) "Thu gọn về 10 app xả nặng nhất"

                                                else "Xem thêm +$hiddenCount app chạy ngầm khác",

                                                color = MagicCyanLight,

                                                fontSize = 11.sp,

                                                fontWeight = FontWeight.Bold

                                            )

                                        }

                                    }

                                }

                            }

                    }



                    // 3. STICKY BOTTOM COMMAND DOCK (FULL-WIDTH EDGE-TO-EDGE)

                    val entries = allEntries

                    val stoppableCount = entryStats.stoppableCount

                    HorizontalDivider(color = MagicBorder.copy(alpha = 0.6f))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Min)
                            .background(Color(0xFF0A1120))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        OutlinedButton(

                            onClick = {

                                coroutineScope.launch {

                                    isWorkingAction = true

                                    try {

                                        val (_, msg) = BackgroundDrainInspector.trimSystemCachesAndReclaimRam(context, entries)

                                        lastActionBanner = msg

                                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

                                        runScanNow(silent = true)

                                    } catch (e: kotlinx.coroutines.CancellationException) {

                                        throw e

                                    } catch (_: Throwable) {

                                    } finally {

                                        isWorkingAction = false

                                    }

                                }

                            },

                            enabled = !isWorkingAction,

                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .heightIn(min = 40.dp, max = 44.dp)
                                .testTag("trim_ram_cache_button"),

                            shape = RoundedCornerShape(12.dp),

                            border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.65f)),

                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)

                        ) {

                            Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(15.dp))

                            Spacer(modifier = Modifier.width(4.dp))

                            Text(

                                text = "Dọn App Nền",

                                color = MagicCyanLight,

                                fontSize = 10.8.sp,

                                fontWeight = FontWeight.Black,

                                maxLines = 1,

                                overflow = TextOverflow.Ellipsis

                            )

                        }



                        Button(

                            onClick = {

                                coroutineScope.launch {

                                    isWorkingAction = true

                                    try {

                                        val (_, msg) = BackgroundDrainInspector.stopAllHighDrainApps(context, entries)

                                        lastActionBanner = msg

                                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()

                                        runScanNow(silent = true)

                                    } catch (e: kotlinx.coroutines.CancellationException) {

                                        throw e

                                    } catch (_: Throwable) {

                                    } finally {

                                        isWorkingAction = false

                                    }

                                }

                            },

                            enabled = stoppableCount > 0 && !isWorkingAction,

                            modifier = Modifier
                                .weight(1.35f)
                                .fillMaxHeight()
                                .heightIn(min = 40.dp, max = 44.dp)
                                .testTag("stop_all_bg_drainers_button"),

                            shape = RoundedCornerShape(12.dp),

                            colors = ButtonDefaults.buttonColors(

                                containerColor = MagicRose,

                                contentColor = Color.White,

                                disabledContainerColor = MagicSurfaceCard,

                                disabledContentColor = TextMuted

                            ),

                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)

                        ) {

                            Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(15.dp))

                            Spacer(modifier = Modifier.width(4.dp))

                            Text(

                                text = if (stoppableCount > 0) "Dừng $stoppableCount App Xả Cao" else "✓ Không Có App Xả Cao",

                                fontSize = 10.8.sp,

                                fontWeight = FontWeight.Black,

                                maxLines = 1,

                                overflow = TextOverflow.Ellipsis

                            )

                        }

                    }

    }

}



@Composable

private fun TelemetryExecutiveDashboard(

    report: BackgroundDrainScanReport?,

    liveBattery: com.example.core.widget.BatteryChargeData? = null,

    drainAnalytics: DrainRateAnalytics? = null,

    onRequestUsagePermission: () -> Unit,

    onOpenWlanConnection: () -> Unit

) {

    val livePct = liveBattery?.batteryPct ?: report?.batteryPct ?: 0

    val liveTemperatureAvailable = liveBattery?.isBatteryTemperatureAvailable

        ?: (report?.batteryTempAvailable == true)

    val rawTemp = if (liveTemperatureAvailable) {

        liveBattery?.tempCelsius ?: report?.batteryTempC ?: 0.0

    } else 0.0

    val liveTempC = if (rawTemp.isFinite()) rawTemp else 0.0

    val liveCharging = liveBattery?.isCharging ?: report?.isCharging ?: false

    val rawWatts = liveBattery?.let { if (it.isCharging) it.currentWatts else it.dischargingWatts }

        ?: report?.totalCurrentDrainWatts ?: 0.0

    val liveWatts = if (rawWatts.isFinite()) rawWatts else 0.0

    val liveDesignMah = liveBattery?.designCapacityMah ?: 5000



    val severityLabel: String

    val severityColor: Color

    when {

        liveCharging -> {

            severityLabel = "🔌 ĐANG SẠC"

            severityColor = MagicEmeraldLight

        }

        !liveTemperatureAvailable -> {

            severityLabel = "🌡️ NHIỆT ĐỘ N/A"

            severityColor = Color(0xFF94A3B8)

        }

        liveTempC >= 41.0 -> {

            severityLabel = "🔥 PIN NÓNG"

            severityColor = MagicRoseLight

        }

        liveTempC >= 37.5 -> {

            severityLabel = "⚠️ HƠI ẤM"

            severityColor = MagicAmberLight

        }

        else -> {

            severityLabel = "❄️ MÁT & ỔN ĐỊNH"

            severityColor = MagicEmeraldLight

        }

    }



    Card(

        modifier = Modifier.fillMaxWidth(),

        shape = RoundedCornerShape(14.dp),

        colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1528)),

        border = BorderStroke(1.dp, severityColor.copy(alpha = 0.48f))

    ) {

        Column(

            modifier = Modifier

                .fillMaxWidth()

                .padding(12.dp),

            verticalArrangement = Arrangement.spacedBy(8.dp)

        ) {

            Row(

                modifier = Modifier.fillMaxWidth(),

                horizontalArrangement = Arrangement.SpaceBetween,

                verticalAlignment = Alignment.CenterVertically

            ) {

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(5.dp))

                            .background(MagicCyan.copy(alpha = 0.2f))

                            .border(0.8.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(5.dp))

                            .padding(horizontal = 5.dp, vertical = 1.dp)

                    ) {

                        Text("Ô #44", color = MagicCyanLight, fontSize = 9.2.sp, fontWeight = FontWeight.Black)

                    }

                    Icon(

                        imageVector = if (liveCharging) Icons.Default.BatteryChargingFull else Icons.Default.Bolt,

                        contentDescription = null,

                        tint = severityColor,

                        modifier = Modifier.size(17.dp)

                    )

                    Text(

                        text = if (liveCharging && liveWatts > 0.5) {

                            String.format(Locale.US, "Pin %d%% • %.1fW", livePct, liveWatts)

                        } else {

                            if (liveTemperatureAvailable) {

                                "Pin $livePct% • ${String.format(Locale.US, "%.1f°C", liveTempC)}"

                            } else {

                                "Pin $livePct% • Nhiệt độ --°C"

                            }

                        },

                        color = Color.White,

                        fontSize = 13.sp,

                        fontWeight = FontWeight.Black

                    )

                }



                Box(

                    modifier = Modifier

                        .clip(RoundedCornerShape(8.dp))

                        .background(severityColor.copy(alpha = 0.18f))

                        .border(0.8.dp, severityColor.copy(alpha = 0.55f), RoundedCornerShape(8.dp))

                        .padding(horizontal = 8.dp, vertical = 4.dp)

                ) {

                    Text(

                        text = severityLabel,

                        color = severityColor,

                        fontSize = 9.8.sp,

                        fontWeight = FontWeight.Black

                    )

                }

            }



            // 3 chỉ số siêu nhẹ đọc tức thì (<2ms từ Fuel Gauge µAh, đồng bộ 100% với Widget)

            Row(

                modifier = Modifier.fillMaxWidth(),

                horizontalArrangement = Arrangement.spacedBy(6.dp)

            ) {

                MiniDashStat(

                    modifier = Modifier.weight(1f),

                    icon = Icons.Default.Warning,

                    label = "Nhiệt pin",

                    value = if (liveTemperatureAvailable) String.format(Locale.US, "%.1f°C", liveTempC) else "--°C",

                    color = when {

                        !liveTemperatureAvailable -> Color(0xFF94A3B8)

                        liveTempC >= 38.5 -> MagicRoseLight

                        else -> MagicCyanLight

                    }

                )

                val syncedEstMins = if (livePct > 0) {

                    AiPowerAutopilotManager.estimateScreenOnMinutes(

                        batteryPct = livePct,

                        screenOnDrainPctPerHour = drainAnalytics?.screenOnDrainPctPerHour,

                        designCapacityMah = liveDesignMah

                    )

                } else {

                    ((report?.estimatedHoursLeft ?: 0.0).takeIf { it.isFinite() } ?: 0.0).times(60.0).toInt().coerceAtLeast(0)

                }

                val syncedEstLabel = when {

                    syncedEstMins > 0 -> {

                        val h = syncedEstMins / 60

                        val m = syncedEstMins % 60

                        if (m > 0) "~${h}h ${m}p" else "~${h}h"

                    }

                    else -> "$livePct%"

                }

                MiniDashStat(

                    modifier = Modifier.weight(1f),

                    icon = Icons.Default.Memory,

                    label = "Sáng màn",

                    value = syncedEstLabel,

                    color = MagicAmberLight

                )

                MiniDashStat(

                    modifier = Modifier.weight(1f),

                    icon = Icons.Default.BatteryAlert,

                    label = "App tải nặng",

                    value = if (report != null) "${report.highDrainCount}/${report.totalBgAppsRunning}" else "Đang quét...",

                    color = if ((report?.highDrainCount ?: 0) > 0) MagicRoseLight else MagicEmeraldLight

                )

            }



            // Thanh RAM tổng & RAM trống

            if (report != null && report.totalRamMb > 0) {

                val ramRatio = (report.usedRamMb.toFloat() / report.totalRamMb.toFloat()).takeIf { it.isFinite() }?.coerceIn(0f, 1f) ?: 0f

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {

                    Row(

                        modifier = Modifier.fillMaxWidth(),

                        horizontalArrangement = Arrangement.SpaceBetween

                    ) {

                        Text(

                            text = "🧠 RAM: ${report.usedRamMb}MB / ${report.totalRamMb}MB",

                            color = TextSecondary,

                            fontSize = 10.sp,

                            fontWeight = FontWeight.SemiBold

                        )

                        Text(

                            text = "Trống ${report.availableRamMb}MB (${((1f - ramRatio) * 100).toInt()}%)",

                            color = if (report.availableRamMb < 1200) MagicAmberLight else MagicEmeraldLight,

                            fontSize = 10.sp,

                            fontWeight = FontWeight.Bold

                        )

                    }

                    LinearProgressIndicator(

                        progress = { ramRatio },

                        modifier = Modifier

                            .fillMaxWidth()

                            .height(6.dp)

                            .clip(RoundedCornerShape(4.dp)),

                        color = if (ramRatio > 0.82f) MagicRose else if (ramRatio > 0.65f) MagicAmber else MagicCyan,

                        trackColor = Color(0xFF1E293B)

                    )

                }

            }



            if (report != null && !report.isDeepAdbScan) {

                Row(

                    modifier = Modifier

                        .fillMaxWidth()

                        .clip(RoundedCornerShape(10.dp))

                        .background(MagicAmber.copy(alpha = 0.14f))

                        .border(1.dp, MagicAmber.copy(alpha = 0.5f), RoundedCornerShape(10.dp))

                        .padding(horizontal = 10.dp, vertical = 8.dp),

                    verticalAlignment = Alignment.CenterVertically,

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Text(

                        text = if (!report.hasUsageStatsAccess) {

                            "Cấp quyền Truy cập Sử dụng hoặc bật ADB để dừng app chạy ngầm hiệu quả hơn."

                        } else {

                            "Kết nối Gỡ lỗi WLAN ADB trực tiếp để đóng băng sâu app ngầm (vẫn giữ thông báo)."

                        },

                        color = MagicAmberLight,

                        fontSize = 10.2.sp,

                        fontWeight = FontWeight.Bold,

                        modifier = Modifier.weight(1f)

                    )

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(8.dp))

                            .background(if (!report.hasUsageStatsAccess) MagicAmber else MagicCyan)

                            .clickable {

                                if (!report.hasUsageStatsAccess) onRequestUsagePermission() else onOpenWlanConnection()

                            }

                            .padding(horizontal = 10.dp, vertical = 6.dp)

                    ) {

                        Text(

                            text = if (!report.hasUsageStatsAccess) "Cấp quyền" else "Kết nối ADB",

                            color = Color(0xFF020617),

                            fontSize = 10.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                }

            }

        }

    }

}



@Composable

private fun MiniDashStat(

    modifier: Modifier,

    icon: androidx.compose.ui.graphics.vector.ImageVector,

    label: String,

    value: String,

    color: Color

) {

    Column(

        modifier = modifier

            .clip(RoundedCornerShape(8.dp))

            .background(Color(0xFF080E1C))

            .border(0.7.dp, MagicBorder.copy(alpha = 0.55f), RoundedCornerShape(8.dp))

            .padding(horizontal = 6.dp, vertical = 6.dp),

        verticalArrangement = Arrangement.spacedBy(2.dp)

    ) {

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {

            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(11.dp))

            Text(text = label, color = TextMuted, fontSize = 8.8.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)

        }

        Text(text = value, color = color, fontSize = 10.5.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)

    }

}



@OptIn(ExperimentalLayoutApi::class)

@Composable

private fun BackgroundDrainEntryCard(

    entry: BackgroundAppDrainEntry,

    isExpanded: Boolean,

    isBusy: Boolean,

    onToggleExpand: () -> Unit,

    onDeepSleepKeepNotif: () -> Unit,

    onForceStop: () -> Unit,

    onRestoreNormal: () -> Unit,

    onToggleVipWhitelist: () -> Unit,

    onOpenAppInfo: () -> Unit

) {

    val borderColor = when {

        entry.isProtected -> MagicEmerald.copy(alpha = 0.55f)

        entry.wakeLockCount > 0 || entry.isHighDrain -> MagicRose.copy(alpha = 0.68f)

        entry.hasActiveService -> MagicAmber.copy(alpha = 0.55f)

        else -> MagicBorder

    }



    Card(

        modifier = Modifier

            .fillMaxWidth()

            .clickable(onClick = onToggleExpand),

        shape = RoundedCornerShape(12.dp),

        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),

        border = BorderStroke(1.dp, borderColor)

    ) {

        Column(

            modifier = Modifier

                .fillMaxWidth()

                .padding(11.dp),

            verticalArrangement = Arrangement.spacedBy(7.dp)

        ) {

            Row(

                modifier = Modifier.fillMaxWidth(),

                verticalAlignment = Alignment.CenterVertically,

                horizontalArrangement = Arrangement.spacedBy(9.dp)

            ) {

                AppIconImage(

                    packageName = entry.packageName,

                    label = entry.appName,

                    modifier = Modifier.size(40.dp),

                    cornerRadius = 10.dp

                )

                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(5.dp)

                    ) {

                        Text(

                            text = entry.appName,

                            color = Color.White,

                            fontSize = 13.sp,

                            fontWeight = FontWeight.Black,

                            maxLines = 1,

                            overflow = TextOverflow.Ellipsis,

                            modifier = Modifier.weight(1f, fill = false)

                        )

                        val tierBadge: Pair<String, Color> = when {

                            entry.isProtected -> "VIP" to MagicEmeraldLight

                            entry.wakeLockCount > 0 -> "KHÓA CPU" to MagicRoseLight

                            entry.isHighDrain -> "XẢ NẶNG" to MagicRoseLight

                            entry.hasActiveService -> "DỊCH VỤ" to MagicAmberLight

                            else -> "NHẸ" to MagicCyanLight

                        }

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(5.dp))

                                .background(tierBadge.second.copy(alpha = 0.18f))

                                .padding(horizontal = 6.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = tierBadge.first,

                                color = tierBadge.second,

                                fontSize = 8.8.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                    }

                    Text(

                        text = entry.processStateLabel,

                        color = if (entry.isHighDrain || entry.wakeLockCount > 0) MagicRoseLight else TextSecondary,

                        fontSize = 10.5.sp,

                        fontWeight = FontWeight.Medium,

                        maxLines = 1,

                        overflow = TextOverflow.Ellipsis

                    )

                }



                // Nút thao tác nhanh 1 chạm ngay bên phải + Chevron mở rộng

                if (!entry.isProtected) {

                    Box(

                        modifier = Modifier

                            .heightIn(min = 34.dp)

                            .clip(RoundedCornerShape(8.dp))

                            .background(MagicRose.copy(alpha = 0.22f))

                            .border(1.dp, MagicRose.copy(alpha = 0.6f), RoundedCornerShape(8.dp))

                            .clickable(enabled = !isBusy, onClick = onDeepSleepKeepNotif)

                            .padding(horizontal = 9.dp, vertical = 6.dp),

                        contentAlignment = Alignment.Center

                    ) {

                        Text(

                            text = "❄️ Ngủ sâu",

                            color = MagicRoseLight,

                            fontSize = 10.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                } else {

                    Icon(

                        imageVector = Icons.Default.Shield,

                        contentDescription = "VIP Bảo vệ",

                        tint = MagicEmeraldLight,

                        modifier = Modifier.size(18.dp)

                    )

                }



                Icon(

                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,

                    contentDescription = "Mở chi tiết phân tích",

                    tint = TextSecondary,

                    modifier = Modifier.size(20.dp)

                )

            }



            // Hàng chỉ số gọn nhẹ (chỉ RAM & dịch vụ nền — không đo CPU/WakeLock/mAh thừa)

            Row(

                modifier = Modifier.fillMaxWidth(),

                horizontalArrangement = Arrangement.spacedBy(5.dp),

                verticalAlignment = Alignment.CenterVertically

            ) {

                if (entry.ramMb > 0) {

                    DrainMetricChip(text = "${entry.ramMb}MB RAM", color = MagicCyanLight)

                }

                if (entry.activeServiceCount > 0) {

                    DrainMetricChip(text = "${entry.activeServiceCount} dịch vụ", color = MagicAmberLight)

                }

                DrainMetricChip(

                    text = entry.standbyBucketLabel,

                    color = if (entry.isBackgroundRestricted) MagicEmeraldLight else TextSecondary

                )

            }



            // NGĂN MỞ RỘNG ĐIỀU KHIỂN NHANH (chỉ compose khi mở để 0 tốn bộ nhớ khi cuộn)

            if (isExpanded) {

                Column(

                    modifier = Modifier

                        .fillMaxWidth()

                        .padding(top = 4.dp)

                        .clip(RoundedCornerShape(10.dp))

                        .background(Color(0xFF090F1D))

                        .border(0.8.dp, MagicBorder.copy(alpha = 0.65f), RoundedCornerShape(10.dp))

                        .padding(10.dp),

                    verticalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Text(

                        text = "${entry.packageName} • ${entry.processCount} tiến trình",

                        color = TextSecondary,

                        fontSize = 9.8.sp,

                        fontWeight = FontWeight.SemiBold,

                        maxLines = 1,

                        overflow = TextOverflow.Ellipsis

                    )



                    // Hàng 1 nút điều khiển chính

                    Row(

                        modifier = Modifier.fillMaxWidth(),

                        horizontalArrangement = Arrangement.spacedBy(6.dp)

                    ) {

                        Button(

                            onClick = onDeepSleepKeepNotif,

                            enabled = !isBusy,

                            modifier = Modifier.weight(1f).fillMaxHeight().defaultMinSize(minHeight = 36.dp),

                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),

                            shape = RoundedCornerShape(8.dp),

                            colors = ButtonDefaults.buttonColors(

                                containerColor = if (entry.isProtected) MagicEmerald.copy(alpha = 0.2f) else MagicCyan.copy(alpha = 0.22f),

                                contentColor = if (entry.isProtected) MagicEmeraldLight else MagicCyanLight

                            ),

                            border = BorderStroke(

                                1.dp,

                                if (entry.isProtected) MagicEmerald.copy(alpha = 0.55f) else MagicCyan.copy(alpha = 0.55f)

                            )

                        ) {

                            Icon(

                                imageVector = if (entry.isProtected) Icons.Default.Shield else Icons.Default.Bolt,

                                contentDescription = null,

                                modifier = Modifier.size(14.dp)

                            )

                            Spacer(modifier = Modifier.width(4.dp))

                            Text(

                                text = if (entry.isProtected) "Gia cố VIP" else "❄️ Ngủ Sâu (Giữ TB)",

                                fontSize = 10.2.sp,

                                fontWeight = FontWeight.Black,

                                maxLines = 1

                            )

                        }



                        if (!entry.isSystemCommsProtected) {

                            Button(

                                onClick = onForceStop,

                                enabled = !isBusy,

                                modifier = Modifier.weight(1f).fillMaxHeight().defaultMinSize(minHeight = 36.dp),

                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),

                                shape = RoundedCornerShape(8.dp),

                                colors = ButtonDefaults.buttonColors(

                                    containerColor = MagicRose.copy(alpha = 0.24f),

                                    contentColor = MagicRoseLight

                                ),

                                border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.6f))

                            ) {

                                Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(14.dp))

                                Spacer(modifier = Modifier.width(4.dp))

                                Text("🛑 Force-Stop 0%", fontSize = 10.2.sp, fontWeight = FontWeight.Black, maxLines = 1)

                            }

                        }

                    }



                    // Hàng 2 nút bổ trợ: Khôi phục bình thường / Toggle VIP / Mở Cài đặt App

                    Row(

                        modifier = Modifier.fillMaxWidth(),

                        horizontalArrangement = Arrangement.spacedBy(6.dp)

                    ) {

                        OutlinedButton(

                            onClick = onRestoreNormal,

                            enabled = !isBusy,

                            modifier = Modifier.weight(1f).fillMaxHeight().defaultMinSize(minHeight = 34.dp),

                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),

                            shape = RoundedCornerShape(8.dp),

                            border = BorderStroke(1.dp, MagicBorder)

                        ) {

                            Icon(Icons.Default.Refresh, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(13.dp))

                            Spacer(modifier = Modifier.width(4.dp))

                            Text("Mở lại nền", color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)

                        }



                        if (!entry.isSystemCommsProtected) {

                            OutlinedButton(

                                onClick = onToggleVipWhitelist,

                                enabled = !isBusy,

                                modifier = Modifier.weight(1f).fillMaxHeight().defaultMinSize(minHeight = 34.dp),

                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),

                                shape = RoundedCornerShape(8.dp),

                                border = BorderStroke(1.dp, if (entry.isUserWhitelisted) MagicAmber else MagicEmerald.copy(alpha = 0.55f))

                            ) {

                                Icon(

                                    Icons.Default.Shield,

                                    contentDescription = null,

                                    tint = if (entry.isUserWhitelisted) MagicAmberLight else MagicEmeraldLight,

                                    modifier = Modifier.size(13.dp)

                                )

                                Spacer(modifier = Modifier.width(4.dp))

                                Text(

                                    text = if (entry.isUserWhitelisted) "Bỏ VIP" else "Bảo vệ VIP",

                                    color = if (entry.isUserWhitelisted) MagicAmberLight else MagicEmeraldLight,

                                    fontSize = 10.sp,

                                    fontWeight = FontWeight.Bold,

                                    maxLines = 1

                                )

                            }

                        }



                        OutlinedButton(

                            onClick = onOpenAppInfo,

                            modifier = Modifier.heightIn(min = 36.dp),

                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),

                            shape = RoundedCornerShape(8.dp),

                            border = BorderStroke(1.dp, MagicBorder)

                        ) {

                            Icon(Icons.Default.Settings, contentDescription = "Mở thông tin app", tint = TextSecondary, modifier = Modifier.size(13.dp))

                            Spacer(modifier = Modifier.width(3.dp))

                            Text("Cài đặt", color = TextSecondary, fontSize = 10.sp)

                        }

                    }

                }

            }

        }

    }

}



@Composable

private fun DrainMetricChip(

    text: String,

    color: Color

) {

    Box(

        modifier = Modifier

            .clip(RoundedCornerShape(6.dp))

            .background(color.copy(alpha = 0.14f))

            .padding(horizontal = 6.dp, vertical = 3.dp)

    ) {

        Text(

            text = text,

            color = color,

            fontSize = 9.5.sp,

            fontWeight = FontWeight.Bold

        )

    }

}



@Composable

private fun MagicTuneSelfPowerGovernorCard(

    snapshot: com.example.core.perf.MagicTuneSelfPowerGovernor.SelfPowerSnapshot?,

    onRequestLoadSnapshot: () -> Unit,

    onSelectMode: (com.example.core.perf.MagicTuneSelfPowerGovernor.SelfPowerMode) -> Unit,

    onToggleModule: (String, Boolean) -> Unit,

    onHibernateSelfNow: () -> Unit

) {

    var isCardExpanded by remember { mutableStateOf(false) }

    var showModulesDetail by remember { mutableStateOf(false) }

    val maText = if (snapshot == null) "Chưa có trạng thái" else "Không đo mA riêng"

    val statusColor = if (snapshot == null) MagicEmeraldLight else MagicCyanLight



    Card(

        modifier = Modifier

            .fillMaxWidth()

            .testTag("magictune_self_power_card"),

        shape = RoundedCornerShape(14.dp),

        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1424)),

        border = BorderStroke(1.2.dp, MagicEmerald.copy(alpha = 0.65f))

    ) {

        Column(

            modifier = Modifier

                .fillMaxWidth()

                .padding(12.dp),

            verticalArrangement = Arrangement.spacedBy(9.dp)

        ) {

            // Header gọn gàng (chỉ tải thống kê nội bộ khi người dùng chủ động chạm mở -> 0 tốn CPU/PSS khi mở Tab 7)

            Row(

                modifier = Modifier

                    .fillMaxWidth()

                    .clickable {

                        val next = !isCardExpanded

                        isCardExpanded = next

                        if (next && snapshot == null) {

                            onRequestLoadSnapshot()

                        }

                    },

                horizontalArrangement = Arrangement.SpaceBetween,

                verticalAlignment = Alignment.CenterVertically

            ) {

                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp)

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(5.dp))

                                .background(MagicEmerald.copy(alpha = 0.22f))

                                .border(0.8.dp, MagicEmerald.copy(alpha = 0.6f), RoundedCornerShape(5.dp))

                                .padding(horizontal = 5.dp, vertical = 1.dp)

                        ) {

                            Text("Ô #43", color = MagicEmeraldLight, fontSize = 9.2.sp, fontWeight = FontWeight.Black)

                        }

                        Text(

                            text = "CHẾ ĐỘ NỀN MAGICTUNE",

                            color = MagicEmeraldLight,

                            fontSize = 11.2.sp,

                            fontWeight = FontWeight.Black,

                            maxLines = 1,

                            overflow = TextOverflow.Ellipsis,

                            modifier = Modifier.weight(1f, fill = false)

                        )

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(5.dp))

                                .background(statusColor.copy(alpha = 0.18f))

                                .padding(horizontal = 6.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = maText,

                                color = statusColor,

                                fontSize = 9.5.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                    }

                    Text(

                        text = snapshot?.let {

                            "RAM ${it.processPssMb}MB • ${it.activeModuleCount}/${it.totalModuleCount} mô-đun • ${it.mode.badge}"

                        } ?: "Chạm để chỉnh chế độ tiết kiệm & bật/tắt mô-đun nền",

                        color = TextSecondary,

                        fontSize = 9.8.sp,

                        maxLines = 1,

                        overflow = TextOverflow.Ellipsis

                    )

                }

                Icon(

                    imageVector = if (isCardExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,

                    contentDescription = if (isCardExpanded) "Thu gọn chế độ nền" else "Mở rộng chế độ nền",

                    tint = MagicEmeraldLight,

                    modifier = Modifier.size(20.dp)

                )

            }



            if (isCardExpanded && snapshot != null) {



            // 4 chỉ số thực của chính tiến trình MagicTune

            Row(

                modifier = Modifier.fillMaxWidth(),

                horizontalArrangement = Arrangement.spacedBy(6.dp)

            ) {

                SelfPowerMetricBox(

                    modifier = Modifier.weight(1f),

                    label = "RAM MagicTune",

                    value = "${snapshot.processPssMb} MB",

                    sub = "Heap ${snapshot.jvmHeapUsedMb}/${snapshot.jvmHeapMaxMb}M",

                    color = MagicCyanLight

                )

                SelfPowerMetricBox(

                    modifier = Modifier.weight(1f),

                    label = "Mức tiêu thụ app",

                    value = maText,

                    sub = if (snapshot.isKeepAliveServiceRunning) "KeepAlive đang bật" else "KeepAlive đã dừng",

                    color = statusColor

                )

                SelfPowerMetricBox(

                    modifier = Modifier.weight(1f),

                    label = "WakeLock Giữ",

                    value = if (snapshot.isWakeLockHeld) "1 (Voice)" else "0 Khóa",

                    sub = if (snapshot.isAccessibilityActiveInSettings) "A11y Đang mở" else "A11y Đã ngắt",

                    color = if (snapshot.isWakeLockHeld) MagicAmberLight else MagicEmeraldLight

                )

                SelfPowerMetricBox(

                    modifier = Modifier.weight(1f),

                    label = "Mô-đun Nền",

                    value = "${snapshot.activeModuleCount}/${snapshot.totalModuleCount}",

                    sub = snapshot.mode.badge,

                    color = MagicPurpleLight

                )

            }



            // Trạng thái nhịp CPU hiện tại

            Text(

                text = "⚙️ Trạng thái tiến trình: ${snapshot.cpuCadenceLabel}",

                color = MagicCyanLight,

                fontSize = 10.2.sp,

                fontWeight = FontWeight.Bold

            )



            // 3 Chế độ Quản trị Năng lượng Nội bộ

            Row(

                modifier = Modifier.fillMaxWidth(),

                horizontalArrangement = Arrangement.spacedBy(6.dp)

            ) {

                com.example.core.perf.MagicTuneSelfPowerGovernor.SelfPowerMode.entries.forEach { mode ->

                    val selected = snapshot.mode == mode

                    val modeColor = when (mode) {

                        com.example.core.perf.MagicTuneSelfPowerGovernor.SelfPowerMode.ULTRA_LOW_POWER -> MagicEmerald

                        com.example.core.perf.MagicTuneSelfPowerGovernor.SelfPowerMode.ECO_ZERO_DRAIN -> MagicEmerald

                        com.example.core.perf.MagicTuneSelfPowerGovernor.SelfPowerMode.SMART_BALANCED -> MagicCyan

                        com.example.core.perf.MagicTuneSelfPowerGovernor.SelfPowerMode.MAX_24_7 -> MagicAmber

                    }

                    Column(

                        modifier = Modifier

                            .weight(1f)

                            .clip(RoundedCornerShape(10.dp))

                            .background(if (selected) modeColor.copy(alpha = 0.22f) else MagicSurfaceDark)

                            .border(

                                width = if (selected) 1.3.dp else 0.8.dp,

                                color = if (selected) modeColor else MagicBorder,

                                shape = RoundedCornerShape(10.dp)

                            )

                            .clickable { onSelectMode(mode) }

                            .padding(horizontal = 7.dp, vertical = 7.dp)

                            .testTag("self_power_mode_${mode.id}"),

                        verticalArrangement = Arrangement.spacedBy(2.dp)

                    ) {

                        Text(

                            text = mode.title,

                            color = if (selected) Color.White else TextSecondary,

                            fontSize = 9.8.sp,

                            fontWeight = FontWeight.Black,

                            maxLines = 1,

                            overflow = TextOverflow.Ellipsis

                        )

                        Text(

                            text = mode.badge,

                            color = if (selected) modeColor else TextMuted,

                            fontSize = 8.8.sp,

                            fontWeight = FontWeight.Bold,

                            maxLines = 1,

                            overflow = TextOverflow.Ellipsis

                        )

                    }

                }

            }



            Text(

                text = snapshot.mode.description,

                color = TextSecondary,

                fontSize = 9.8.sp,

                lineHeight = 13.5.sp

            )



            // Hàng nút hành động: Thu gọn & Ngủ sâu ngay + Bật/Tắt từng mô-đun

            Row(

                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),

                horizontalArrangement = Arrangement.spacedBy(8.dp),

                verticalAlignment = Alignment.CenterVertically

            ) {

                Button(

                    onClick = onHibernateSelfNow,

                    modifier = Modifier

                        .fillMaxHeight()

                        .weight(1f)

                        .defaultMinSize(minHeight = 36.dp)

                        .testTag("self_power_hibernate_now_button"),

                    shape = RoundedCornerShape(10.dp),

                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),

                    colors = ButtonDefaults.buttonColors(

                        containerColor = MagicEmerald,

                        contentColor = Color(0xFF020617)

                    )

                ) {

                    Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(15.dp))

                    Spacer(modifier = Modifier.width(4.dp))

                    Text(

                        text = "Thu Gọn RAM & Ngắt Ngầm MagicTune (0 mA)",

                        fontSize = 10.2.sp,

                        fontWeight = FontWeight.Black,

                        maxLines = 1,

                        overflow = TextOverflow.Ellipsis

                    )

                }



                OutlinedButton(

                    onClick = { showModulesDetail = !showModulesDetail },

                    modifier = Modifier

                        .fillMaxHeight()

                        .defaultMinSize(minHeight = 36.dp)

                        .testTag("toggle_self_modules_button"),

                    shape = RoundedCornerShape(10.dp),

                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),

                    border = BorderStroke(1.dp, MagicCyan)

                ) {

                    Text(

                        text = if (showModulesDetail) "Ẩn Mô-đun" else "8 Mô-đun (${snapshot.activeModuleCount})",

                        color = MagicCyanLight,

                        fontSize = 10.sp,

                        fontWeight = FontWeight.Bold

                    )

                    Spacer(modifier = Modifier.width(3.dp))

                    Icon(

                        imageVector = if (showModulesDetail) Icons.Default.ExpandLess else Icons.Default.ExpandMore,

                        contentDescription = null,

                        tint = MagicCyanLight,

                        modifier = Modifier.size(16.dp)

                    )

                }

            }



            // Danh sách bật/tắt chi tiết từng mô-đun chạy ngầm của chính MagicTune

            if (showModulesDetail) {

                Column(

                    modifier = Modifier

                        .fillMaxWidth()

                        .padding(top = 4.dp),

                    verticalArrangement = Arrangement.spacedBy(6.dp)

                ) {

                    HorizontalDivider(color = MagicBorder.copy(alpha = 0.5f))

                    Text(

                        text = "BẬT / TẮT TỪNG TÍNH NĂNG CHẠY NGẦM CỦA MAGICTUNE:",

                        color = MagicAmberLight,

                        fontSize = 10.sp,

                        fontWeight = FontWeight.Black

                    )

                    snapshot.modules.forEach { mod ->

                        Row(

                            modifier = Modifier

                                .fillMaxWidth()

                                .clip(RoundedCornerShape(9.dp))

                                .background(MagicSurfaceDark)

                                .border(

                                    0.8.dp,

                                    if (mod.isEnabled) MagicEmerald.copy(alpha = 0.45f) else MagicBorder.copy(alpha = 0.5f),

                                    RoundedCornerShape(9.dp)

                                )

                                .padding(horizontal = 10.dp, vertical = 7.dp),

                            verticalAlignment = Alignment.CenterVertically,

                            horizontalArrangement = Arrangement.SpaceBetween

                        ) {

                            Column(

                                modifier = Modifier

                                    .weight(1f)

                                    .padding(end = 8.dp),

                                verticalArrangement = Arrangement.spacedBy(2.dp)

                            ) {

                                Row(

                                    verticalAlignment = Alignment.CenterVertically,

                                    horizontalArrangement = Arrangement.spacedBy(6.dp)

                                ) {

                                    Text(

                                        text = mod.title,

                                        color = Color.White,

                                        fontSize = 10.8.sp,

                                        fontWeight = FontWeight.Bold,

                                        maxLines = 1,

                                        overflow = TextOverflow.Ellipsis,

                                        modifier = Modifier.weight(1f, fill = false)

                                    )

                                    Box(

                                        modifier = Modifier

                                            .clip(RoundedCornerShape(4.dp))

                                            .background(

                                                if (mod.isEnabled) MagicAmber.copy(alpha = 0.18f)

                                                else MagicEmerald.copy(alpha = 0.16f)

                                            )

                                            .padding(horizontal = 5.dp, vertical = 1.dp)

                                    ) {

                                        Text(

                                            text = mod.powerImpactLabel,

                                            color = if (mod.isEnabled) MagicAmberLight else MagicEmeraldLight,

                                            fontSize = 8.8.sp,

                                            fontWeight = FontWeight.Black

                                        )

                                    }

                                }

                                Text(

                                    text = mod.subtitle,

                                    color = TextSecondary,

                                    fontSize = 9.5.sp,

                                    maxLines = 2,

                                    overflow = TextOverflow.Ellipsis

                                )

                            }



                            Box(

                                modifier = Modifier

                                    .clip(RoundedCornerShape(8.dp))

                                    .background(if (mod.isEnabled) MagicEmerald.copy(alpha = 0.22f) else Color(0xFF1E293B))

                                    .border(

                                        1.dp,

                                        if (mod.isEnabled) MagicEmerald else MagicBorder,

                                        RoundedCornerShape(8.dp)

                                    )

                                    .clickable { onToggleModule(mod.id, !mod.isEnabled) }

                                    .padding(horizontal = 10.dp, vertical = 6.dp)

                                    .testTag("toggle_self_mod_${mod.id}"),

                                contentAlignment = Alignment.Center

                            ) {

                                Text(

                                    text = if (mod.isEnabled) "ĐANG BẬT" else "ĐÃ TẮT 0%",

                                    color = if (mod.isEnabled) MagicEmeraldLight else TextMuted,

                                    fontSize = 9.2.sp,

                                    fontWeight = FontWeight.Black

                                )

                            }

                        }

                    }

                }

            }

            }

        }

    }

}



@androidx.compose.runtime.Immutable

private data class DrainListPrecomputedStats(

    val countAll: Int,

    val countHigh: Int,

    val countSvc: Int,

    val countUser: Int,

    val countProt: Int,

    val stoppableCount: Int

)



@Composable

private fun SelfPowerMetricBox(

    modifier: Modifier = Modifier,

    label: String,

    value: String,

    sub: String,

    color: Color

) {

    Column(

        modifier = modifier

            .clip(RoundedCornerShape(9.dp))

            .background(MagicSurfaceDark)

            .border(0.8.dp, color.copy(alpha = 0.35f), RoundedCornerShape(9.dp))

            .padding(horizontal = 7.dp, vertical = 6.dp),

        verticalArrangement = Arrangement.spacedBy(1.dp)

    ) {

        Text(

            text = label,

            color = TextMuted,

            fontSize = 8.8.sp,

            maxLines = 1,

            overflow = TextOverflow.Ellipsis

        )

        Text(

            text = value,

            color = color,

            fontSize = 11.2.sp,

            fontWeight = FontWeight.Black,

            maxLines = 1,

            overflow = TextOverflow.Ellipsis

        )

        Text(

            text = sub,

            color = TextSecondary,

            fontSize = 8.5.sp,

            maxLines = 1,

            overflow = TextOverflow.Ellipsis

        )

    }

}



