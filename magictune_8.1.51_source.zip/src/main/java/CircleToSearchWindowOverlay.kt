package com.example.core.widget

import com.example.core.perf.ScreenPowerOptimizer

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.ActivityOptions
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.TextUtils
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.compose.ui.geometry.Rect
import androidx.core.content.FileProvider
import com.example.MainActivity
import com.example.R
import com.example.core.assistant.MagicTuneVoiceInteractionService
import com.example.core.permission.AppPermissionChecker
import com.example.core.projection.MediaProjectionHolder
import com.example.core.service.MagicTuneCtsAccessibilityService
import com.example.core.service.NoAccessibilityScreenEngine
import com.example.core.service.SystemFloatingHudOverlay
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

/**
 * Lớp phủ KÍNH TRONG SUỐT XUYÊN THẤU 100% (`WindowManager` `TYPE_APPLICATION_OVERLAY` + `PixelFormat.TRANSLUCENT`)
 * cho Khoanh tròn hỏi AI.
 *
 * KIẾN TRÚC SIÊU TIẾT KIỆM PIN (Ngang chuẩn Dịch Cuộn 100%):
 * 1. Sử dụng 100% Native Android View (`CircleBorderGlowView` tĩnh 0 FPS + `CircleLassoCanvasView` vẽ cục bộ `invalidate(dirtyRect)`),
 *    HOÀN TOÀN KHÔNG khởi tạo Compose `Recomposer` / `LifecycleRegistry` / `ViewModelStore`.
 * 2. Chế độ tìm ảnh chuyển JPEG vùng khoanh trực tiếp sang ứng dụng Google Lens; không dùng Lens web/popup và không tìm thay bằng văn bản/OCR.
 */
object CircleToSearchWindowOverlay {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val overlayScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var captureJob: Job? = null
    private var uploadJob: Job? = null

    @Volatile
    var isShowing: Boolean = false
        private set

    private var windowManager: WindowManager? = null
    private var rootContainer: FrameLayout? = null
    private var screenOffReceiver: BroadcastReceiver? = null
    private var lassoCanvasView: CircleLassoCanvasView? = null
    private var loadingCardContainer: LinearLayout? = null
    private var loadingTitleTv: TextView? = null
    private var loadingSubTv: TextView? = null

    // Bảng Popup hiển thị kết quả Google Tìm Kiếm bằng văn bản màn hình siêu tiết kiệm điện (như Dịch Cuộn)
    private var searchPopupSheet: LinearLayout? = null
    private var searchPopupQueryInput: EditText? = null
    private var searchPopupClearInputBtn: TextView? = null
    private var searchPopupModeBadge: TextView? = null
    private var searchPopupTitle: TextView? = null
    private var circleBorderOverlay: View? = null
    private var circleSearchPill: View? = null
    private var circleOverlayClose: View? = null
    private var searchPopupImagePreviewRow: LinearLayout? = null
    private var searchPopupImagePreview: ImageView? = null
    private var searchPopupImagePreviewLabel: TextView? = null
    private var searchPopupExpandBtn: TextView? = null
    private var searchPopupBackBtn: TextView? = null
    private var searchPopupForwardBtn: TextView? = null
    private var searchPopupSmartCandidatesScroll: HorizontalScrollView? = null
    private var searchPopupSmartCandidatesRow: LinearLayout? = null
    private var searchPopupProgressBar: ProgressBar? = null
    private var searchPopupWebViewContainer: FrameLayout? = null
    private var activePopupWebView: WebView? = null
    private var isPopupExpandedFull: Boolean = false
    private var activeSearchTabMode: String = "ALL" // ALL, IMAGES, SHOP, VIDEO

    @Volatile
    private var lastOverlayAppContext: Context? = null

    @Volatile
    private var preCapturedScreenNodes: List<NoAccessibilityScreenEngine.ScreenTextNode> = emptyList()

    private var lastSelectionBounds: Rect? = null
    private var lastExtractedQueryText: String = ""
    private var lastTranslatedVietnameseQuery: String = ""
    private var lastDetectedLanguageLabel: String = ""
    private var lastCandidatePhrases: List<String> = emptyList()
    private var lastCroppedFile: File? = null
    private var lastCroppedJpegBase64: String? = null
    private var lastVisualLensUrl: String = ""

    data class SmartExtractionResult(
        val primaryQuery: String,
        val candidatePhrases: List<String>,
        val languageBadge: String,
        val isForeignLanguage: Boolean
    )

    private var googleSearchMode = false

    fun show(context: Context, googleSearch: Boolean = false): Boolean {
        val appCtx = context.applicationContext ?: context
        if (!AppPermissionChecker.isFirstTimeWlanActivated(appCtx)) {
            mainHandler.post {
                Toast.makeText(
                    appCtx,
                    "🔒 Khoanh tròn hỏi AI đang KHÓA ĐỎ!\nVui lòng kết nối Gỡ lỗi Wi-Fi 1 lần bằng mã 6 số để kích hoạt!",
                    Toast.LENGTH_LONG
                ).show()
                try {
                    val mainIntent = Intent(appCtx, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        putExtra("TARGET_TAB", "SHIZUKU")
                    }
                    appCtx.startActivity(mainIntent)
                } catch (_: Throwable) {}
            }
            return false
        }

        if (!Settings.canDrawOverlays(appCtx)) {
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                overlayScope.launch(Dispatchers.IO) {
                    try {
                        withTimeoutOrNull(800L) {
                            shell.execute("cmd appops set ${appCtx.packageName} SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1")
                        }
                    } catch (_: Throwable) {}
                }
            }
            return false
        }

        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.postAtFrontOfQueue { showOnMainThread(appCtx, googleSearch) }
            return true
        }
        return showOnMainThread(appCtx, googleSearch)
    }

    private fun createThemedOverlayContext(appCtx: Context): Context {
        val baseCtx = try {
            val dm = appCtx.getSystemService(Context.DISPLAY_SERVICE) as? android.hardware.display.DisplayManager
            val defaultDisplay = dm?.getDisplay(android.view.Display.DEFAULT_DISPLAY)
            if (defaultDisplay != null) {
                appCtx.createDisplayContext(defaultDisplay)
            } else {
                appCtx
            }
        } catch (_: Throwable) {
            appCtx
        }
        return android.view.ContextThemeWrapper(baseCtx, R.style.Theme_AppSearchTranslucent)
    }

    private fun showOnMainThread(appCtx: Context, googleSearch: Boolean): Boolean {
        uploadJob?.cancel()
        googleSearchMode = googleSearch
        return try {
            if (GoogleLiveTranslateOverlay.isRunning) {
                GoogleLiveTranslateOverlay.stop(appCtx)
            }
            MagicLiveFloatingOverlay.dismiss(appCtx)
            try { com.example.core.adb.AdbNsdScanner.getInstance(appCtx).releaseMulticastLock() } catch (_: Throwable) {}
            ScreenPowerOptimizer.onFeatureStarted(appCtx, "CircleToSearch")

            lastSelectionBounds = null
            lastExtractedQueryText = ""
            lastTranslatedVietnameseQuery = ""
            lastDetectedLanguageLabel = ""
            lastCandidatePhrases = emptyList()
            lastCroppedFile = null
            lastCroppedJpegBase64 = null
            lastVisualLensUrl = ""
            isPopupExpandedFull = true
            activeSearchTabMode = "ALL"
            // Lưu snapshot node sẵn có trong RAM (0ms, không kích hoạt Accessibility khi chưa khoanh)
            preCapturedScreenNodes = NoAccessibilityScreenEngine.lastCapturedScreenNodes

            CircleToSearchOverlayActivity.isOverlayActive = true
            CircleToSearchOverlayActivity.lastCreatedTimestampMs = System.currentTimeMillis()
            lastOverlayAppContext = appCtx
            registerScreenOffReceiver(appCtx)
            SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(appCtx, true)

            val existingView = rootContainer
            if (isShowing && existingView != null) {
                if (existingView.isAttachedToWindow) {
                    existingView.alpha = 1f
                    existingView.visibility = View.VISIBLE
                    hideGoogleSearchPopup(destroyWebView = true)
                    setLoadingState(false)
                    existingView.requestFocus()
                    triggerGentleHapticStatic(appCtx)
                    return true
                } else {
                    cleanupDetachedViewOnly()
                }
            }

            val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return false
            windowManager = wm

            val themedCtx = createThemedOverlayContext(appCtx)
            val density = themedCtx.resources.displayMetrics.density
            fun dp(v: Int): Int = (v * density).toInt()
            fun dpF(v: Float): Float = v * density

            val container = object : FrameLayout(themedCtx) {
                override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                    if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                        if (event.action == KeyEvent.ACTION_UP) {
                            val wv = activePopupWebView
                            if (searchPopupSheet?.visibility == View.VISIBLE) {
                                if (wv != null && wv.canGoBack()) {
                                    wv.goBack()
                                    updatePopupNavButtonsState()
                                    return true
                                }
                                hideGoogleSearchPopup(destroyWebView = true)
                                resetSelectionState()
                                return true
                            }
                            if (uploadJob?.isActive == true) {
                                resetSelectionState()
                                return true
                            }
                            dismiss(appCtx)
                        }
                        return true
                    }
                    return super.dispatchKeyEvent(event)
                }
            }.apply {
                setBackgroundColor(Color.TRANSPARENT)
                isFocusable = true
                isFocusableInTouchMode = true
            }

            // 1. Viền 4 màu Google tĩnh 0 FPS (Hardware Layer Cached)
            val borderView = CircleBorderGlowView(themedCtx)
            circleBorderOverlay = borderView
            container.addView(
                borderView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )

            // 2. Bề mặt cảm ứng vẽ khoanh tròn Native Canvas (invalidate vùng thay đổi)
            val lassoView = CircleLassoCanvasView(themedCtx).apply {
                onSelectionCompleted = { normLeft, normTop, normRight, normBottom ->
                    processCroppedRegionAndSearchGoogle(
                        appCtx = appCtx,
                        normLeft = normLeft,
                        normTop = normTop,
                        normRight = normRight,
                        normBottom = normBottom,
                        forceVisualImageSearch = true
                    )
                }
            }
            lassoCanvasView = lassoView
            container.addView(
                lassoView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )

            // 3. Hộp thông báo trạng thái tĩnh (Không dùng spinner quay 120Hz)
            val loadingCard = LinearLayout(themedCtx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                visibility = View.GONE
                setPadding(dp(20), dp(14), dp(20), dp(14))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpF(20f)
                    setColor(Color.parseColor("#F0131314"))
                    setStroke(dp(1), Color.parseColor("#3C4043"))
                }

                val titleTv = TextView(themedCtx).apply {
                    text = "Đang tìm kiếm trên Google..."
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                }
                loadingTitleTv = titleTv
                addView(titleTv)

                val subTv = TextView(themedCtx).apply {
                    text = "Google Tìm kiếm hình ảnh & thông tin"
                    setTextColor(Color.parseColor("#9AA0A6"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    gravity = Gravity.CENTER
                    setPadding(0, dp(4), 0, dp(10))
                }
                loadingSubTv = subTv
                addView(subTv)

                val actionsRow = LinearLayout(themedCtx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                }
                val retryBtn = TextView(themedCtx).apply {
                    text = "🔄 Khoanh lại"
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(dp(14), dp(6), dp(14), dp(6))
                    background = GradientDrawable().apply {
                        cornerRadius = dpF(14f)
                        setColor(Color.parseColor("#1E293B"))
                        setStroke(dp(1), Color.parseColor("#64748B"))
                    }
                    setOnClickListener { resetSelectionState() }
                }
                actionsRow.addView(retryBtn)
                addView(actionsRow)
            }
            loadingCardContainer = loadingCard
            container.addView(
                loadingCard,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                ).apply {
                    leftMargin = dp(24)
                    rightMargin = dp(24)
                }
            )

            // 4. BẢNG POPUP KẾT QUẢ GOOGLE THẾ HỆ MỚI (GỌN GÀNG, SANG TRỌNG, ĐA NGÔN NGỮ, CÓ NÚT LÙI / TIẾN / PHÓNG TO)
            val screenHeight = themedCtx.resources.displayMetrics.heightPixels
            val defaultPopupHeight = (screenHeight * 0.72f).toInt().coerceAtLeast(dp(400))
            val expandedPopupHeight = (screenHeight * 0.91f).toInt().coerceAtLeast(dp(500))

            val popupSheet = LinearLayout(themedCtx).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                isClickable = true
                isFocusable = true
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadii = floatArrayOf(
                        dpF(26f), dpF(26f),
                        dpF(26f), dpF(26f),
                        0f, 0f,
                        0f, 0f
                    )
                    setColor(Color.parseColor("#FC0B1120"))
                    setStroke(dp(1), Color.parseColor("#3338BDF8"))
                }
            }

            fun togglePopupExpandHeight() {
                isPopupExpandedFull = !isPopupExpandedFull
                val targetH = if (isPopupExpandedFull) expandedPopupHeight else defaultPopupHeight
                (popupSheet.layoutParams as? FrameLayout.LayoutParams)?.let { lpSheet ->
                    lpSheet.height = targetH
                    popupSheet.layoutParams = lpSheet
                }
                searchPopupExpandBtn?.text = if (isPopupExpandedFull) "⤓ Thu gọn" else "⤒ Mở rộng"
            }

            // Thanh nắm kéo (Drag Handle) tinh tế trên đỉnh Popup (bấm vào để phóng to / thu nhỏ nhanh)
            val dragHandleContainer = FrameLayout(themedCtx).apply {
                setPadding(0, dp(7), 0, dp(3))
                setOnClickListener {
                    triggerGentleHapticStatic(appCtx)
                    togglePopupExpandHeight()
                }
                val pill = View(themedCtx).apply {
                    background = GradientDrawable().apply {
                        cornerRadius = dpF(3f)
                        setColor(Color.parseColor("#64748B"))
                    }
                }
                addView(pill, FrameLayout.LayoutParams(dp(38), dp(4), Gravity.CENTER))
            }
            popupSheet.addView(
                dragHandleContainer,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )

            // Hàng 1: Cụm nút điều hướng gọn đẹp (◀ | ▶ | ↻) + Nhãn ngôn ngữ thông minh + Mở rộng + Khoanh lại + Đóng
            val topHeaderRow = LinearLayout(themedCtx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(2), dp(10), dp(5))
            }

            fun makeHeaderIconBtn(symbol: String, desc: String, leftMarginDp: Int = 0, onClick: () -> Unit): TextView {
                return TextView(themedCtx).apply {
                    text = symbol
                    contentDescription = desc
                    gravity = Gravity.CENTER
                    setTextColor(Color.parseColor("#F1F5F9"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                    typeface = Typeface.DEFAULT_BOLD
                    minWidth = dp(34)
                    minHeight = dp(32)
                    setPadding(dp(9), dp(4), dp(9), dp(4))
                    background = GradientDrawable().apply {
                        cornerRadius = dpF(10f)
                        setColor(Color.parseColor("#1E293B"))
                        setStroke(dp(1), Color.parseColor("#334155"))
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        if (leftMarginDp > 0) leftMargin = dp(leftMarginDp)
                    }
                    setOnClickListener { onClick() }
                }
            }

            val backBtn = makeHeaderIconBtn("◀", "Quay lại trang trước trong Popup", 0) {
                val wv = activePopupWebView
                if (wv != null && wv.canGoBack()) {
                    triggerGentleHapticStatic(appCtx)
                    wv.goBack()
                    updatePopupNavButtonsState()
                } else {
                    Toast.makeText(appCtx, "ℹ️ Đang ở trang kết quả đầu tiên.", Toast.LENGTH_SHORT).show()
                }
            }.apply { alpha = 0.38f }
            searchPopupBackBtn = backBtn
            topHeaderRow.addView(backBtn)

            val forwardBtn = makeHeaderIconBtn("▶", "Tiến tới trang tiếp theo trong Popup", 4) {
                val wv = activePopupWebView
                if (wv != null && wv.canGoForward()) {
                    triggerGentleHapticStatic(appCtx)
                    wv.goForward()
                    updatePopupNavButtonsState()
                } else {
                    Toast.makeText(appCtx, "ℹ️ Không có trang tiếp theo.", Toast.LENGTH_SHORT).show()
                }
            }.apply { alpha = 0.38f }
            searchPopupForwardBtn = forwardBtn
            topHeaderRow.addView(forwardBtn)

            val reloadBtn = makeHeaderIconBtn("↻", "Tải lại trang trong Popup", 4) {
                triggerGentleHapticStatic(appCtx)
                activePopupWebView?.reload()
            }
            topHeaderRow.addView(reloadBtn)

            val externalBrowserBtn = makeHeaderIconBtn("↗", "Mở trang Google trong trình duyệt mặc định", 4) {
                openCurrentGooglePopupInExternalBrowser(appCtx)
            }
            topHeaderRow.addView(externalBrowserBtn)

            searchPopupModeBadge = null

            val expandChip = TextView(themedCtx).apply {
                text = if (isPopupExpandedFull) "⤓ Thu gọn" else "⤒ Mở rộng"
                contentDescription = "Mở rộng hoặc thu gọn bảng kết quả"
                setTextColor(Color.parseColor("#E2E8F0"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(8), dp(5), dp(8), dp(5))
                background = GradientDrawable().apply {
                    cornerRadius = dpF(10f)
                    setColor(Color.parseColor("#1E293B"))
                    setStroke(dp(1), Color.parseColor("#334155"))
                }
                setOnClickListener {
                    triggerGentleHapticStatic(appCtx)
                    togglePopupExpandHeight()
                }
            }
            searchPopupExpandBtn = expandChip
            topHeaderRow.addView(expandChip)

            val reCircleChip = TextView(themedCtx).apply {
                text = "🔄 Khoanh"
                contentDescription = "Khoanh lại vùng khác"
                setTextColor(Color.parseColor("#93C5FD"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(8), dp(5), dp(8), dp(5))
                background = GradientDrawable().apply {
                    cornerRadius = dpF(10f)
                    setColor(Color.parseColor("#172554"))
                    setStroke(dp(1), Color.parseColor("#2563EB"))
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { leftMargin = dp(4) }
                setOnClickListener {
                    triggerGentleHapticStatic(appCtx)
                    hideGoogleSearchPopup(destroyWebView = true)
                    resetSelectionState()
                }
            }
            topHeaderRow.addView(reCircleChip)

            val closePopupChip = TextView(themedCtx).apply {
                text = "✕"
                contentDescription = "Đóng Popup"
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#FCA5A5"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                minWidth = dp(32)
                minHeight = dp(30)
                setPadding(dp(8), dp(4), dp(8), dp(4))
                background = GradientDrawable().apply {
                    cornerRadius = dpF(10f)
                    setColor(Color.parseColor("#3B1822"))
                    setStroke(dp(1), Color.parseColor("#EF4444"))
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { leftMargin = dp(4) }
                setOnClickListener {
                    dismiss(appCtx)
                }
            }
            topHeaderRow.addView(closePopupChip)
            val popupTitle = TextView(themedCtx).apply {
                text = "Khoanh tìm kiếm Google"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(16), dp(4), dp(12), dp(3))
                maxLines = 1
            }
            searchPopupTitle = popupTitle
            popupSheet.addView(popupTitle)
            popupSheet.addView(topHeaderRow)

            // Hàng 2: Thanh tìm kiếm Omnibox hiện đại (Biểu tượng 🔍 + Ô từ khóa + Nút xóa nhanh × + Nút Tìm Gradient)
            val searchBarWrapper = LinearLayout(themedCtx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(2), dp(10), dp(4))
            }

            val omniboxContainer = LinearLayout(themedCtx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(3), dp(6), dp(3))
                background = GradientDrawable().apply {
                    cornerRadius = dpF(16f)
                    setColor(Color.parseColor("#1E293B"))
                    setStroke(dp(1), Color.parseColor("#475569"))
                }
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val searchLeadIcon = TextView(themedCtx).apply {
                text = "🔍"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setPadding(0, 0, dp(6), 0)
            }
            omniboxContainer.addView(searchLeadIcon)

            val queryEdit = EditText(themedCtx).apply {
                hint = "Từ khóa thông minh trích xuất từ vùng khoanh..."
                setHintTextColor(Color.parseColor("#64748B"))
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setSingleLine(true)
                imeOptions = EditorInfo.IME_ACTION_SEARCH
                setPadding(dp(2), dp(5), dp(4), dp(5))
                background = null
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnEditorActionListener { v, actionId, _ ->
                    if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                        val q = v.text?.toString()?.trim().orEmpty()
                        if (q.isNotBlank()) {
                            hideSoftKeyboard(v)
                            executeSearchByCurrentTab(appCtx, q)
                        }
                        true
                    } else false
                }
            }
            searchPopupQueryInput = queryEdit
            omniboxContainer.addView(queryEdit)

            val clearInputBtn = TextView(themedCtx).apply {
                text = "×"
                contentDescription = "Xóa ô tìm kiếm"
                setTextColor(Color.parseColor("#94A3B8"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(6), dp(2), dp(6), dp(2))
                setOnClickListener {
                    queryEdit.setText("")
                    queryEdit.requestFocus()
                }
            }
            searchPopupClearInputBtn = clearInputBtn
            omniboxContainer.addView(clearInputBtn)

            searchBarWrapper.addView(omniboxContainer)

            val searchGoBtn = TextView(themedCtx).apply {
                text = "Tìm"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(Color.parseColor("#2563EB"), Color.parseColor("#0284C7"))
                ).apply {
                    cornerRadius = dpF(16f)
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { leftMargin = dp(6) }
                setOnClickListener {
                    val q = queryEdit.text?.toString()?.trim().orEmpty()
                    if (q.isNotBlank()) {
                        triggerGentleHapticStatic(appCtx)
                        hideSoftKeyboard(queryEdit)
                        executeSearchByCurrentTab(appCtx, q)
                    }
                }
            }
            searchBarWrapper.addView(searchGoBtn)
            popupSheet.addView(searchBarWrapper)

            // Hàng 2.5 (Tự động hiện khi có Đa Ngôn Ngữ / Bản dịch Tiếng Việt / Các cụm từ khóa tách riêng trong vùng khoanh)
            val smartCandidatesRow = LinearLayout(themedCtx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(10), dp(5))
            }
            searchPopupSmartCandidatesRow = smartCandidatesRow
            val smartCandidatesScroll = HorizontalScrollView(themedCtx).apply {
                isHorizontalScrollBarEnabled = false
                visibility = View.GONE
                addView(smartCandidatesRow)
            }
            searchPopupSmartCandidatesScroll = smartCandidatesScroll
            popupSheet.addView(smartCandidatesScroll)

            // Hàng 3: Thanh Tab Chế Độ Tìm Kiếm (Tất cả | Hình ảnh | Mua sắm | Video | Sao chép | Trình duyệt)
            val quickChipsRow = LinearLayout(themedCtx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(10), dp(6))
            }

            val tabChipViews = mutableMapOf<String, TextView>()

            fun updateTabStyles(selectedTab: String) {
                activeSearchTabMode = selectedTab
                for ((tabKey, tv) in tabChipViews) {
                    val isSelected = tabKey == selectedTab
                    tv.background = GradientDrawable().apply {
                        cornerRadius = dpF(12f)
                        if (isSelected) {
                            setColor(Color.parseColor("#1D4ED8"))
                            setStroke(dp(1), Color.parseColor("#60A5FA"))
                        } else {
                            setColor(Color.parseColor("#1E293B"))
                            setStroke(dp(1), Color.parseColor("#334155"))
                        }
                    }
                    tv.setTextColor(if (isSelected) Color.WHITE else Color.parseColor("#CBD5E1"))
                }
            }

            fun makeModeTabChip(tabKey: String?, label: String, onClick: () -> Unit): TextView {
                val tv = TextView(themedCtx).apply {
                    text = label
                    setTextColor(Color.parseColor("#CBD5E1"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(dp(10), dp(5), dp(10), dp(5))
                    background = GradientDrawable().apply {
                        cornerRadius = dpF(12f)
                        setColor(Color.parseColor("#1E293B"))
                        setStroke(dp(1), Color.parseColor("#334155"))
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { rightMargin = dp(6) }
                    setOnClickListener {
                        if (tabKey != null) {
                            updateTabStyles(tabKey)
                        }
                        onClick()
                    }
                }
                if (tabKey != null) {
                    tabChipViews[tabKey] = tv
                }
                return tv
            }

            quickChipsRow.addView(
                makeModeTabChip("ALL", "🌐 Tất cả") {
                    val q = queryEdit.text?.toString()?.trim().orEmpty().ifBlank { lastExtractedQueryText }
                    if (q.isNotBlank()) {
                        triggerGentleHapticStatic(appCtx)
                        executeSearchByCurrentTab(appCtx, q)
                    }
                }
            )
            quickChipsRow.addView(
                makeModeTabChip("IMAGES", "🖼️ Hình ảnh") {
                    val q = queryEdit.text?.toString()?.trim().orEmpty().ifBlank { lastExtractedQueryText }
                    if (q.isNotBlank()) {
                        triggerGentleHapticStatic(appCtx)
                        executeSearchByCurrentTab(appCtx, q)
                    }
                }
            )
            quickChipsRow.addView(
                makeModeTabChip("SHOP", "🛒 Mua sắm") {
                    val q = queryEdit.text?.toString()?.trim().orEmpty().ifBlank { lastExtractedQueryText }
                    if (q.isNotBlank()) {
                        triggerGentleHapticStatic(appCtx)
                        executeSearchByCurrentTab(appCtx, q)
                    }
                }
            )
            quickChipsRow.addView(
                makeModeTabChip("VIDEO", "🎥 Video") {
                    val q = queryEdit.text?.toString()?.trim().orEmpty().ifBlank { lastExtractedQueryText }
                    if (q.isNotBlank()) {
                        triggerGentleHapticStatic(appCtx)
                        executeSearchByCurrentTab(appCtx, q)
                    }
                }
            )
            quickChipsRow.addView(
                makeModeTabChip(null, "📸 Mở ứng dụng") {
                    val file = lastCroppedFile
                    if (file != null && file.exists()) {
                        triggerGentleHapticStatic(appCtx)
                        if (sendImageToExternalGoogleLensStatic(appCtx, file)) {
                            dismiss(appCtx)
                        } else {
                            Toast.makeText(
                                appCtx,
                                "💡 Chưa mở được ứng dụng tìm kiếm ảnh. Kết quả vẫn đang hiển thị trong Popup.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        Toast.makeText(appCtx, "ℹ️ Hãy khoanh vùng hình ảnh trên màn hình trước.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
            quickChipsRow.addView(
                makeModeTabChip(null, "📋 Sao chép") {
                    val txt = queryEdit.text?.toString()?.trim().orEmpty().ifBlank { lastExtractedQueryText }
                    val copyPayload = if (lastTranslatedVietnameseQuery.isNotBlank() &&
                        !lastTranslatedVietnameseQuery.equals(txt, ignoreCase = true)
                    ) {
                        "$txt\n(Dịch: $lastTranslatedVietnameseQuery)"
                    } else {
                        txt
                    }
                    if (copyPayload.isNotBlank()) {
                        try {
                            val cb = appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            cb?.setPrimaryClip(ClipData.newPlainText("GoogleSearch", copyPayload))
                            Toast.makeText(appCtx, "✅ Đã sao chép: ${copyPayload.take(48)}", Toast.LENGTH_SHORT).show()
                        } catch (_: Throwable) {}
                    } else {
                        Toast.makeText(appCtx, "ℹ️ Chưa có văn bản để sao chép.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
            quickChipsRow.addView(
                makeModeTabChip(null, "↗ Trình duyệt") {
                    val currentUrl = activePopupWebView?.url?.takeIf { it.startsWith("http") }
                        ?: lastVisualLensUrl.takeIf { it.startsWith("http") }
                        ?: queryEdit.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let {
                            "https://www.google.com/search?q=${Uri.encode(it)}&hl=vi"
                        }
                    if (!currentUrl.isNullOrBlank()) {
                        try {
                            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl)).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivitySafeStatic(appCtx, browserIntent)
                            dismiss(appCtx)
                        } catch (_: Throwable) {}
                    }
                }
            )
            updateTabStyles("ALL")

            val chipsScroll = HorizontalScrollView(themedCtx).apply {
                isHorizontalScrollBarEnabled = false
                addView(quickChipsRow)
            }
            popupSheet.addView(chipsScroll)

            // Keep the selected crop visible in the results popup so users can verify which image was sent.
            val imagePreviewRow = LinearLayout(themedCtx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                visibility = View.GONE
                setPadding(dp(10), dp(4), dp(10), dp(6))
            }
            val imagePreview = ImageView(themedCtx).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = GradientDrawable().apply {
                    cornerRadius = dpF(8f)
                    setColor(Color.parseColor("#1E293B"))
                    setStroke(dp(1), Color.parseColor("#475569"))
                }
                clipToOutline = true
            }
            imagePreviewRow.addView(imagePreview, LinearLayout.LayoutParams(dp(48), dp(40)))
            val imagePreviewLabel = TextView(themedCtx).apply {
                text = "Ảnh vùng khoanh"
                setTextColor(Color.parseColor("#CBD5E1"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setPadding(dp(9), 0, 0, 0)
            }
            imagePreviewRow.addView(imagePreviewLabel)
            searchPopupImagePreviewRow = imagePreviewRow
            searchPopupImagePreview = imagePreview
            searchPopupImagePreviewLabel = imagePreviewLabel
            popupSheet.addView(imagePreviewRow)

            val progressBar = ProgressBar(themedCtx, null, android.R.attr.progressBarStyleHorizontal).apply {
                isIndeterminate = false
                max = 100
                progress = 0
                visibility = View.GONE
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    dp(3)
                )
            }
            searchPopupProgressBar = progressBar
            popupSheet.addView(progressBar)

            val webContainer = FrameLayout(themedCtx).apply {
                setBackgroundColor(Color.parseColor("#0F172A"))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    0,
                    1f
                )
            }
            searchPopupWebViewContainer = webContainer
            popupSheet.addView(webContainer)

            searchPopupSheet = popupSheet
            container.addView(
                popupSheet,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    if (isPopupExpandedFull) expandedPopupHeight else defaultPopupHeight,
                    Gravity.BOTTOM
                )
            )

            // 5. Thanh tìm kiếm Google chuẩn 1:1 theo ảnh thực tế: viên thuốc mờ ngoài, bên trong gồm capsule tìm kiếm (G + Hỏi + Mic) và nút tròn dịch (Translate)
            val googleSearchPill = LinearLayout(themedCtx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(60)
                setPadding(dp(4), dp(4), dp(4), dp(4))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpF(30f)
                    setColor(Color.parseColor("#73FFFFFF"))
                }
            }

            // Nút "Trò chuyện với trợ lý" bên trái mở bảng MagicLive
            val searchOmnibox = LinearLayout(themedCtx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(52)
                setPadding(dp(14), 0, dp(12), 0)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpF(26f)
                    setColor(Color.parseColor("#FFFFFF"))
                }
                elevation = dp(2).toFloat()
                isClickable = true
                setOnClickListener { if (googleSearchMode) openGoogleTextSearchPopup(appCtx) else launchMagicLiveFloatingOverlayStatic(appCtx) }
            }

            // Trợ lý Sparkle Icon
            searchOmnibox.addView(ImageView(themedCtx).apply {
                setImageResource(R.drawable.ic_cts_sparkle)
                setColorFilter(Color.parseColor("#4285F4"))
                contentDescription = "Trợ lý"
            }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(10) })

            // Nhãn "Trò chuyện với trợ lý"
            searchOmnibox.addView(TextView(themedCtx).apply {
                text = if (googleSearchMode) "Tìm kiếm bằng văn bản" else "Trò chuyện với trợ lý"
                setTextColor(Color.parseColor("#202124"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                gravity = Gravity.CENTER_VERTICAL
                isSingleLine = true
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))

            // Microphone icon
            searchOmnibox.addView(ImageView(themedCtx).apply {
                setImageResource(R.drawable.ic_cts_mic)
                setColorFilter(Color.parseColor("#5F6368"))
                contentDescription = "Hỏi bằng giọng nói"
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }, LinearLayout.LayoutParams(dp(32), dp(32)))

            googleSearchPill.addView(searchOmnibox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))

            // Translate circular button (Google Translate 文A icon)
            val translateCircleBtn = FrameLayout(themedCtx).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#FFFFFF"))
                }
                elevation = dp(2).toFloat()
                isClickable = true
                setOnClickListener { activateInstantGoogleTranslateAndScroll(appCtx) }
                addView(ImageView(themedCtx).apply {
                    setImageResource(R.drawable.ic_cts_translate)
                    setColorFilter(Color.parseColor("#3C4043"))
                    contentDescription = "Dịch màn hình"
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER))
            }

            val translateLp = LinearLayout.LayoutParams(dp(52), dp(52)).apply {
                leftMargin = dp(6)
            }
            googleSearchPill.addView(translateCircleBtn, translateLp)

            val cameraButton = TextView(themedCtx).apply {
                text = "📷"
                contentDescription = if (googleSearchMode) "Chụp ảnh tìm Google" else "Chụp ảnh hỏi AI"
                gravity = Gravity.CENTER
                textSize = 20f
                setOnClickListener {
                    try {
                        MagicLivePhotoActivity.launch(appCtx, "camera", circle = true, googleSearch = googleSearchMode)
                        dismiss(appCtx)
                    } catch (_: Exception) {
                        Toast.makeText(appCtx, "Không mở được camera.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            // Chỉ giữ nút chụp ảnh ở chế độ hỏi AI; Google dùng thao tác khoanh trực tiếp.
            if (!googleSearchMode) {
                googleSearchPill.addView(cameraButton, LinearLayout.LayoutParams(dp(44), dp(52)))
            }

            val bottomPillLp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                dp(60),
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply {
                leftMargin = dp(14)
                rightMargin = dp(14)
                bottomMargin = dp(26)
            }
            circleSearchPill = googleSearchPill
            container.addView(googleSearchPill, bottomPillLp)

            val topCloseBtn = FrameLayout(themedCtx).apply {
                contentDescription = "Đóng khoanh tròn tìm kiếm"
                isClickable = true
                isFocusable = true
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#CC10243A"))
                }
                addView(ImageView(themedCtx).apply {
                    setImageResource(R.drawable.ic_cts_close)
                    setColorFilter(Color.WHITE)
                }, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
                setOnClickListener { dismiss(appCtx) }
            }
            circleOverlayClose = topCloseBtn
            container.addView(topCloseBtn, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.START).apply {
                leftMargin = dp(16)
                topMargin = dp(58)
            })

            // Căn chỉnh lề an toàn theo StatusBar & NavigationBar hệ thống
            container.setOnApplyWindowInsetsListener { _, insets ->
                try {
                    val bottomInset: Int
                    val topInset: Int
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        val sysBars = insets.getInsets(WindowInsets.Type.systemBars())
                        bottomInset = sysBars.bottom
                        topInset = sysBars.top
                    } else {
                        @Suppress("DEPRECATION")
                        bottomInset = insets.systemWindowInsetBottom
                        @Suppress("DEPRECATION")
                        topInset = insets.systemWindowInsetTop
                    }
                    (googleSearchPill.layoutParams as? FrameLayout.LayoutParams)?.let { p ->
                        p.bottomMargin = bottomInset + dp(26)
                        googleSearchPill.layoutParams = p
                    }
                    (topCloseBtn.layoutParams as? FrameLayout.LayoutParams)?.let { p ->
                        p.topMargin = topInset + dp(16)
                        topCloseBtn.layoutParams = p
                    }
                } catch (_: Throwable) {}
                insets
            }

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
                    WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                dimAmount = 0f
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
                softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                title = "MagicTuneCircleToSearchGlassOverlay"
                ScreenPowerOptimizer.applyEcoRefreshRateToWindow(this)
            }

            wm.addView(container, lp)
            container.alpha = 1f
            container.visibility = View.VISIBLE
            container.requestFocus()
            rootContainer = container
            isShowing = true
            triggerGentleHapticStatic(appCtx)
            true
        } catch (_: Throwable) {
            cleanupDetachedViewOnly()
            false
        }
    }

    /**
     * Đọc trước cây văn bản đang hiển thị trên màn hình bằng đúng cơ chế của Dịch Cuộn (`NoAccessibilityScreenEngine` / `WindowNode`),
     * hoàn toàn KHÔNG chụp ảnh màn hình, KHÔNG cấp phát Bitmap.
     */
    private fun prewarmScreenNodesLikeScrollTranslate(appCtx: Context) {
        captureJob?.cancel()
        captureJob = overlayScope.launch(Dispatchers.IO) {
            try {
                var nodes = NoAccessibilityScreenEngine.extractVisibleScreenNodesNow(appCtx)
                if (nodes.isEmpty()) {
                    MagicTuneCtsAccessibilityService.beginTemporaryBurst(1200L)
                    try {
                        NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(appCtx, 1200L)
                        val svc = MagicTuneCtsAccessibilityService.awaitServiceInstance(appCtx, 650L)
                        if (svc != null) {
                            nodes = NoAccessibilityScreenEngine.extractVisibleScreenNodesNow(appCtx)
                        }
                    } catch (_: Throwable) {
                    } finally {
                        MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(appCtx, 100L)
                    }
                }
                if (nodes.isNotEmpty()) {
                    preCapturedScreenNodes = nodes
                }
            } catch (_: Throwable) {}
        }
    }

    private fun hideSoftKeyboard(view: View) {
        try {
            val imm = view.context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.hideSoftInputFromWindow(view.windowToken, 0)
        } catch (_: Throwable) {}
    }

    private fun updatePopupNavButtonsState() {
        val wv = activePopupWebView
        val canBack = try { wv?.canGoBack() == true } catch (_: Throwable) { false }
        val canFwd = try { wv?.canGoForward() == true } catch (_: Throwable) { false }
        searchPopupBackBtn?.let { btn ->
            btn.alpha = if (canBack) 1.0f else 0.38f
            btn.isEnabled = true
        }
        searchPopupForwardBtn?.let { btn ->
            btn.alpha = if (canFwd) 1.0f else 0.38f
            btn.isEnabled = true
        }
    }

    /**
     * Hiển thị thanh Gợi Ý Từ Khóa & Bản Dịch Đa Ngôn Ngữ ngay dưới thanh tìm kiếm:
     * - Khi người dùng khoanh vào tiếng Trung / Nhật / Hàn / Anh / Thái / Nga..., hiển thị ngay nút
     *   `🇻🇳 Dịch: ...` và `🔤 Gốc: ...` để chuyển đổi 1 chạm.
     * - Hiển thị các cụm từ thành phần trong vùng khoanh để người dùng có thể chọn chính xác từng mã SP / tên hãng mà không bao giờ bị lẫn từ rác.
     */
    private fun refreshSmartCandidateChipsUI(
        appCtx: Context,
        primaryQuery: String,
        translatedVi: String,
        candidates: List<String>
    ) {
        val row = searchPopupSmartCandidatesRow ?: return
        val scroll = searchPopupSmartCandidatesScroll ?: return
        val themedCtx = row.context
        val density = themedCtx.resources.displayMetrics.density
        fun dp(v: Int): Int = (v * density).toInt()
        fun dpF(v: Float): Float = v * density

        row.removeAllViews()

        fun addCandidateChip(
            prefix: String,
            displayText: String,
            queryToRun: String,
            bgHex: String,
            borderHex: String,
            textHex: String = "#F8FAFC"
        ) {
            val cleanQ = queryToRun.trim()
            if (cleanQ.isBlank()) return
            val chip = TextView(themedCtx).apply {
                text = "$prefix ${displayText.take(42)}"
                setTextColor(Color.parseColor(textHex))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(9), dp(4), dp(9), dp(4))
                background = GradientDrawable().apply {
                    cornerRadius = dpF(10f)
                    setColor(Color.parseColor(bgHex))
                    setStroke(dp(1), Color.parseColor(borderHex))
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { rightMargin = dp(6) }
                setOnClickListener {
                    triggerGentleHapticStatic(appCtx)
                    executeSearchByCurrentTab(appCtx, cleanQ)
                }
            }
            row.addView(chip)
        }

        val hasDistinctTranslation = translatedVi.isNotBlank() &&
            !translatedVi.equals(primaryQuery, ignoreCase = true)

        if (hasDistinctTranslation) {
            // Strip "(≈ ... đ)" price suffix when constructing the pure Vietnamese search query
            val pureViSearchQuery = translatedVi.replace(Regex("""\s*\(≈[^)]+\)"""), "").trim()
                .ifBlank { translatedVi }
            addCandidateChip(
                prefix = "🇻🇳 Dịch:",
                displayText = translatedVi,
                queryToRun = pureViSearchQuery,
                bgHex = "#064E3B",
                borderHex = "#10B981",
                textHex = "#A7F3D0"
            )
            addCandidateChip(
                prefix = "🔤 Gốc:",
                displayText = primaryQuery,
                queryToRun = primaryQuery,
                bgHex = "#1E1B4B",
                borderHex = "#6366F1",
                textHex = "#C7D2FE"
            )
            addCandidateChip(
                prefix = "🌐 Song ngữ:",
                displayText = "$primaryQuery $pureViSearchQuery",
                queryToRun = "$primaryQuery $pureViSearchQuery",
                bgHex = "#0F172A",
                borderHex = "#38BDF8",
                textHex = "#BAE6FD"
            )
        }

        for (cand in candidates) {
            if (!cand.equals(primaryQuery, ignoreCase = true)) {
                addCandidateChip(
                    prefix = "🎯",
                    displayText = cand,
                    queryToRun = cand,
                    bgHex = "#1E293B",
                    borderHex = "#475569",
                    textHex = "#E2E8F0"
                )
            }
        }

        scroll.visibility = if (row.childCount > 0) View.VISIBLE else View.GONE
    }

    private fun executeSearchByCurrentTab(
        appCtx: Context,
        queryText: String,
        customBadge: String? = null
    ) {
        val cleanQuery = queryText.trim()
        if (cleanQuery.isBlank()) return
        lastExtractedQueryText = cleanQuery
        val encoded = Uri.encode(cleanQuery)
        val (url, defaultBadge) = when (activeSearchTabMode) {
            "IMAGES" -> "https://www.google.com/search?q=$encoded&udm=2&hl=vi" to "🖼️ Hình ảnh • ${lastDetectedLanguageLabel.ifBlank { "Chính xác cao" }}"
            "SHOP" -> "https://www.google.com/search?q=$encoded&tbm=shop&hl=vi" to "🛒 Mua sắm • ${lastDetectedLanguageLabel.ifBlank { "Chính xác cao" }}"
            "VIDEO" -> "https://www.google.com/search?q=$encoded&tbm=vid&hl=vi" to "🎥 Video • ${lastDetectedLanguageLabel.ifBlank { "Chính xác cao" }}"
            else -> "https://www.google.com/search?q=$encoded&hl=vi" to (customBadge ?: "✨ ${lastDetectedLanguageLabel.ifBlank { "Google Tìm Kiếm • Chính xác cao" }}")
        }
        showUrlInGooglePopup(
            appCtx = appCtx,
            url = url,
            displayQuery = cleanQuery,
            badgeLabel = customBadge ?: defaultBadge,
            useDesktopUserAgent = false
        )
    }

    private fun openGoogleTextSearchPopup(appCtx: Context) {
        showUrlInGooglePopup(appCtx, "https://www.google.com/search?hl=vi", "", "Google • Tìm kiếm bằng văn bản", false)
        searchPopupQueryInput?.requestFocus()
        searchPopupQueryInput?.post {
            val imm = appCtx.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.showSoftInput(searchPopupQueryInput, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun openCurrentGooglePopupInExternalBrowser(appCtx: Context) {
        val query = searchPopupQueryInput?.text?.toString()?.trim().orEmpty()
        val url = activePopupWebView?.url?.takeIf { it.startsWith("https://") || it.startsWith("http://") }
            ?: query.takeIf { it.isNotBlank() }?.let { "https://www.google.com/search?q=${Uri.encode(it)}&hl=vi" }
            ?: "https://www.google.com/search?hl=vi"
        try {
            startActivitySafeStatic(
                appCtx,
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            dismiss(appCtx)
        } catch (_: Throwable) {
            Toast.makeText(appCtx, "Không tìm thấy trình duyệt để mở trang này.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showPopupWebElementActions(view: View, appCtx: Context): Boolean {
        val webView = view as? WebView ?: return false
        val hit = webView.hitTestResult ?: return false
        val isImage = hit.type == WebView.HitTestResult.IMAGE_TYPE ||
            hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
        val isLink = hit.type == WebView.HitTestResult.ANCHOR_TYPE || isImage
        if (!isLink) return false
        val target = hit.extra?.trim().orEmpty()
        if (!target.startsWith("https://") && !target.startsWith("http://")) return false

        val options = if (isImage) {
            arrayOf("Lưu ảnh vào máy", "Sao chép đường dẫn ảnh", "Mở liên kết trong trình duyệt")
        } else {
            arrayOf("Sao chép đường dẫn", "Mở liên kết trong trình duyệt")
        }
        val dialog = AlertDialog.Builder(webView.context)
            .setItems(options) { _, which ->
                when (options.getOrNull(which)) {
                    "Lưu ảnh vào máy" -> downloadPopupImage(webView, target, appCtx)
                    "Sao chép đường dẫn ảnh", "Sao chép đường dẫn" -> {
                        try {
                            val clipboard = appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            clipboard?.setPrimaryClip(ClipData.newPlainText("URL", target))
                            Toast.makeText(appCtx, "Đã sao chép đường dẫn.", Toast.LENGTH_SHORT).show()
                        } catch (_: Throwable) {}
                    }
                    else -> openWebUrlInExternalBrowser(target, appCtx)
                }
            }
            .create()
        try {
            // This WebView belongs to a TYPE_APPLICATION_OVERLAY window, not an Activity.
            // A default AlertDialog requests an Activity token and can throw BadTokenException.
            val overlayWindowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            }
            dialog.window?.setType(overlayWindowType)
            dialog.show()
        } catch (_: WindowManager.BadTokenException) {
            Toast.makeText(appCtx, "Không thể mở menu trên popup lúc này. Hãy thử nhấn giữ lại.", Toast.LENGTH_SHORT).show()
        } catch (_: Throwable) {
            Toast.makeText(appCtx, "Không thể mở menu thao tác ảnh lúc này.", Toast.LENGTH_SHORT).show()
        }
        return true
    }

    private fun openWebUrlInExternalBrowser(url: String, appCtx: Context) {
        try {
            startActivitySafeStatic(
                appCtx,
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Throwable) {
            Toast.makeText(appCtx, "Không tìm thấy trình duyệt để mở liên kết.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun downloadPopupImage(webView: WebView, url: String, appCtx: Context) {
        try {
            val uri = Uri.parse(url)
            val manager = appCtx.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
                ?: throw IllegalStateException("DownloadManager unavailable")
            val rawName = uri.lastPathSegment.orEmpty().substringBefore('?')
            val safeName = rawName.replace(Regex("[^A-Za-z0-9._-]"), "_").takeLast(80)
                .ifBlank { "google_image_${System.currentTimeMillis()}" }
                .let { if (it.contains('.')) it else "$it.jpg" }
            val request = DownloadManager.Request(uri)
                .setTitle("Đang lưu ảnh Google")
                .setDescription(safeName)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES, "MagicTune/$safeName")
            CookieManager.getInstance().getCookie(url)?.takeIf { it.isNotBlank() }?.let {
                request.addRequestHeader("Cookie", it)
            }
            request.addRequestHeader("User-Agent", webView.settings.userAgentString)
            manager.enqueue(request)
            Toast.makeText(appCtx, "Đang tải ảnh; tiến trình sẽ hiện trong thông báo.", Toast.LENGTH_SHORT).show()
        } catch (_: Throwable) {
            Toast.makeText(appCtx, "Không thể lưu ảnh này từ trang hiện tại.", Toast.LENGTH_SHORT).show()
        }
    }

    fun searchCapturedPhoto(appCtx: Context, imageBase64: String) {
        if (!show(appCtx, googleSearch = true)) return
        overlayScope.launch {
            val bytes = try { Base64.decode(imageBase64, Base64.DEFAULT) } catch (_: Throwable) { null }
            val imageBytes = bytes?.takeIf { it.isNotEmpty() }
            if (imageBytes == null) {
                Toast.makeText(appCtx, "Không đọc được ảnh vừa chụp.", Toast.LENGTH_LONG).show()
                return@launch
            }
            val imageFile = withContext(Dispatchers.IO) {
                runCatching {
                    val dir = File(appCtx.cacheDir, "cts_shares").apply { mkdirs() }
                    File(dir, "google_lens_camera_${System.currentTimeMillis()}.jpg").apply {
                        writeBytes(imageBytes)
                    }
                }.getOrNull()
            }
            if (imageFile != null && sendImageToExternalGoogleLensStatic(appCtx, imageFile)) {
                dismiss(appCtx, keepFollowUpSession = true)
            } else {
                Toast.makeText(appCtx, "Không mở được ứng dụng Google Lens để nhận ảnh vừa chụp.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showCroppedImagePreview(file: File?, label: String) {
        val row = searchPopupImagePreviewRow ?: return
        val preview = searchPopupImagePreview ?: return
        if (file == null || !file.isFile) {
            preview.setImageDrawable(null)
            row.visibility = View.GONE
            return
        }
        preview.setImageURI(Uri.fromFile(file))
        searchPopupImagePreviewLabel?.text = label
        row.visibility = View.VISIBLE
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun getOrCreateLowPowerPopupWebView(appCtx: Context): WebView? {
        activePopupWebView?.let { return it }
        val container = searchPopupWebViewContainer ?: return null
        return try {
            val themedCtx = container.context
            val wv = WebView(themedCtx).apply {
                // Tắt tạo lớp phần cứng GPU riêng biệt cho WebView để tiết kiệm ~8MB VRAM và điện năng GPU
                setLayerType(View.LAYER_TYPE_NONE, null)
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = false
                    // Chặn tự động phát video/âm thanh quảng cáo để tiết kiệm pin tối đa
                    mediaPlaybackRequiresUserGesture = true
                    loadsImagesAutomatically = true
                    blockNetworkImage = false
                    cacheMode = WebSettings.LOAD_DEFAULT
                    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    builtInZoomControls = true
                    displayZoomControls = false
                    setSupportZoom(true)
                }
                try {
                    CookieManager.getInstance().setAcceptCookie(true)
                } catch (_: Throwable) {}

                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                        searchPopupProgressBar?.let { pb ->
                            if (newProgress in 1..99) {
                                pb.visibility = View.VISIBLE
                                pb.progress = newProgress
                            } else {
                                pb.visibility = View.GONE
                            }
                        }
                        updatePopupNavButtonsState()
                    }
                }

                // Keep normal WebView text selection and copy behavior. Show a small action
                // menu only when a link or image itself is long-pressed.
                setOnLongClickListener { view -> showPopupWebElementActions(view, appCtx) }

                webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        super.onPageStarted(view, url, favicon)
                        updatePopupNavButtonsState()
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        updatePopupNavButtonsState()
                    }

                    override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                        super.doUpdateVisitedHistory(view, url, isReload)
                        updatePopupNavButtonsState()
                    }

                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val url = request?.url?.toString().orEmpty()
                        if (url.isBlank()) return false
                        if (url.startsWith("http://") || url.startsWith("https://")) {
                            return false
                        }
                        val resolvedHttps = CircleToSearchOverlayActivity.resolveIntentToHttpsUrl(url)
                        if (!resolvedHttps.isNullOrBlank()) {
                            view?.loadUrl(resolvedHttps)
                            return true
                        }
                        return try {
                            val extIntent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivitySafeStatic(appCtx, extIntent)
                            true
                        } catch (_: Throwable) {
                            true
                        }
                    }
                }
            }
            container.removeAllViews()
            container.addView(
                wv,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            activePopupWebView = wv
            updatePopupNavButtonsState()
            wv
        } catch (_: Throwable) {
            null
        }
    }

    private fun loadGoogleSearchQueryInPopup(
        appCtx: Context,
        queryText: String,
        badgeLabel: String = "✨ Google Tìm Kiếm • Chính xác cao"
    ) {
        executeSearchByCurrentTab(appCtx, queryText, customBadge = badgeLabel)
    }

    private fun showUrlInGooglePopup(
        appCtx: Context,
        url: String,
        displayQuery: String,
        badgeLabel: String,
        useDesktopUserAgent: Boolean
    ) {
        setLoadingState(false)
        lassoCanvasView?.isDrawingEnabled = false
        searchPopupModeBadge?.text = badgeLabel
        if (displayQuery.isNotBlank()) {
            searchPopupQueryInput?.setText(displayQuery)
        } else {
            searchPopupQueryInput?.setText("")
            searchPopupQueryInput?.hint = "Nhập từ khóa hoặc tìm tiếp trên Google..."
        }
        searchPopupSheet?.visibility = View.VISIBLE
        circleBorderOverlay?.visibility = View.GONE
        lassoCanvasView?.visibility = View.GONE
        circleSearchPill?.visibility = View.GONE
        circleOverlayClose?.visibility = View.GONE

        val wv = getOrCreateLowPowerPopupWebView(appCtx)
        if (wv != null) {
            try {
                wv.onResume()
                wv.resumeTimers()
                if (useDesktopUserAgent) {
                    try {
                        val cm = CookieManager.getInstance()
                        cm.setCookie("https://lens.google.com", CircleToSearchOverlayActivity.LENS_DEFAULT_COOKIE)
                        cm.setCookie("https://www.google.com", CircleToSearchOverlayActivity.LENS_DEFAULT_COOKIE)
                    } catch (_: Throwable) {}
                }
                wv.settings.userAgentString = if (useDesktopUserAgent) {
                    CircleToSearchOverlayActivity.LENS_DESKTOP_USER_AGENT
                } else {
                    null
                }
                wv.loadUrl(url)
                updatePopupNavButtonsState()
            } catch (_: Throwable) {}
        } else {
            // Dự phòng nếu thiết bị không có Android System WebView
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivitySafeStatic(appCtx, browserIntent)
                dismiss(appCtx)
            } catch (_: Throwable) {}
        }
    }

    private fun hideGoogleSearchPopup(destroyWebView: Boolean) {
        searchPopupSheet?.visibility = View.GONE
        searchPopupProgressBar?.visibility = View.GONE
        circleBorderOverlay?.visibility = View.VISIBLE
        lassoCanvasView?.visibility = View.VISIBLE
        circleSearchPill?.visibility = View.VISIBLE
        circleOverlayClose?.visibility = View.VISIBLE
        val wv = activePopupWebView
        if (wv != null) {
            try {
                wv.stopLoading()
                wv.onPause()
                wv.pauseTimers()
                if (destroyWebView) {
                    activePopupWebView = null
                    searchPopupWebViewContainer?.removeAllViews()
                    wv.loadUrl("about:blank")
                    wv.removeAllViews()
                    wv.destroy()
                }
            } catch (_: Throwable) {}
        }
    }

    private fun setLoadingState(loading: Boolean, title: String? = null, subtitle: String? = null) {
        lassoCanvasView?.isDrawingEnabled = !loading && (searchPopupSheet?.visibility != View.VISIBLE)
        if (title != null) loadingTitleTv?.text = title
        if (subtitle != null) loadingSubTv?.text = subtitle
        loadingCardContainer?.visibility = if (loading) View.VISIBLE else View.GONE
    }

    private fun cleanupDetachedViewOnly() {
        isShowing = false
        hideGoogleSearchPopup(destroyWebView = true)
        val view = rootContainer
        rootContainer = null
        lassoCanvasView = null
        loadingCardContainer = null
        loadingTitleTv = null
        loadingSubTv = null
        searchPopupSheet = null
        searchPopupQueryInput = null
        searchPopupClearInputBtn = null
        searchPopupModeBadge = null
        searchPopupExpandBtn = null
        searchPopupBackBtn = null
        searchPopupForwardBtn = null
        searchPopupSmartCandidatesScroll = null
        searchPopupSmartCandidatesRow = null
        searchPopupProgressBar = null
        searchPopupWebViewContainer = null
        searchPopupImagePreview?.setImageDrawable(null)
        searchPopupImagePreview = null
        searchPopupImagePreviewLabel = null
        searchPopupImagePreviewRow = null
        if (view != null) {
            try {
                windowManager?.removeViewImmediate(view)
            } catch (_: Throwable) {}
        }
        windowManager = null
    }

    private fun resetSelectionState() {
        uploadJob?.cancel()
        uploadJob = null
        lastSelectionBounds = null
        lastVisualLensUrl = ""
        hideGoogleSearchPopup(destroyWebView = true)
        lassoCanvasView?.clearStroke()
        setLoadingState(false)
    }

    fun dismiss(
        context: Context? = null,
        keepFollowUpSession: Boolean = false,
        preserveLiveScrollForHandoff: Boolean = false
    ) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { dismissInternal(context, keepFollowUpSession, preserveLiveScrollForHandoff) }
        } else {
            dismissInternal(context, keepFollowUpSession, preserveLiveScrollForHandoff)
        }
    }

    private fun registerScreenOffReceiver(appCtx: Context) {
        if (screenOffReceiver != null) return
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                    dismiss(appCtx)
                }
            }
        }
        try {
            val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                appCtx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                appCtx.registerReceiver(receiver, filter)
            }
            screenOffReceiver = receiver
        } catch (_: Throwable) {}
    }

    private fun unregisterScreenOffReceiver(context: Context?) {
        val receiver = screenOffReceiver ?: return
        screenOffReceiver = null
        val ctx = context?.applicationContext ?: lastOverlayAppContext ?: return
        try {
            ctx.unregisterReceiver(receiver)
        } catch (_: Throwable) {}
    }

    private fun dismissInternal(
        context: Context?,
        keepFollowUpSession: Boolean = false,
        preserveLiveScrollForHandoff: Boolean = false
    ) {
        context?.let { ScreenPowerOptimizer.onFeatureStopped(it, "CircleToSearch") }
        if (!keepFollowUpSession) {
            MagicLiveFloatingOverlay.clearPendingCircleFollowUpIfUnused()
        }
        unregisterScreenOffReceiver(context)
        captureJob?.cancel()
        captureJob = null
        uploadJob?.cancel()
        uploadJob = null
        isShowing = false
        CircleToSearchOverlayActivity.isOverlayActive = false
        lastCroppedFile = null
        lastCroppedJpegBase64 = null
        lastVisualLensUrl = ""

        hideGoogleSearchPopup(destroyWebView = true)

        val view = rootContainer
        rootContainer = null
        lassoCanvasView = null
        loadingCardContainer = null
        loadingTitleTv = null
        loadingSubTv = null
        searchPopupSheet = null
        searchPopupQueryInput = null
        searchPopupClearInputBtn = null
        searchPopupModeBadge = null
        searchPopupExpandBtn = null
        searchPopupBackBtn = null
        searchPopupForwardBtn = null
        searchPopupSmartCandidatesScroll = null
        searchPopupSmartCandidatesRow = null
        searchPopupProgressBar = null
        searchPopupWebViewContainer = null
        searchPopupImagePreview?.setImageDrawable(null)
        searchPopupImagePreview = null
        searchPopupImagePreviewLabel = null
        searchPopupImagePreviewRow = null
        if (view != null) {
            try {
                windowManager?.removeViewImmediate(view)
            } catch (_: Throwable) {
                try {
                    windowManager?.removeView(view)
                } catch (_: Throwable) {}
            }
        }
        windowManager = null

        val resolveCtx = context?.applicationContext ?: lastOverlayAppContext
        resolveCtx?.let { appCtx ->
            SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(appCtx, false)
            // Skip cleanup only for the deliberate handoff into live translation.
            if (!preserveLiveScrollForHandoff && !GoogleLiveTranslateOverlay.isRunning) {
                NoAccessibilityScreenEngine.isLiveScrollTranslateActive = false
                MagicTuneCtsAccessibilityService.clearLiveScrollLease()
                MagicTuneCtsAccessibilityService.updateEventSubscriptionForLiveScroll(false)
                MagicTuneCtsAccessibilityService.enterDeepSleepNow(appCtx, forceImmediate = true)
                com.example.core.projection.MediaProjectionHolder.releaseIfNoActiveConsumer(appCtx)
            }
            try {
                com.example.core.service.MagicTuneKeepAliveService.syncServiceNeed(appCtx, "Circle overlay closed")
            } catch (_: Throwable) {}
        }
    }

    private fun activateInstantGoogleTranslateAndScroll(appCtx: Context) {
        triggerGentleHapticStatic(appCtx)
        // Đặt cờ trước khi đóng lớp phủ Khoanh để dismiss() không tắt Trợ năng ngầm
        NoAccessibilityScreenEngine.isLiveScrollTranslateActive = true

        val cachedNodes = preCapturedScreenNodes.ifEmpty {
            NoAccessibilityScreenEngine.lastCapturedScreenNodes
        }

        // 1. Đóng ngay lớp phủ Khoanh Màn Hình trong 0ms để trả tiêu điểm cửa sổ (rootInActiveWindow) về cho ứng dụng phía dưới
        dismiss(appCtx, preserveLiveScrollForHandoff = true)

        // 2. Lấy nhanh các hộp giá tiền / từ điển sẵn có trong RAM (0ms, không gọi IO/OCR)
        val dm = appCtx.resources.displayMetrics
        val (instantBoxes, _) = if (cachedNodes.isNotEmpty()) {
            GoogleScreenTranslator.buildInstantCachedBoxesForNodes(
                cachedNodes,
                dm.widthPixels.coerceAtLeast(1),
                dm.heightPixels.coerceAtLeast(1)
            )
        } else {
            Pair(emptyList(), false)
        }

        // 3. Khởi chạy Dịch Cuộn Xuyên Thấu tức thì 0ms trên Main Thread
        GoogleLiveTranslateOverlay.start(
            context = appCtx,
            initialBoxes = instantBoxes
        )
    }

    /**
     * Danh sách các nút bấm giao diện / nhãn rác phổ biến trên mọi ngôn ngữ (Việt, Trung, Anh, Nhật, Hàn)
     * cần loại bỏ để KHÔNG BAO GIỜ đẩy từ rác lên Google Tìm Kiếm.
     */
    private val uiNoiseExactPhrases = setOf(
        // Tiếng Việt
        "mua ngay", "thêm vào giỏ", "thêm vào giỏ hàng", "giỏ hàng", "đã bán", "xem thêm", "thu gọn",
        "bình luận", "chia sẻ", "yêu thích", "thích", "theo dõi", "đang theo dõi", "trang chủ",
        "thông báo", "tài khoản", "tôi", "tìm kiếm", "quảng cáo", "được tài trợ", "miễn phí vận chuyển",
        "freeship", "hoàn xu", "voucher", "chọn phân loại", "chat ngay", "xem shop", "vào shop",
        // Tiếng Trung (Taobao, 1688, Tmall, Pinduoduo, Douyin, WeChat, Xiaohongshu)
        "加入购物车", "立即购买", "立即抢购", "领券购买", "包邮", "运费险", "退货宝", "七天无理由退换",
        "7天无理由退货", "查看全部", "进店逛逛", "进店", "店铺", "客服", "收藏", "购物车", "我的淘宝",
        "猜你喜欢", "百亿补贴", "选择规格", "规格", "参数", "详情", "评价", "宝贝评价", "推荐",
        "关注", "已关注", "点赞", "转发", "评论", "分享", "首页", "消息", "我的", "展开", "收起",
        // Tiếng Anh
        "add to cart", "buy now", "shop now", "sponsored", "follow", "following", "subscribe",
        "share", "like", "likes", "comment", "comments", "views", "free shipping", "best seller",
        "see more", "read more", "home", "search", "notifications", "profile", "settings",
        // Tiếng Nhật & Hàn
        "カートに入れる", "今すぐ購入", "送料無料", "フォロー", "シェア", "コメント", "もっと見る",
        "장바구니", "바로구매", "무료배송", "팔로우", "공유", "댓글", "더보기"
    )

    private val inlineClutterRegex = Regex(
        """(\b(đã bán|sold)\s*\d+[.,]?\d*[kKmM+]*\b|\d+[.,]?\d*\s*(万人付款|人付款|人已买|条评价|好评)|\b\d{1,2}:\d{2}\b|\b\d{1,3}%\s*(好评)?|【\s*(现货|包邮|正品|秒发|新品)\s*】|\[\s*(现货|包邮|正品)\s*\])""",
        RegexOption.IGNORE_CASE
    )

    private val pureSymbolOrCounterRegex = Regex(
        """^([0-9.,+\-*/=<>%$:~•·|()\[\]{}¥￥₩€£฿₫]+|\d+[.,]?\d*\s*(k|m|b|tr|đ|vnd|rmb|cny|usd|krw|jpy|元|円|원|万|件|个|h|m|s|giờ|phút|ngày|tuần|năm|ago))$""",
        RegexOption.IGNORE_CASE
    )

    /**
     * Nhận diện ngôn ngữ hiển thị của chuỗi văn bản vừa khoanh (hỗ trợ mọi hệ chữ cái trên thế giới).
     */
    private fun detectLanguageScriptInfo(text: String): Pair<String, Boolean> {
        var cjkCount = 0
        var kanaCount = 0
        var hangulCount = 0
        var thaiCount = 0
        var cyrillicCount = 0
        var arabicCount = 0
        var vietCount = 0
        var latinCount = 0

        val vietChars = "ăâđêôơưĂÂĐÊÔƠƯáàảãạấầẩẫậắằẳẵặéèẻẽẹếềểễệíìỉĩịóòỏõọốồổỗộớờởỡợúùủũụứừửữựýỳỷỹỵ"

        for (ch in text) {
            val code = ch.code
            when {
                code in 0x3040..0x30FF || code in 0x31F0..0x31FF -> kanaCount++
                code in 0xAC00..0xD7AF || code in 0x1100..0x11FF || code in 0x3130..0x318F -> hangulCount++
                code in 0x4E00..0x9FFF || code in 0x3400..0x4DBF -> cjkCount++
                code in 0x0E00..0x0E7F -> thaiCount++
                code in 0x0400..0x04FF -> cyrillicCount++
                code in 0x0600..0x06FF -> arabicCount++
                ch in vietChars -> vietCount++
                ch in 'a'..'z' || ch in 'A'..'Z' -> latinCount++
            }
        }

        return when {
            kanaCount > 0 -> "🇯🇵 Tiếng Nhật • Đã lọc nhiễu" to true
            hangulCount > 0 -> "🇰🇷 Tiếng Hàn • Đã lọc nhiễu" to true
            cjkCount > 0 -> "🇨🇳 Tiếng Trung • Đã lọc nhiễu" to true
            thaiCount > 0 -> "🇹🇭 Tiếng Thái • Đã lọc nhiễu" to true
            cyrillicCount > 0 -> "🇷🇺 Tiếng Nga • Đã lọc nhiễu" to true
            arabicCount > 0 -> "🌐 Đa ngôn ngữ • Đã lọc nhiễu" to true
            vietCount > 0 -> "🇻🇳 Tiếng Việt • Chính xác cao" to false
            latinCount >= 2 -> "🇬🇧 Quốc tế / Anh • Chính xác cao" to true
            else -> "✨ Đa ngôn ngữ • Chính xác cao" to false
        }
    }

    /**
     * Làm sạch một node văn bản và chấm điểm chất lượng ngữ nghĩa (Semantic Quality Score):
     * - Trả về chuỗi đã dọn sạch các nhãn rác (`[包邮]`, `已售1000+`, `Đã bán 2k`...)
     * - Điểm <= 0 nghĩa là node rác (số đếm, giờ hệ thống, nút "Mua ngay", "Thêm vào giỏ"...) cần loại bỏ.
     */
    private fun cleanAndScoreNodeSemantics(rawText: String): Pair<String, Int> {
        val cleaned = rawText
            .replace("\n", " ")
            .replace(inlineClutterRegex, " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        if (cleaned.length < 2) return "" to -100

        val lower = cleaned.lowercase()
        if (lower in uiNoiseExactPhrases) return "" to -100
        if (pureSymbolOrCounterRegex.matches(cleaned)) return cleaned to -50

        // Đếm số chữ cái thực sự trên mọi ngôn ngữ (Unicode Letter `\p{L}`) và chữ số
        var letterCount = 0
        var cjkOrForeignCharCount = 0
        var digitCount = 0
        for (ch in cleaned) {
            if (Character.isLetter(ch)) {
                letterCount++
                if (ch.code > 0x024F) cjkOrForeignCharCount++
            } else if (ch.isDigit()) {
                digitCount++
            }
        }

        if (letterCount == 0 && digitCount < 3) return "" to -80

        // Một chữ Hán / Nhật / Hàn mang lượng thông tin tương đương ~2.5 chữ cái Latinh
        val effectiveSemanticLength = letterCount + cjkOrForeignCharCount * 2 + (digitCount / 2)
        if (effectiveSemanticLength < 2) return "" to -60

        var qualityScore = when {
            effectiveSemanticLength in 6..90 -> 140
            effectiveSemanticLength in 3..5 -> 85
            effectiveSemanticLength > 90 -> 95
            else -> 30
        }

        // Phạt nhẹ nếu chuỗi bắt đầu bằng ký hiệu tiền tệ đơn thuần
        if (cleaned.first() in "¥￥$₩€£฿₫" && letterCount <= 2) {
            qualityScore -= 90
        }

        return cleaned to qualityScore
    }

    /**
     * THUẬT TOÁN TRÍCH XUẤT & XẾP HẠNG VĂN BẢN ĐA NGÔN NGỮ CHÍNH XÁC GẤP 10 LẦN:
     * 1. Loại bỏ các ViewGroup cha bao trùm (tránh gom nhầm cả màn hình khi khoanh 1 mục nhỏ).
     * 2. Lọc sạch rác giao diện (nút Mua ngay, Giỏ hàng, Đã bán, giờ hệ thống, % pin) trên mọi ngôn ngữ (Việt, Trung, Anh, Nhật, Hàn...).
     * 3. Chấm điểm kết hợp: Độ khớp tâm vùng khoanh + Tỷ lệ diện tích nằm trong nét khoanh + Chất lượng ngữ nghĩa của văn bản.
     * 4. Khi khoanh vào một BỨC ẢNH sản phẩm không có chữ đè lên, tự động dò theo cột dọc (Column Alignment)
     *    để lấy đúng tiêu đề của chính bức ảnh đó (không bao giờ lấy nhầm tiêu đề của cột bên cạnh!).
     */
    private suspend fun extractSmartMultilingualRegion(
        appCtx: Context,
        normLeft: Float,
        normTop: Float,
        normRight: Float,
        normBottom: Float
    ): SmartExtractionResult = withContext(Dispatchers.IO) {
        try {
            val dm = appCtx.resources.displayMetrics
            val screenW = dm.widthPixels.coerceAtLeast(1)
            val screenH = dm.heightPixels.coerceAtLeast(1)
            val padPx = (18f * dm.density).toInt()

            val selLeftPx = (normLeft * screenW).toInt()
            val selTopPx = (normTop * screenH).toInt()
            val selRightPx = (normRight * screenW).toInt()
            val selBottomPx = (normBottom * screenH).toInt()
            val selWidth = max(1, selRightPx - selLeftPx)
            val selHeight = max(1, selBottomPx - selTopPx)
            val selArea = selWidth.toLong() * selHeight.toLong()
            val selCenterX = (selLeftPx + selRightPx) / 2
            val selCenterY = (selTopPx + selBottomPx) / 2
            val isFullScreenSearch = (normRight - normLeft) >= 0.88f && (normBottom - normTop) >= 0.82f

            val expLeft = (selLeftPx - padPx).coerceAtLeast(0)
            val expTop = (selTopPx - padPx).coerceAtLeast(0)
            val expRight = (selRightPx + padPx).coerceAtMost(screenW)
            val expBottom = (selBottomPx + padPx).coerceAtMost(screenH)

            // 1. Lấy danh sách toàn bộ node văn bản trên màn hình bằng luồng Dịch Cuộn (0% chụp ảnh màn hình)
            var rawScreenNodes = NoAccessibilityScreenEngine.extractVisibleScreenNodesNow(appCtx)
            if (rawScreenNodes.isEmpty()) {
                rawScreenNodes = preCapturedScreenNodes
            }
            if (rawScreenNodes.isEmpty()) {
                rawScreenNodes = NoAccessibilityScreenEngine.lastCapturedScreenNodes
            }
            if (rawScreenNodes.isEmpty()) {
                MagicTuneCtsAccessibilityService.beginTemporaryBurst(1200L)
                try {
                    NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(appCtx, 1200L)
                    val svc = MagicTuneCtsAccessibilityService.awaitServiceInstance(appCtx, 320L)
                    if (svc != null) {
                        rawScreenNodes = NoAccessibilityScreenEngine.extractVisibleScreenNodesNow(appCtx)
                    }
                } catch (_: Throwable) {
                } finally {
                    MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(appCtx, 100L)
                }
            }
            if (rawScreenNodes.isEmpty()) {
                rawScreenNodes = GoogleScreenTranslator.extractNodesViaUiAutomatorFallback(appCtx)
            }

            if (rawScreenNodes.isNotEmpty()) {
                preCapturedScreenNodes = rawScreenNodes
            }

            val statusBarCutoff = (screenH * 0.042f).toInt()
            val navBarCutoff = (screenH * 0.945f).toInt()
            val clockOrBatteryRegex = Regex("""^(\d{1,2}:\d{2}|\d{1,3}%|[0-9.,]+\s*(KB/s|MB/s|G|4G|5G|LTE))$""", RegexOption.IGNORE_CASE)

            // 2. Loại bỏ các node thanh trạng thái / thanh điều hướng và loại bỏ ViewGroup cha bao trùm
            val basicFiltered = rawScreenNodes.filter { node ->
                val txt = node.text.trim()
                val b = node.boundsInScreen
                txt.length >= 2 &&
                    b.bottom > statusBarCutoff &&
                    b.top < navBarCutoff &&
                    b.right > b.left &&
                    b.bottom > b.top &&
                    !clockOrBatteryRegex.matches(txt)
            }

            val leafNodes = basicFiltered.filter { parent ->
                val pb = parent.boundsInScreen
                val pArea = (pb.right - pb.left).toLong() * (pb.bottom - pb.top).toLong()
                // Nếu một node cha quá lớn chứa từ 2 node con trở lên bên trong thì bỏ node cha để lấy node con chính xác
                val childCountInside = basicFiltered.count { child ->
                    child !== parent &&
                        child.boundsInScreen.left >= pb.left - 6 &&
                        child.boundsInScreen.right <= pb.right + 6 &&
                        child.boundsInScreen.top >= pb.top - 6 &&
                        child.boundsInScreen.bottom <= pb.bottom + 6 &&
                        ((child.boundsInScreen.right - child.boundsInScreen.left).toLong() *
                            (child.boundsInScreen.bottom - child.boundsInScreen.top).toLong()) < (pArea * 4L / 5L)
                }
                childCountInside < 2
            }

            data class ScoredNode(
                val node: NoAccessibilityScreenEngine.ScreenTextNode,
                val cleanedText: String,
                val semanticScore: Int,
                val totalScore: Double,
                val overlapRatio: Float
            )

            // 3. Chấm điểm các node nằm BÊN TRONG hoặc GIAO CẮT với vùng người dùng vừa khoanh
            val insideScored = mutableListOf<ScoredNode>()
            for (node in leafNodes) {
                val b = node.boundsInScreen
                val nodeW = max(1, b.right - b.left)
                val nodeH = max(1, b.bottom - b.top)
                val nodeArea = nodeW.toLong() * nodeH.toLong()

                // Không lấy các khung nền khổng lồ lớn gấp > 4 lần vùng người dùng khoanh
                if (!isFullScreenSearch && nodeArea > selArea * 4L && nodeW > (screenW * 0.85f)) {
                    continue
                }

                val overlapW = min(b.right, expRight) - max(b.left, expLeft)
                val overlapH = min(b.bottom, expBottom) - max(b.top, expTop)
                if (overlapW <= 0 || overlapH <= 0) continue

                val overlapArea = overlapW.toLong() * overlapH.toLong()
                val nodeOverlapRatio = overlapArea.toFloat() / nodeArea.toFloat()
                val selCoverageRatio = overlapArea.toFloat() / max(1L, selArea).toFloat()

                val cx = (b.left + b.right) / 2
                val cy = (b.top + b.bottom) / 2
                val centerInside = cx in expLeft..expRight && cy in expTop..expBottom

                if (!centerInside && nodeOverlapRatio < 0.22f && selCoverageRatio < 0.18f) continue

                val (cleanedText, semScore) = cleanAndScoreNodeSemantics(node.text)
                if (cleanedText.isBlank() || semScore < 0) continue

                // Khoảng cách chuẩn hóa từ tâm chữ tới tâm nét khoanh của ngón tay (0.0 = ngay chính giữa tâm khoanh)
                val normDistX = kotlin.math.abs(cx - selCenterX).toDouble() / max(1, selWidth).toDouble()
                val normDistY = kotlin.math.abs(cy - selCenterY).toDouble() / max(1, selHeight).toDouble()
                val centerProximityBonus = (1.5 - (normDistX + normDistY)).coerceIn(-0.5, 1.5) * 95.0

                val overlapBonus = (nodeOverlapRatio * 130.0) + (selCoverageRatio.coerceAtMost(1f) * 60.0)
                val total = semScore.toDouble() + overlapBonus + centerProximityBonus

                insideScored.add(
                    ScoredNode(
                        node = node,
                        cleanedText = cleanedText,
                        semanticScore = semScore,
                        totalScore = total,
                        overlapRatio = nodeOverlapRatio
                    )
                )
            }

            if (insideScored.isNotEmpty()) {
                val ranked = insideScored.sortedByDescending { it.totalScore }
                val best = ranked.first()

                // Chỉ ghép thêm dòng thứ 2 nếu dòng đó nằm cùng một khối tiêu đề (cùng cột X, sát ngay trên/dưới dòng chính)
                val bestBounds = best.node.boundsInScreen
                val companion = ranked.drop(1).firstOrNull { other ->
                    val ob = other.node.boundsInScreen
                    val verticalGap = max(0, max(ob.top - bestBounds.bottom, bestBounds.top - ob.bottom))
                    val horizOverlap = min(ob.right, bestBounds.right) - max(ob.left, bestBounds.left)
                    verticalGap <= (22f * dm.density).toInt() &&
                        horizOverlap >= min(bestBounds. right - bestBounds.left, ob.right - ob.left) / 2 &&
                        other.semanticScore >= 75 &&
                        !best.cleanedText.contains(other.cleanedText, ignoreCase = true) &&
                        !other.cleanedText.contains(best.cleanedText, ignoreCase = true)
                }

                val primaryQuery = if (companion != null && (best.cleanedText.length + companion.cleanedText.length) <= 95) {
                    val ordered = listOf(best, companion).sortedBy { it.node.boundsInScreen.top }
                    "${ordered[0].cleanedText} ${ordered[1].cleanedText}".trim()
                } else {
                    best.cleanedText.take(110).trim()
                }

                val distinctCandidates = ranked
                    .map { it.cleanedText }
                    .distinctBy { it.lowercase() }
                    .take(5)

                val (langLabel, isForeign) = detectLanguageScriptInfo(primaryQuery)
                return@withContext SmartExtractionResult(
                    primaryQuery = primaryQuery,
                    candidatePhrases = distinctCandidates,
                    languageBadge = langLabel,
                    isForeignLanguage = isForeign
                )
            }

            // 4. Trường hợp người dùng khoanh vào MỘT BỨC ẢNH THUẦN TÚY (không có chữ đè lên ảnh):
            //    Dò tìm tiêu đề sản phẩm / bài viết nằm CÙNG CỘT DỌC (Column-Aligned) ngay bên dưới hoặc bên trên bức ảnh!
            val captionCandidates = mutableListOf<ScoredNode>()
            for (node in leafNodes) {
                val (cleanedText, semScore) = cleanAndScoreNodeSemantics(node.text)
                if (cleanedText.isBlank() || semScore < 40) continue

                val b = node.boundsInScreen
                // Tính độ trùng khớp cột ngang (Horizontal Column Overlap) với bức ảnh đã khoanh
                val horizOverlap = min(b.right, selRightPx + padPx) - max(b.left, selLeftPx - padPx)
                val nodeW = max(1, b.right - b.left)
                val horizOverlapRatio = horizOverlap.toFloat() / min(nodeW, selWidth).toFloat()

                // Nếu tiêu đề nằm lệch hẳn sang cột sản phẩm bên cạnh (trên lưới 2 cột Taobao/Shopee) -> Loại bỏ ngay!
                if (horizOverlapRatio < 0.25f) continue

                val dyBelow = b.top - selBottomPx
                val dyAbove = selTopPx - b.bottom

                val verticalDistanceScore = when {
                    // Tiêu đề nằm ngay dưới bức ảnh (chuẩn 95% các app Taobao, 1688, Shopee, TikTok, YouTube, Web)
                    dyBelow in -(padPx * 2)..(190f * dm.density).toInt() -> {
                        220.0 - (max(0, dyBelow).toDouble() * 0.45)
                    }
                    // Tiêu đề nằm ngay phía trên bức ảnh (chuẩn bài đăng Facebook, X, báo chí)
                    dyAbove in -(padPx * 2)..(120f * dm.density).toInt() -> {
                        160.0 - (max(0, dyAbove).toDouble() * 0.55)
                    }
                    else -> -999.0
                }
                if (verticalDistanceScore < -100.0) continue

                val totalScore = semScore.toDouble() + verticalDistanceScore + (horizOverlapRatio * 90.0)
                captionCandidates.add(
                    ScoredNode(
                        node = node,
                        cleanedText = cleanedText,
                        semanticScore = semScore,
                        totalScore = totalScore,
                        overlapRatio = horizOverlapRatio
                    )
                )
            }

            if (captionCandidates.isNotEmpty()) {
                val rankedCaptions = captionCandidates.sortedByDescending { it.totalScore }
                val primaryCaption = rankedCaptions.first().cleanedText.take(110).trim()
                val distinctCandidates = rankedCaptions
                    .map { it.cleanedText }
                    .distinctBy { it.lowercase() }
                    .take(5)
                val (langLabel, isForeign) = detectLanguageScriptInfo(primaryCaption)
                return@withContext SmartExtractionResult(
                    primaryQuery = primaryCaption,
                    candidatePhrases = distinctCandidates,
                    languageBadge = langLabel,
                    isForeignLanguage = isForeign
                )
            }

            SmartExtractionResult(
                primaryQuery = "",
                candidatePhrases = emptyList(),
                languageBadge = "✨ Đa ngôn ngữ • Chính xác cao",
                isForeignLanguage = false
            )
        } catch (_: Throwable) {
            SmartExtractionResult(
                primaryQuery = "",
                candidatePhrases = emptyList(),
                languageBadge = "✨ Đa ngôn ngữ • Chính xác cao",
                isForeignLanguage = false
            )
        }
    }

    /**
     * Chụp màn hình sạch phía dưới lớp phủ (tạm ẩn rootContainer trong tích tắc khi chụp,
     * ưu tiên AccessibilityService.takeScreenshot() trên Android 11+ rồi mới tới dự phòng VoiceInteraction / MediaProjection / Shell).
     */
    private suspend fun captureCleanScreenBehindOverlay(appCtx: Context): Bitmap? {
        val assistAge = System.currentTimeMillis() - MagicTuneVoiceInteractionService.lastCapturedAssistTimeMs
        val cachedAssist = if (assistAge in 0..4000L) MagicTuneVoiceInteractionService.lastCapturedAssistBitmap else null
        if (NoAccessibilityScreenEngine.isBitmapValidAndNotBlack(cachedAssist)) {
            return cachedAssist
        }

        val container = rootContainer
        withContext(Dispatchers.Main.immediate) {
            container?.alpha = 0f
            container?.visibility = View.INVISIBLE
        }
        try {
            delay(55L)
            var bmp = withContext(Dispatchers.IO) {
                MagicTuneCtsAccessibilityService.beginTemporaryBurst(1500L)
                try {
                    try {
                        NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(appCtx, 1200L)
                    } catch (_: Throwable) {}
                    if (!MagicTuneCtsAccessibilityService.isServiceConnected()) {
                        MagicTuneCtsAccessibilityService.awaitServiceInstance(appCtx, 320L)
                    }
                    withTimeoutOrNull(1800L) {
                        NoAccessibilityScreenEngine.captureScreenOffline(appCtx, skipFullScreenDownscale = true)
                    }
                } finally {
                    MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(appCtx, 100L)
                }
            }

            if (!NoAccessibilityScreenEngine.isBitmapValidAndNotBlack(bmp)) {
                val shell = ShellEngine.getInstance(appCtx)
                if (shell.state.value.isAdbReady) {
                    bmp = withContext(Dispatchers.IO) {
                        try {
                            withTimeoutOrNull(1400L) {
                                val outDir = appCtx.externalCacheDir ?: appCtx.cacheDir
                                outDir?.mkdirs()
                                val tmpFile = File(outDir, "magictune_cts.png")
                                if (tmpFile.exists()) tmpFile.delete()
                                val absPath = tmpFile.absolutePath
                                val sdcardFallback = "${android.os.Environment.getExternalStorageDirectory().path}/Android/data/${appCtx.packageName}/cache/magictune_cts.png"
                                shell.execute(
                                    "screencap -p '$absPath' 2>/dev/null || screencap -p '$sdcardFallback' 2>/dev/null; " +
                                        "chmod 666 '$absPath' '$sdcardFallback' 2>/dev/null || true"
                                )
                                val targetFile = if (tmpFile.exists() && tmpFile.length() > 1024L) {
                                    tmpFile
                                } else {
                                    File(sdcardFallback)
                                }
                                if (targetFile.exists() && targetFile.length() > 1024L) {
                                    val decoded = BitmapFactory.decodeFile(targetFile.absolutePath)
                                    try { targetFile.delete() } catch (_: Throwable) {}
                                    decoded
                                } else null
                            }
                        } catch (_: Throwable) {
                            null
                        }
                    }
                }
            }
            return if (NoAccessibilityScreenEngine.isBitmapValidAndNotBlack(bmp)) bmp else null
        } finally {
            withContext(Dispatchers.Main.immediate) {
                container?.visibility = View.VISIBLE
                container?.alpha = 1f
            }
            MagicTuneCtsAccessibilityService.enterDeepSleepNow(appCtx, forceImmediate = true)
        }
    }

    private data class CroppedImagePayload(
        val file: File,
        val jpegBytes: ByteArray,
        val base64Jpeg: String,
        val width: Int,
        val height: Int
    )

    private suspend fun cropAndEncodeRegionToJpeg(
        appCtx: Context,
        sourceBitmap: Bitmap,
        normLeft: Float,
        normTop: Float,
        normRight: Float,
        normBottom: Float
    ): CroppedImagePayload? = withContext(Dispatchers.IO) {
        var swCopy: Bitmap? = null
        var rawCropped: Bitmap? = null
        var scaledBmp: Bitmap? = null
        try {
            val swSource = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                sourceBitmap.config == Bitmap.Config.HARDWARE
            ) {
                (sourceBitmap.copy(Bitmap.Config.ARGB_8888, false) ?: sourceBitmap).also {
                    if (it !== sourceBitmap) swCopy = it
                }
            } else {
                sourceBitmap
            }

            val w = swSource.width
            val h = swSource.height
            if (w < 24 || h < 24) return@withContext null

            val leftPx = (normLeft * w).toInt().coerceIn(0, max(0, w - 24))
            val topPx = (normTop * h).toInt().coerceIn(0, max(0, h - 24))
            val rightPx = (normRight * w).toInt().coerceIn(leftPx + 24, w)
            val bottomPx = (normBottom * h).toInt().coerceIn(topPx + 24, h)

            val cropW = (rightPx - leftPx).coerceIn(24, w - leftPx)
            val cropH = (bottomPx - topPx).coerceIn(24, h - topPx)

            rawCropped = Bitmap.createBitmap(swSource, leftPx, topPx, cropW, cropH)

            val maxSide = max(cropW, cropH)
            val uploadBmp = if (maxSide > 768) {
                val scale = 768f / maxSide.toFloat()
                val tw = (cropW * scale).toInt().coerceAtLeast(24)
                val th = (cropH * scale).toInt().coerceAtLeast(24)
                Bitmap.createScaledBitmap(rawCropped, tw, th, true).also {
                    if (it !== rawCropped) scaledBmp = it
                }
            } else {
                rawCropped
            }

            val jpegBytes = ByteArrayOutputStream().use { baos ->
                uploadBmp.compress(Bitmap.CompressFormat.JPEG, 75, baos)
                baos.toByteArray()
            }
            if (jpegBytes.isEmpty()) return@withContext null

            val outDir = File(appCtx.cacheDir, "cts_shares").apply { if (!exists()) mkdirs() }
            try {
                outDir.listFiles { f -> f.name.startsWith("cts_region_") && f.name.endsWith(".jpg") }
                    ?.sortedByDescending { it.lastModified() }
                    ?.drop(4)
                    ?.forEach { old -> try { old.delete() } catch (_: Throwable) {} }
            } catch (_: Throwable) {}
            val outFile = File(outDir, "cts_region_${System.currentTimeMillis()}.jpg")
            FileOutputStream(outFile).use { fos ->
                fos.write(jpegBytes)
                fos.flush()
            }
            val b64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)

            CroppedImagePayload(
                file = outFile,
                jpegBytes = jpegBytes,
                base64Jpeg = b64,
                width = uploadBmp.width,
                height = uploadBmp.height
            )
        } catch (_: Throwable) {
            null
        } finally {
            try {
                scaledBmp?.let { if (it !== rawCropped && !it.isRecycled) it.recycle() }
            } catch (_: Throwable) {}
            try {
                rawCropped?.let { if (it !== sourceBitmap && !it.isRecycled) it.recycle() }
            } catch (_: Throwable) {}
            try {
                swCopy?.let { if (it !== sourceBitmap && !it.isRecycled) it.recycle() }
            } catch (_: Throwable) {}
            val isShared = sourceBitmap === MediaProjectionHolder.lastCapturedBitmap ||
                sourceBitmap === MagicTuneVoiceInteractionService.lastCapturedAssistBitmap
            if (!isShared && !sourceBitmap.isRecycled) {
                try { sourceBitmap.recycle() } catch (_: Throwable) {}
            }
        }
    }

    private fun sendImageToExternalGoogleLensStatic(appCtx: Context, imageFile: File): Boolean {
        return try {
            val authority = "${appCtx.packageName}.fileprovider"
            val contentUri: Uri = FileProvider.getUriForFile(appCtx, authority, imageFile)
            val targetPackages = listOf(
                "com.google.ar.lens",
                "com.google.android.googlequicksearchbox"
            )
            for (pkg in targetPackages) {
                try {
                    appCtx.grantUriPermission(pkg, contentUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Throwable) {}
            }

            val baseSendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                clipData = ClipData.newRawUri("CircleToSearch", contentUri)
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP
                )
            }

            val pm = appCtx.packageManager
            val resolvedList = pm.queryIntentActivities(baseSendIntent, 0)
                .filter { it.activityInfo.packageName != appCtx.packageName }
            val lensActivityInfo = resolvedList.firstOrNull { info ->
                val pkg = info.activityInfo.packageName
                val cls = info.activityInfo.name
                (pkg == "com.google.ar.lens" || pkg == "com.google.android.googlequicksearchbox") &&
                    cls.contains("lens", ignoreCase = true)
            } ?: resolvedList.firstOrNull { info ->
                info.activityInfo.packageName == "com.google.ar.lens"
            } ?: resolvedList.firstOrNull { info ->
                info.activityInfo.packageName == "com.google.android.googlequicksearchbox"
            }

            if (lensActivityInfo != null) {
                val explicitIntent = Intent(baseSendIntent).apply {
                    setClassName(lensActivityInfo.activityInfo.packageName, lensActivityInfo.activityInfo.name)
                }
                if (startActivitySafeStatic(appCtx, explicitIntent)) return true
            }

            for (pkg in targetPackages) {
                val pkgIntent = Intent(baseSendIntent).apply { setPackage(pkg) }
                if (startActivitySafeStatic(appCtx, pkgIntent)) return true
            }

            val launchIntent = pm.getLaunchIntentForPackage("com.google.ar.lens")
            if (launchIntent != null) {
                launchIntent.action = Intent.ACTION_SEND
                launchIntent.type = "image/jpeg"
                launchIntent.putExtra(Intent.EXTRA_STREAM, contentUri)
                launchIntent.clipData = ClipData.newRawUri("CircleToSearch", contentUri)
                launchIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                if (startActivitySafeStatic(appCtx, launchIntent)) return true
            }
            false
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Khoanh màn hình hỏi MagicLive về vùng vừa khoanh:
     * 1. Kết hợp chính xác tính năng Đọc Màn Hình (`extractSmartMultilingualRegion` + `NoAccessibilityScreenEngine`) để hiểu toàn bộ chữ, tiêu đề, giá cả, nút bấm bên trong & ngay xung quanh vùng khoanh.
     * 2. Chụp màn hình sạch phía dưới lớp phủ, cắt đúng vùng đã khoanh và chạy thêm OCR trực tiếp trên ảnh cắt (`ScreenOcrEngine`) để đọc mọi chữ nằm chìm trong ảnh/video.
     * 3. Trả Accessibility về 0% ngay lập tức để bảo vệ pin, đóng khung khoanh và chuyển thẳng sang `MagicLiveFloatingOverlay.askMagicLiveAboutCircledScreenRegion` để MagicLive giải thích chi tiết kiến thức về vùng vừa khoanh (đồng thời lưu vào Bộ Não Trí Nhớ trên máy và tách biệt phiên trò chuyện mới).
     */
    private fun processCroppedRegionAndSearchGoogle(
        appCtx: Context,
        normLeft: Float,
        normTop: Float,
        normRight: Float,
        normBottom: Float,
        forceVisualImageSearch: Boolean = true
    ) {
        val searchGoogle = googleSearchMode
        uploadJob?.cancel()
        uploadJob = overlayScope.launch {
            try {
                lastSelectionBounds = Rect(normLeft, normTop, normRight, normBottom)
                triggerGentleHapticStatic(appCtx)

                val fg = withContext(Dispatchers.IO) {
                    NoAccessibilityScreenEngine.getActiveForegroundPackage(appCtx).orEmpty()
                }
                if (fg.isNotBlank() && NoAccessibilityScreenEngine.isSensitiveBankingPackage(fg) && fg != appCtx.packageName) {
                    Toast.makeText(
                        appCtx,
                        "🛡️ Ứng dụng hiện tại bảo mật chống chụp ảnh màn hình.",
                        Toast.LENGTH_SHORT
                    ).show()
                    dismiss(appCtx)
                    return@launch
                }

                setLoadingState(
                    loading = true,
                    title = if (searchGoogle) "🔍 Đang mở Google Lens với ảnh đã khoanh..." else "⚡ Đang gửi ảnh lên MAGIC LIVE...",
                    subtitle = if (searchGoogle) "Đang chuyển ảnh trực tiếp sang ứng dụng Google Lens" else "AI đang phân tích trực tiếp hình ảnh..."
                )

                // Làm nóng sẵn kết nối HTTPS Groq để tăng tốc độ phản hồi ngay tức thì
                if (!searchGoogle) MagicLiveFloatingOverlay.prewarmGroqConnection()
                MagicTuneCtsAccessibilityService.beginTemporaryBurst(2500L)

                val fgAppLabel = withContext(Dispatchers.IO) {
                    try {
                        NoAccessibilityScreenEngine.getActiveForegroundAppLabel(appCtx).orEmpty()
                    } catch (_: Throwable) {
                        ""
                    }
                }

                // Chụp ảnh màn hình sạch phía dưới lớp phủ và cắt đúng vùng vừa khoanh
                // KHÔNG chạy OCR hay gửi văn bản màn hình kèm theo để AI tập trung 100% hiểu trực tiếp hình ảnh
                val screenBitmap = captureCleanScreenBehindOverlay(appCtx)
                var croppedPayload: CroppedImagePayload? = null

                if (screenBitmap != null) {
                    val payload = cropAndEncodeRegionToJpeg(
                        appCtx = appCtx,
                        sourceBitmap = screenBitmap,
                        normLeft = normLeft,
                        normTop = normTop,
                        normRight = normRight,
                        normBottom = normBottom
                    )
                    croppedPayload = payload
                    if (payload != null) {
                        lastCroppedFile = payload.file
                        lastCroppedJpegBase64 = payload.base64Jpeg
                    }
                }

                // Đảm bảo trả Trợ năng về 0% CPU ngay sau khi chụp xong
                MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(appCtx, 60L)

                val base64Jpeg = croppedPayload?.base64Jpeg.orEmpty()

                if (base64Jpeg.isBlank()) {
                    Toast.makeText(
                        appCtx,
                        "⚠️ Không chụp được vùng ảnh màn hình hiện tại. Vui lòng thử khoanh lại vùng cần hỏi!",
                        Toast.LENGTH_LONG
                    ).show()
                    return@launch
                }

                if (searchGoogle && croppedPayload != null) {
                    val payload = croppedPayload
                    showCroppedImagePreview(payload.file, "Ảnh vùng chọn • đang mở Google Lens")
                    if (sendImageToExternalGoogleLensStatic(appCtx, payload.file)) {
                        dismiss(appCtx, keepFollowUpSession = true)
                    } else {
                        showCroppedImagePreview(payload.file, "Ảnh vùng chọn • chưa mở được Lens")
                        Toast.makeText(appCtx, "Không mở được ứng dụng Google Lens để nhận ảnh. Hãy kiểm tra ứng dụng Google Lens trên máy.", Toast.LENGTH_LONG).show()
                    }
                    return@launch
                }

                // Đóng lớp phủ khoanh màn hình và gửi CHỈ hình ảnh sang MagicLive để AI trực tiếp giải đáp
                dismiss(appCtx, keepFollowUpSession = true)
                MagicLiveFloatingOverlay.askMagicLiveAboutCircledScreenRegion(
                    context = appCtx,
                    croppedBase64Jpeg = base64Jpeg,
                    croppedImageFile = croppedPayload?.file,
                    primaryExtractedText = "",
                    candidatePhrases = emptyList(),
                    ocrTextFromCroppedBitmap = "",
                    surroundingScreenSummary = "",
                    foregroundAppLabel = fgAppLabel,
                    languageBadge = ""
                )
            } finally {
                MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(appCtx, 80L)
                rootContainer?.visibility = View.VISIBLE
                rootContainer?.alpha = 1f
                setLoadingState(false)
            }
        }
    }

    internal fun launchGoogleVoiceSearchStatic(appCtx: Context) {
        triggerGentleHapticStatic(appCtx)
        val candidates = listOf(
            Intent(RecognizerIntent.ACTION_WEB_SEARCH).apply {
                setClassName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.googlequicksearchbox.VoiceSearchActivity"
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH)
                putExtra("com.google.android.voicesearch.extra.CALLED_FROM_SEARCH_PLATE", true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            Intent().apply {
                setClassName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.googlequicksearchbox.VoiceSearchActivity"
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            Intent(RecognizerIntent.ACTION_WEB_SEARCH).apply {
                setPackage("com.google.android.googlequicksearchbox")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
        )

        var launched = false
        for (intent in candidates) {
            if (startActivitySafeStatic(appCtx, intent)) {
                launched = true
                break
            }
        }

        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            overlayScope.launch(Dispatchers.IO) {
                try {
                    shell.execute(
                        "am start --user 0 -a android.speech.action.WEB_SEARCH -n com.google.android.googlequicksearchbox/com.google.android.googlequicksearchbox.VoiceSearchActivity --es android.speech.extra.LANGUAGE_MODEL web_search --ez com.google.android.voicesearch.extra.CALLED_FROM_SEARCH_PLATE true >/dev/null 2>&1 || am start --user 0 -n com.google.android.googlequicksearchbox/com.google.android.googlequicksearchbox.VoiceSearchActivity >/dev/null 2>&1 || true"
                    )
                } catch (_: Exception) {}
            }
            launched = true
        }

        if (!launched) {
            Toast.makeText(
                appCtx,
                "⚠️ Đang mở CH Play để cài đặt ứng dụng Google tìm kiếm giọng nói...",
                Toast.LENGTH_SHORT
            ).show()
            try {
                val playIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.googlequicksearchbox")).apply {
                    setPackage("com.android.vending")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appCtx.startActivity(playIntent)
            } catch (_: Exception) {}
        }
    }

    private fun launchMagicLiveFloatingOverlayStatic(appCtx: Context) {
        triggerGentleHapticStatic(appCtx)
        val ocrSummary = lastExtractedQueryText.takeIf { it.isNotBlank() }
        val imgFile = lastCroppedFile
        val imgB64 = lastCroppedJpegBase64

        dismiss(appCtx)

        val shown = MagicLiveFloatingOverlay.showWithAttachedScreenQuery(
            context = appCtx,
            base64Jpeg = imgB64,
            imageFile = imgFile,
            ocrSummary = ocrSummary
        )
        if (!shown) {
            MagicLiveFloatingOverlay.showAndStartListening(appCtx)
        }
    }

    internal fun startActivitySafeStatic(appCtx: Context, intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val options = ActivityOptions.makeBasic().apply {
                    setPendingIntentBackgroundActivityStartMode(
                        @Suppress("DEPRECATION") ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    )
                }
                appCtx.startActivity(intent, options.toBundle())
            } else {
                appCtx.startActivity(intent)
            }
            true
        } catch (_: Exception) {
            try {
                appCtx.startActivity(intent)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    internal fun triggerGentleHapticStatic(appCtx: Context) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = appCtx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                appCtx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(30L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(30L)
            }
        } catch (_: Exception) {}
    }
}

