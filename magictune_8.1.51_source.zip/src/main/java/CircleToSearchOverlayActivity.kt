package com.example.core.widget

import com.example.R

import android.Manifest
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.util.Base64
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Translate
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.example.MainActivity
import com.example.core.license.LicenseManager
import com.example.core.service.NoAccessibilityScreenEngine
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

/**
 * Activity ÉP BẬT KHOANH TRÒN TÌM KIẾM & GOOGLE DỊCH MÀN HÌNH TỨC THÌ (Forced Circle to Search + Google Screen Translate)
 * dành riêng cho điện thoại Honor MagicOS (Hoạt động 100% NGAY CẢ KHI ĐÃ TẮT GỠ LỖI WLAN / TẮT SHIZUKU).
 *
 * Cơ chế hoạt động:
 * 1. Chụp màn hình ngầm siêu tốc (~80ms) kèm trích xuất toàn bộ tọa độ văn bản trên màn hình (~8ms)
 *    thông qua `NoAccessibilityScreenEngine`.
 * 2. Chế độ 🔍 Tìm Google: Khoanh tròn bất kỳ sản phẩm, vật thể, hình ảnh nào để tìm kiếm trên Google Lens.
 * 3. Chế độ 🌐 Google Dịch (Tức thì + Cuộn Đến Đâu Dịch Đến Đó cho Taobao, 1688, App Ngoại Ngữ):
 *    - Sử dụng 100% công cụ GOOGLE DỊCH (`translate.googleapis.com`) siêu tốc (~100ms), KHÔNG dùng Groq AI.
 *    - Tự động nhận diện và quy đổi giá tiền nước ngoài (Nhân dân tệ ¥/RMB/CNY, USD $, Won ₩, Yên 円...) sang VNĐ (đ).
 *    - Kích hoạt lớp phủ xuyên thấu (`GoogleLiveTranslateOverlay`) cho phép người dùng cuộn trang, bấm mua hàng
 *      trực tiếp trên Taobao / 1688 trong khi bản dịch Tiếng Việt (kích thước chữ nhỏ gọn 8.5sp - 9sp, tự động né nhau)
 *      cập nhật tức thì theo từng nhịp cuộn!
 */
class CircleToSearchOverlayActivity : ComponentActivity() {

    enum class LensMode(val code: String, val label: String) {
        SEARCH("un", "🔍 Kết Quả Google"),
        TRANSLATE("tr", "🌐 Google Dịch"),
        TEXT("text", "📝 Chép Chữ")
    }

    data class TranslatedTextBox(
        val ymin: Float,
        val xmin: Float,
        val ymax: Float,
        val xmax: Float,
        val originalText: String,
        val translatedText: String
    )

    data class GoogleTranslationResult(
        val translatedText: String,
        val originalText: String,
        val engineUsed: String = "Google Dịch + Tự đổi VNĐ",
        val isSuccess: Boolean,
        val boxes: List<TranslatedTextBox> = emptyList()
    )

    private var capturedBitmap by mutableStateOf<Bitmap?>(null)
    private var isCameraCapturedBitmap by mutableStateOf(false)
    private var croppedPreviewBitmap by mutableStateOf<Bitmap?>(null)
    private var lastCroppedFile by mutableStateOf<File?>(null)
    private var lastCroppedJpegBase64 by mutableStateOf<String?>(null)
    private var lastSelectionBounds by mutableStateOf<Rect?>(null)
    private var isCapturing by mutableStateOf(true)
    private var isUploadingToGoogle by mutableStateOf(false)
    private var isTranslatingWithGoogle by mutableStateOf(false)
    private var googleTranslationResult by mutableStateOf<GoogleTranslationResult?>(null)
    private var activeLensMode by mutableStateOf(LensMode.SEARCH)
    private var uploadErrorMessage by mutableStateOf<String?>(null)
    private var cameraCaptureFile: File? = null
    private var isLaunchingCameraForSearch: Boolean = false
    private var screenOffReceiver: BroadcastReceiver? = null

    private val takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        isLaunchingCameraForSearch = false
        window.decorView.alpha = 1f
        if (success) {
            val file = cameraCaptureFile
            if (file != null && file.exists() && file.length() > 512L) {
                lifecycleScope.launch {
                    val bmp = withContext(Dispatchers.IO) {
                        try {
                            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            BitmapFactory.decodeFile(file.absolutePath, opts)
                            var sample = 1
                            while (opts.outWidth / sample > 1600 || opts.outHeight / sample > 1600) {
                                sample *= 2
                            }
                            BitmapFactory.decodeFile(
                                file.absolutePath,
                                BitmapFactory.Options().apply { inSampleSize = sample }
                            )
                        } catch (_: Throwable) {
                            null
                        }
                    }
                    if (bmp != null) {
                        isCameraCapturedBitmap = true
                        capturedBitmap = bmp
                        isCapturing = false
                        googleTranslationResult = null
                        uploadErrorMessage = null
                        processCroppedRegionAndSearchGoogle(
                            normLeft = 0f,
                            normTop = 0f,
                            normRight = 1f,
                            normBottom = 1f,
                            initialMode = LensMode.SEARCH
                        )
                    } else {
                        Toast.makeText(this@CircleToSearchOverlayActivity, "⚠️ Không đọc được ảnh từ Camera", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private val cameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted || ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCameraCaptureForGoogleSearch()
        } else {
            Toast.makeText(this, "⚠️ Cần cấp quyền Camera để chụp ảnh tìm kiếm Google", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchCameraSearchNow() {
        val hasCam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (hasCam) {
            startCameraCaptureForGoogleSearch()
            return
        }
        val shell = ShellEngine.getInstance(applicationContext)
        if (shell.state.value.isAdbReady) {
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    try {
                        val pkg = packageName
                        shell.execute(
                            "pm grant -u 0 $pkg android.permission.CAMERA >/dev/null 2>&1 || pm grant --user 0 $pkg android.permission.CAMERA >/dev/null 2>&1 || pm grant $pkg android.permission.CAMERA >/dev/null 2>&1 || true; " +
                                "cmd appops set $pkg CAMERA allow >/dev/null 2>&1 || cmd appops set --user 0 $pkg CAMERA allow >/dev/null 2>&1 || true"
                        )
                    } catch (_: Throwable) {}
                }
                if (ContextCompat.checkSelfPermission(this@CircleToSearchOverlayActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    startCameraCaptureForGoogleSearch()
                } else {
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                }
            }
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCameraCaptureForGoogleSearch() {
        try {
            val shareDir = File(cacheDir, "cts_shares").apply { mkdirs() }
            val photoFile = File(shareDir, "cts_camera_capture.jpg")
            if (photoFile.exists()) photoFile.delete()
            photoFile.createNewFile()
            cameraCaptureFile = photoFile
            val photoUri = FileProvider.getUriForFile(
                this,
                "${packageName}.fileprovider",
                photoFile
            )
            isLaunchingCameraForSearch = true
            takePictureLauncher.launch(photoUri)
        } catch (e: Throwable) {
            isLaunchingCameraForSearch = false
            Toast.makeText(this, "⚠️ Không thể mở Camera: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // KIỂM TRA KHÓA ĐỎ: Bắt buộc kết nối Gỡ lỗi Wi-Fi lần đầu sau khi tải app về máy
        if (!com.example.core.permission.AppPermissionChecker.isFirstTimeWlanActivated(applicationContext)) {
            Toast.makeText(
                applicationContext,
                "🔒 Khoanh tròn hỏi AI đang KHÓA ĐỎ!\nVui lòng kết nối Gỡ lỗi Wi-Fi 1 lần bằng mã 6 số để kích hoạt lệnh ADB khóa quyền trợ năng vĩnh viễn!",
                Toast.LENGTH_LONG
            ).show()
            val mainIntent = Intent(this, com.example.MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("TARGET_TAB", "SHIZUKU")
            }
            startActivity(mainIntent)
            finish()
            return
        }
        // Nếu đang bật lớp phủ Dịch Cuộn Trực Tiếp thì tạm tắt để chụp màn hình sạch
        if (GoogleLiveTranslateOverlay.isRunning) {
            GoogleLiveTranslateOverlay.stop(applicationContext)
        }
        // Đảm bảo MagicLive không bao giờ hiển thị đè lên màn hình Khoanh tròn hỏi AI
        MagicLiveFloatingOverlay.dismiss(applicationContext)
        try { com.example.core.adb.AdbNsdScanner.getInstance(applicationContext).releaseMulticastLock() } catch (_: Throwable) {}

        // Nếu không phải mở trực tiếp Camera tìm kiếm và đã có quyền hiển thị trên ứng dụng khác (SYSTEM_ALERT_WINDOW),
        // chuyển ngay sang Lớp Phủ Kính Xuyên Thấu WindowManager (TYPE_APPLICATION_OVERLAY + PixelFormat.TRANSLUCENT)
        // để tuyệt đối KHÔNG chuyển Task, KHÔNG bị hệ điều hành MagicOS lót nền đen phía sau Activity!
        val isDirectCamera = intent?.getBooleanExtra("DIRECT_CAMERA_SEARCH", false) == true
        if (!isDirectCamera && Settings.canDrawOverlays(applicationContext)) {
            if (CircleToSearchWindowOverlay.show(applicationContext)) {
                finishWithoutAnimation()
                return
            }
        }

        // Khoanh tròn hỏi AI & Google Lens: MỞ CHO TẤT CẢ NGƯỜI DÙNG (Không cần Pro)
        isOverlayActive = true
        activeInstanceRef = java.lang.ref.WeakReference(this)
        lastCreatedTimestampMs = System.currentTimeMillis()
        registerScreenOffReceiver()
        // Tự ẩn & thu nhỏ thụt nút điều hướng ảo xuống dưới để tránh bấm nhầm khi thao tác hàng nút chức năng Khoanh Tròn
        com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(applicationContext, true)
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)

        // Ép cửa sổ trong suốt tuyệt đối 100% xuyên thấu xuống ứng dụng phía dưới (tránh lỗi nền đen trên MagicOS 8-11 / Android 13-17)
        window.setFormat(android.graphics.PixelFormat.TRANSLUCENT)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        com.example.core.perf.ScreenPowerOptimizer.applyEcoRefreshRateToWindow(window.attributes)
        com.example.core.perf.ScreenPowerOptimizer.onFeatureStarted(this, "CircleToSearchActivity")
        window.decorView.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        @Suppress("DEPRECATION")
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        @Suppress("DEPRECATION")
        window.clearFlags(
            WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS or
                WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION or
                WindowManager.LayoutParams.FLAG_DIM_BEHIND
        )
        window.decorView.alpha = 1f

        setContent {
            BackHandler(enabled = isUploadingToGoogle || isTranslatingWithGoogle || googleTranslationResult != null) {
                isUploadingToGoogle = false
                isTranslatingWithGoogle = false
                googleTranslationResult = null
                uploadErrorMessage = null
            }

            ForcedCircleToSearchScreen(
                bitmap = capturedBitmap,
                isCameraCapturedBitmap = isCameraCapturedBitmap,
                croppedPreview = croppedPreviewBitmap,
                lastCroppedJpegBase64 = lastCroppedJpegBase64,
                selectionNormBounds = lastSelectionBounds,
                isCapturing = isCapturing,
                isUploadingToGoogle = isUploadingToGoogle,
                isTranslatingWithGoogle = isTranslatingWithGoogle,
                googleTranslationResult = googleTranslationResult,
                activeLensMode = activeLensMode,
                uploadErrorMessage = uploadErrorMessage,
                onSelectLensMode = { newMode ->
                    activeLensMode = newMode
                    if (newMode == LensMode.TRANSLATE) {
                        // Chuyển ngay sang tính năng Dịch màn hình xuyên thấu theo yêu cầu người dùng
                        GoogleLiveTranslateOverlay.start(this@CircleToSearchOverlayActivity)
                        Toast.makeText(this@CircleToSearchOverlayActivity, "🌐 Đã chuyển sang Dịch màn hình trực tiếp!", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                },
                onCircleSelectionCompleted = { normLeft, normTop, normRight, normBottom, preferredMode ->
                    if (preferredMode == LensMode.TRANSLATE) {
                        translateRegionWithGoogleNow(
                            normLeft = normLeft,
                            normTop = normTop,
                            normRight = normRight,
                            normBottom = normBottom,
                            activateLiveScrollOverlay = false
                        )
                    } else {
                        processCroppedRegionAndSearchGoogle(
                            normLeft = normLeft,
                            normTop = normTop,
                            normRight = normRight,
                            normBottom = normBottom,
                            initialMode = preferredMode
                        )
                    }
                },
                onActivateInstantGoogleTranslateAndScroll = {
                    translateRegionWithGoogleNow(
                        normLeft = 0f,
                        normTop = 0f,
                        normRight = 1f,
                        normBottom = 1f,
                        activateLiveScrollOverlay = true
                    )
                },
                onSearchFullScreen = {
                    processCroppedRegionAndSearchGoogle(
                        normLeft = 0f,
                        normTop = 0f,
                        normRight = 1f,
                        normBottom = 1f,
                        initialMode = LensMode.SEARCH
                    )
                },
                onLaunchCameraSearch = {
                    // This activity already owns a TakePicture launcher. Capture here so
                    // launching the camera does not bring the app's main task forward.
                    launchCameraSearchNow()
                },
                onLaunchGoogleVoiceSearch = {
                    launchGoogleVoiceSearchNow()
                },
                onLaunchMagicLiveFloatingOverlay = {
                    launchMagicLiveFloatingOverlayAndYield()
                },
                onOpenExternalLensApp = {
                    val file = lastCroppedFile
                    if (file != null && file.exists() && !sendImageToExternalGoogleLens(file)) {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.ar.lens")).apply {
                                setPackage("com.android.vending")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            })
                        } catch (_: Exception) {
                            try {
                                startActivity(Intent(Intent.ACTION_WEB_SEARCH).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                })
                            } catch (_: Exception) {}
                        }
                    }
                },
                onResetCircleSelection = {
                    isUploadingToGoogle = false
                    isTranslatingWithGoogle = false
                    googleTranslationResult = null
                    lastSelectionBounds = null
                    uploadErrorMessage = null
                },
                onDismiss = {
                    finishWithoutAnimation()
                }
            )
        }

        if (isDirectCamera) {
            isCapturing = false
            launchCameraSearchNow()
        } else {
            // Tiết kiệm pin: Không kích hoạt Accessibility hay chụp màn hình ngầm khi mới mở lớp phủ.
            // Chỉ chụp đúng 1 lần khi người dùng thực sự khoanh vùng hoặc chọn Tìm toàn màn hình.
            val assistAge = System.currentTimeMillis() - com.example.core.assistant.MagicTuneVoiceInteractionService.lastCapturedAssistTimeMs
            val assistBmp = if (assistAge in 0..5000L) {
                com.example.core.assistant.MagicTuneVoiceInteractionService.lastCapturedAssistBitmap
            } else null
            capturedBitmap = if (NoAccessibilityScreenEngine.isBitmapValidAndNotBlack(assistBmp)) assistBmp else null
            isCapturing = false
            window.decorView.alpha = 1f
            triggerGentleHaptic()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("DIRECT_CAMERA_SEARCH", false)) {
            isCapturing = false
            launchCameraSearchNow()
            return
        }
        if (Settings.canDrawOverlays(applicationContext)) {
            if (CircleToSearchWindowOverlay.show(applicationContext)) {
                finishWithoutAnimation()
                return
            }
        }
        com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(applicationContext, true)
        val now = System.currentTimeMillis()
        if (now - lastCreatedTimestampMs < 350L) {
            return
        }
        lastCreatedTimestampMs = now
        isUploadingToGoogle = false
        isTranslatingWithGoogle = false
        googleTranslationResult = null
        lastSelectionBounds = null
        uploadErrorMessage = null
        isCameraCapturedBitmap = false
        val assistAge = now - com.example.core.assistant.MagicTuneVoiceInteractionService.lastCapturedAssistTimeMs
        val assistBmp = if (assistAge in 0..5000L) {
            com.example.core.assistant.MagicTuneVoiceInteractionService.lastCapturedAssistBitmap
        } else null
        capturedBitmap = if (NoAccessibilityScreenEngine.isBitmapValidAndNotBlack(assistBmp)) assistBmp else null
        isCapturing = false
        window.decorView.alpha = 1f
        triggerGentleHaptic()
    }

    override fun onResume() {
        super.onResume()
        isOverlayActive = true
        com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(applicationContext, true)
    }

    override fun onPause() {
        if (!isLaunchingCameraForSearch && !CircleToSearchWindowOverlay.isShowing) {
            isOverlayActive = false
        }
        super.onPause()
    }

    private fun registerScreenOffReceiver() {
        if (screenOffReceiver != null) return
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_SCREEN_OFF && !isLaunchingCameraForSearch) {
                    finishWithoutAnimation()
                }
            }
        }
        try {
            val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(receiver, filter)
            }
            screenOffReceiver = receiver
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        com.example.core.perf.ScreenPowerOptimizer.onFeatureStopped(this, "CircleToSearchActivity")
        screenOffReceiver?.let { r ->
            screenOffReceiver = null
            try { unregisterReceiver(r) } catch (_: Throwable) {}
        }
        if (activeInstanceRef?.get() === this) {
            activeInstanceRef = null
        }
        if (!CircleToSearchWindowOverlay.isShowing) {
            isOverlayActive = false
            MagicLiveFloatingOverlay.clearPendingCircleFollowUpIfUnused()
            com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(applicationContext, false)
            com.example.core.service.MagicTuneCtsAccessibilityService.enterDeepSleepNow(applicationContext, forceImmediate = true)
            com.example.core.assistant.MagicTuneVoiceInteractionService.releaseCapturedAssistBitmap()
            com.example.core.projection.MediaProjectionHolder.releaseIfNoActiveConsumer(applicationContext)
        }
        capturedBitmap = null
        isCameraCapturedBitmap = false
        croppedPreviewBitmap = null
        super.onDestroy()
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    /**
     * Chụp màn hình ứng dụng phía dưới (Hoạt động cả khi ĐÃ TẮT GỠ LỖI WLAN lẫn khi đang bật ADB/Shizuku).
     * Trong lúc chụp (`isCapturing = true`), giao diện Compose tự giữ trong suốt 100% để không che khuất màn hình.
     */
    private fun captureScreenBehindAndShowOverlay() {
        lifecycleScope.launch {
            try {
                isCameraCapturedBitmap = false
                com.example.core.service.MagicTuneCtsAccessibilityService.beginTemporaryBurst(4500L)
                // Bật quyền đọc màn hình ngầm theo nhu cầu (On-Demand) ngay khi mở Khoanh Tròn
                NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(applicationContext, 1300L)

                // 1. Ghi đồng thời nhánh Assist và ContentCapture (chỉ ghi nếu chưa bật)
                com.example.core.service.MagicTuneCtsAccessibilityService.ensureAssistSettingsEnabledIfNeeded(applicationContext)

                // 2. Chờ service kết nối ổn định thay vì timeout quá sớm gây mù màn hình
                if (!com.example.core.service.MagicTuneCtsAccessibilityService.isServiceConnected()) {
                    com.example.core.service.MagicTuneCtsAccessibilityService.awaitServiceInstance(applicationContext, 650L)
                }

                // Tầng 1: Chụp màn hình Offline + Trích xuất toàn bộ tọa độ văn bản trên màn hình qua AccessibilityService / AssistStructure
                var bmp: Bitmap? = withContext(Dispatchers.IO) {
                    withTimeoutOrNull(1500L) {
                        NoAccessibilityScreenEngine.captureScreenOffline(applicationContext)
                    }
                }

                // Tầng 2: Dự phòng qua Shell vào externalCacheDir (tránh SELinux chặn /data/local/tmp) nếu Accessibility chưa kịp kết nối
                val shell = ShellEngine.getInstance(applicationContext)
                if (!NoAccessibilityScreenEngine.isBitmapValidAndNotBlack(bmp) && shell.state.value.isAdbReady) {
                    bmp = withContext(Dispatchers.IO) {
                        try {
                            withTimeoutOrNull(1200L) {
                                val outDir = applicationContext.externalCacheDir ?: applicationContext.cacheDir
                                outDir?.mkdirs()
                                val tmpFile = File(outDir, "magictune_cts.png")
                                if (tmpFile.exists()) tmpFile.delete()
                                val absPath = tmpFile.absolutePath
                                val sdcardFallback = "${android.os.Environment.getExternalStorageDirectory().path}/Android/data/${applicationContext.packageName}/cache/magictune_cts.png"
                                shell.execute(
                                    "screencap -p '$absPath' 2>/dev/null || screencap -p '$sdcardFallback' 2>/dev/null; " +
                                        "chmod 666 '$absPath' '$sdcardFallback' 2>/dev/null || true"
                                )
                                val targetFile = if (tmpFile.exists() && tmpFile.length() > 1024L) {
                                    tmpFile
                                } else {
                                    File(sdcardFallback)
                                }
                                if (targetFile.exists() && targetFile.length() > 1024L) {
                                    BitmapFactory.decodeFile(targetFile.absolutePath)
                                } else null
                            }
                        } catch (_: Throwable) {
                            null
                        }
                    }
                }

                capturedBitmap = if (NoAccessibilityScreenEngine.isBitmapValidAndNotBlack(bmp)) bmp else null
            } catch (_: Throwable) {
            } finally {
                // Hiển thị ngay lập tức 100% lớp phủ viền phát sáng Google và hàng thanh công cụ chức năng đáy màn hình
                isCapturing = false
                window.decorView.alpha = 1f
                triggerGentleHaptic()
                com.example.core.service.MagicTuneCtsAccessibilityService.enterDeepSleepNow(applicationContext, forceImmediate = false)
            }
        }
    }

    /**
     * Dịch tức thì vùng chọn hoặc kích hoạt Lớp Phủ Xuyên Thấu "Cuộn Đến Đâu Dịch Đến Đó" 100% bằng GOOGLE DỊCH (`GoogleScreenTranslator`)
     * kèm quy đổi ngoại tệ sang VNĐ (Tệ ¥/RMB/CNY, USD $, Won ₩, Yên 円...).
     *
     * Khi `activateLiveScrollOverlay = true` (người dùng bấm nút "🌐 Google Dịch (Cuộn & Dịch)"),
     * hệ thống ĐÓNG NGAY màn hình ảnh chụp tĩnh (`finishWithoutAnimation()`) và gắn lớp phủ xuyên thấu
     * `GoogleLiveTranslateOverlay` (`FLAG_NOT_TOUCHABLE`) trực tiếp lên trên ứng dụng thực tế (Taobao, 1688)
     * để người dùng vừa chạm vuốt cuộn trang trực tiếp vừa xem bản dịch Tiếng Việt + giá tiền VNĐ thời gian thực!
     */
    private fun translateRegionWithGoogleNow(
        normLeft: Float,
        normTop: Float,
        normRight: Float,
        normBottom: Float,
        activateLiveScrollOverlay: Boolean
    ) {
        triggerGentleHaptic()

        if (activateLiveScrollOverlay) {
            NoAccessibilityScreenEngine.isLiveScrollTranslateActive = true
            val dm = resources.displayMetrics
            val screenW = dm.widthPixels.coerceAtLeast(1)
            val screenH = dm.heightPixels.coerceAtLeast(1)
            val cachedNodes = NoAccessibilityScreenEngine.lastCapturedScreenNodes
            val (instantBoxes, _) = if (cachedNodes.isNotEmpty()) {
                GoogleScreenTranslator.buildInstantCachedBoxesForNodes(cachedNodes, screenW, screenH)
            } else {
                Pair(emptyList(), false)
            }
            finishWithoutAnimation()
            GoogleLiveTranslateOverlay.start(
                context = applicationContext,
                initialBoxes = instantBoxes
            )
            return
        }

        if (isTranslatingWithGoogle) return
        isTranslatingWithGoogle = true
        activeLensMode = LensMode.TRANSLATE
        uploadErrorMessage = null
        lastSelectionBounds = Rect(normLeft, normTop, normRight, normBottom)

        lifecycleScope.launch {
            val dm = resources.displayMetrics
            val screenW = dm.widthPixels.coerceAtLeast(1)
            val screenH = dm.heightPixels.coerceAtLeast(1)

            var nodes = NoAccessibilityScreenEngine.lastCapturedScreenNodes
            if (nodes.isEmpty()) {
                nodes = withContext(Dispatchers.IO) {
                    NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(applicationContext, 1200L)
                    var liveNodes = NoAccessibilityScreenEngine.extractVisibleScreenNodesNow(applicationContext)
                    if (liveNodes.isEmpty()) {
                        delay(120L)
                        liveNodes = NoAccessibilityScreenEngine.extractVisibleScreenNodesNow(applicationContext)
                    }
                    if (liveNodes.isNotEmpty()) {
                        liveNodes
                    } else {
                        GoogleScreenTranslator.extractNodesViaUiAutomatorFallback(applicationContext)
                    }
                }
            }

            val translatedBoxes = GoogleScreenTranslator.translateScreenNodesToBoxes(
                nodes = nodes,
                screenWidth = screenW,
                screenHeight = screenH,
                constrained = com.example.core.compat.DeviceCompatProfile.recommendedLiveTranslateConcurrency(applicationContext) <= 1,
                normRegion = Rect(normLeft, normTop, normRight, normBottom)
            )

            isTranslatingWithGoogle = false

            if (translatedBoxes.isNotEmpty()) {
                googleTranslationResult = GoogleTranslationResult(
                    translatedText = translatedBoxes.joinToString("\n") { it.translatedText },
                    originalText = translatedBoxes.joinToString("\n") { it.originalText },
                    engineUsed = "Google Dịch + Tự đổi VNĐ",
                    isSuccess = true,
                    boxes = translatedBoxes
                )
            } else {
                // Nếu vùng khoanh tròn là một bức ảnh tĩnh không chứa văn bản UI (node rỗng),
                // chuyển trực tiếp vùng ảnh đó sang Google Lens Dịch Ảnh (lns_mode=tr) của Google!
                processCroppedRegionAndSearchGoogle(
                    normLeft = normLeft,
                    normTop = normTop,
                    normRight = normRight,
                    normBottom = normBottom,
                    initialMode = LensMode.TRANSLATE,
                    forceOpenGoogleLensTranslateSheet = true
                )
            }
        }
    }

    /**
     * Cắt vùng người dùng vừa khoanh tròn và tải lên máy chủ Google Lens (`https://lens.google.com/v3/upload?hl=vi`).
     */
    private fun processCroppedRegionAndSearchGoogle(
        normLeft: Float,
        normTop: Float,
        normRight: Float,
        normBottom: Float,
        initialMode: LensMode,
        forceOpenGoogleLensTranslateSheet: Boolean = false
    ) {
        var sourceBitmap = capturedBitmap
        if (!NoAccessibilityScreenEngine.isBitmapValidAndNotBlack(sourceBitmap)) {
            sourceBitmap = null
        }
        if (sourceBitmap == null) {
            val assistBmp = com.example.core.assistant.MagicTuneVoiceInteractionService.lastCapturedAssistBitmap
            if (NoAccessibilityScreenEngine.isBitmapValidAndNotBlack(assistBmp)) {
                sourceBitmap = assistBmp
                capturedBitmap = assistBmp
            }
        }
        if (sourceBitmap == null) {
            lifecycleScope.launch {
                isUploadingToGoogle = true
                // Ẩn thanh công cụ & nét vẽ trên Compose trong 70ms để chụp màn hình sạch mà không làm đen cửa sổ
                isCapturing = true
                delay(70L)
                com.example.core.service.MagicTuneCtsAccessibilityService.beginTemporaryBurst(4000L)
                var freshBmp = try {
                    withContext(Dispatchers.IO) {
                        NoAccessibilityScreenEngine.autoWakeAccessibilityIfNeeded(applicationContext, 1200L)
                        com.example.core.service.MagicTuneCtsAccessibilityService.ensureAssistSettingsEnabledIfNeeded(applicationContext)
                        if (!com.example.core.service.MagicTuneCtsAccessibilityService.isServiceConnected()) {
                            com.example.core.service.MagicTuneCtsAccessibilityService.awaitServiceInstance(applicationContext, 650L)
                        }
                        withTimeoutOrNull(1800L) {
                            NoAccessibilityScreenEngine.captureScreenOffline(applicationContext)
                        }
                    }
                } finally {
                    com.example.core.service.MagicTuneCtsAccessibilityService.endTemporaryBurstAndIdle(applicationContext, 120L)
                }
                val shell = ShellEngine.getInstance(applicationContext)
                if (!NoAccessibilityScreenEngine.isBitmapValidAndNotBlack(freshBmp) && shell.state.value.isAdbReady) {
                    freshBmp = withContext(Dispatchers.IO) {
                        try {
                            withTimeoutOrNull(1200L) {
                                val outDir = applicationContext.externalCacheDir ?: applicationContext.cacheDir
                                outDir?.mkdirs()
                                val tmpFile = File(outDir, "magictune_cts.png")
                                if (tmpFile.exists()) tmpFile.delete()
                                val absPath = tmpFile.absolutePath
                                val sdcardFallback = "${android.os.Environment.getExternalStorageDirectory().path}/Android/data/${applicationContext.packageName}/cache/magictune_cts.png"
                                shell.execute(
                                    "screencap -p '$absPath' 2>/dev/null || screencap -p '$sdcardFallback' 2>/dev/null; " +
                                        "chmod 666 '$absPath' '$sdcardFallback' 2>/dev/null || true"
                                )
                                val targetFile = if (tmpFile.exists() && tmpFile.length() > 1024L) tmpFile else File(sdcardFallback)
                                if (targetFile.exists() && targetFile.length() > 1024L) {
                                    BitmapFactory.decodeFile(targetFile.absolutePath)
                                } else null
                            }
                        } catch (_: Throwable) {
                            null
                        }
                    }
                }
                isCapturing = false
                capturedBitmap = freshBmp
                isUploadingToGoogle = false
                if (NoAccessibilityScreenEngine.isBitmapValidAndNotBlack(freshBmp)) {
                    processCroppedRegionAndSearchGoogle(normLeft, normTop, normRight, normBottom, initialMode, forceOpenGoogleLensTranslateSheet)
                } else {
                    val fg = NoAccessibilityScreenEngine.getActiveForegroundPackage(applicationContext).orEmpty()
                    val isBanking = fg.isNotBlank() && NoAccessibilityScreenEngine.isSensitiveBankingPackage(fg) && fg != applicationContext.packageName
                    if (isBanking) {
                        Toast.makeText(
                            applicationContext,
                            "🛡️ Ứng dụng hiện tại bảo mật chống chụp ảnh màn hình.",
                            Toast.LENGTH_LONG
                        ).show()
                        finishWithoutAnimation()
                        return@launch
                    }
                    // Dự phòng bằng văn bản đọc màn hình tại vùng khoanh
                    val nodes = withContext(Dispatchers.IO) {
                        NoAccessibilityScreenEngine.extractVisibleScreenNodesNow(applicationContext)
                    }
                    com.example.core.service.MagicTuneCtsAccessibilityService.enterDeepSleepNow(applicationContext, forceImmediate = true)
                    val screenList = nodes.map { it.text.trim() }.filter { it.length >= 2 }.distinct()
                    val screenSummary = screenList.take(25).joinToString(" | ")
                    val fgLabel = try { NoAccessibilityScreenEngine.getActiveForegroundAppLabel(applicationContext).orEmpty() } catch (_: Throwable) { "" }
                    MagicLiveFloatingOverlay.askMagicLiveAboutCircledScreenRegion(
                        context = applicationContext,
                        croppedBase64Jpeg = "",
                        croppedImageFile = null,
                        primaryExtractedText = screenSummary.take(400),
                        candidatePhrases = screenList.take(6),
                        ocrTextFromCroppedBitmap = "",
                        surroundingScreenSummary = screenSummary,
                        foregroundAppLabel = fgLabel
                    )
                    finishWithoutAnimation()
                }
            }
            return
        }

        if (isUploadingToGoogle) return
        isUploadingToGoogle = true
        activeLensMode = initialMode
        uploadErrorMessage = null
        googleTranslationResult = null
        lastSelectionBounds = Rect(normLeft, normTop, normRight, normBottom)
        triggerGentleHaptic()

        lifecycleScope.launch {
            try {
                MagicLiveFloatingOverlay.prewarmGroqConnection()
                val croppedFile = withContext(Dispatchers.IO) {
                    try {
                        val swSource = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O &&
                            sourceBitmap.config == Bitmap.Config.HARDWARE
                        ) {
                            sourceBitmap.copy(Bitmap.Config.ARGB_8888, false) ?: sourceBitmap
                        } else {
                            sourceBitmap
                        }

                        val w = swSource.width
                        val h = swSource.height

                        val leftPx = (normLeft * w).toInt().coerceIn(0, max(0, w - 20))
                        val topPx = (normTop * h).toInt().coerceIn(0, max(0, h - 20))
                        val rightPx = (normRight * w).toInt().coerceIn(leftPx + 20, w)
                        val bottomPx = (normBottom * h).toInt().coerceIn(topPx + 20, h)

                        val cropW = (rightPx - leftPx).coerceIn(20, w - leftPx)
                        val cropH = (bottomPx - topPx).coerceIn(20, h - topPx)

                        val rawCropped = Bitmap.createBitmap(swSource, leftPx, topPx, cropW, cropH)
                        croppedPreviewBitmap = rawCropped

                        val outDir = File(cacheDir, "cts_shares").apply { if (!exists()) mkdirs() }
                        try {
                            outDir.listFiles { f -> f.name.startsWith("cts_region_") && f.name.endsWith(".jpg") }
                                ?.sortedByDescending { it.lastModified() }
                                ?.drop(4)
                                ?.forEach { old -> try { old.delete() } catch (_: Throwable) {} }
                        } catch (_: Throwable) {}
                        val outFile = File(outDir, "cts_region_${System.currentTimeMillis()}.jpg")
                        FileOutputStream(outFile).use { fos ->
                            rawCropped.compress(Bitmap.CompressFormat.JPEG, 85, fos)
                            fos.flush()
                        }
                        lastCroppedFile = outFile

                        try {
                            val maxSide = kotlin.math.max(rawCropped.width, rawCropped.height)
                            val uploadBmp = if (maxSide > 768) {
                                val scale = 768f / maxSide.toFloat()
                                Bitmap.createScaledBitmap(
                                    rawCropped,
                                    (rawCropped.width * scale).toInt().coerceAtLeast(24),
                                    (rawCropped.height * scale).toInt().coerceAtLeast(24),
                                    true
                                )
                            } else rawCropped
                            val jpegBytes = ByteArrayOutputStream().use { baos ->
                                uploadBmp.compress(Bitmap.CompressFormat.JPEG, 75, baos)
                                baos.toByteArray()
                            }
                            if (uploadBmp !== rawCropped && !uploadBmp.isRecycled) {
                                uploadBmp.recycle()
                            }
                            lastCroppedJpegBase64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
                        } catch (_: Throwable) {}

                        outFile
                    } catch (_: Throwable) {
                        null
                    }
                }

                val fgLabel = withContext(Dispatchers.IO) {
                    try { NoAccessibilityScreenEngine.getActiveForegroundAppLabel(applicationContext).orEmpty() } catch (_: Throwable) { "" }
                }

                com.example.core.service.MagicTuneCtsAccessibilityService.enterDeepSleepNow(applicationContext, forceImmediate = true)

                val encodedJpeg = lastCroppedJpegBase64
                if (croppedFile != null && !encodedJpeg.isNullOrBlank()) {
                    MagicLiveFloatingOverlay.askMagicLiveAboutCircledScreenRegion(
                        context = applicationContext,
                        croppedBase64Jpeg = encodedJpeg,
                        croppedImageFile = croppedFile,
                        primaryExtractedText = "",
                        candidatePhrases = emptyList(),
                        ocrTextFromCroppedBitmap = "",
                        surroundingScreenSummary = "",
                        foregroundAppLabel = fgLabel
                    )
                    finishWithoutAnimation()
                    return@launch
                }

                Toast.makeText(
                    applicationContext,
                    "⚠️ Không chụp được vùng ảnh vừa chọn. Vui lòng thử lại nhé!",
                    Toast.LENGTH_SHORT
                ).show()
                finishWithoutAnimation()
            } finally {
                isUploadingToGoogle = false
            }
        }
    }

    /**
     * Chuyển ảnh vừa khoanh sang ứng dụng Google Lens cài trên máy (nếu người dùng bấm nút "Mở App Lens").
     */
    private fun sendImageToExternalGoogleLens(imageFile: File): Boolean {
        return try {
            val authority = "${applicationContext.packageName}.fileprovider"
            val contentUri: Uri = FileProvider.getUriForFile(this, authority, imageFile)

            val targetPackages = listOf(
                "com.google.ar.lens",
                "com.google.android.googlequicksearchbox"
            )
            for (pkg in targetPackages) {
                try {
                    grantUriPermission(pkg, contentUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {}
            }

            val baseSendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                clipData = ClipData.newRawUri("CircleToSearch", contentUri)
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP
                )
            }

            val pm = packageManager
            val resolvedList = pm.queryIntentActivities(baseSendIntent, 0)
                .filter { it.activityInfo.packageName != applicationContext.packageName }
            val lensActivityInfo = resolvedList.firstOrNull { info ->
                val pkg = info.activityInfo.packageName
                val cls = info.activityInfo.name
                (pkg == "com.google.ar.lens" || pkg == "com.google.android.googlequicksearchbox") &&
                    cls.contains("lens", ignoreCase = true)
            } ?: resolvedList.firstOrNull { info ->
                info.activityInfo.packageName == "com.google.ar.lens"
            } ?: resolvedList.firstOrNull { info ->
                info.activityInfo.packageName == "com.google.android.googlequicksearchbox"
            }

            if (lensActivityInfo != null) {
                val explicitLensIntent = Intent(baseSendIntent).apply {
                    setClassName(
                        lensActivityInfo.activityInfo.packageName,
                        lensActivityInfo.activityInfo.name
                    )
                }
                if (startActivitySafe(explicitLensIntent)) return true
            }

            for (pkg in targetPackages) {
                val pkgIntent = Intent(baseSendIntent).apply {
                    setPackage(pkg)
                }
                if (startActivitySafe(pkgIntent)) return true
            }

            val launchIntent = pm.getLaunchIntentForPackage("com.google.ar.lens")
            if (launchIntent != null) {
                launchIntent.action = Intent.ACTION_SEND
                launchIntent.type = "image/jpeg"
                launchIntent.putExtra(Intent.EXTRA_STREAM, contentUri)
                launchIntent.clipData = ClipData.newRawUri("CircleToSearch", contentUri)
                launchIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                if (startActivitySafe(launchIntent)) return true
            }

            false
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Mở trực tiếp hộp thoại Tìm Kiếm Giọng Nói chính gốc của App Google (`VoiceSearchActivity`).
     */
    private fun launchGoogleVoiceSearchNow() {
        triggerGentleHaptic()
        val candidates = listOf(
            Intent(RecognizerIntent.ACTION_WEB_SEARCH).apply {
                setClassName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.googlequicksearchbox.VoiceSearchActivity"
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH)
                putExtra("com.google.android.voicesearch.extra.CALLED_FROM_SEARCH_PLATE", true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            Intent().apply {
                setClassName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.googlequicksearchbox.VoiceSearchActivity"
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            Intent(RecognizerIntent.ACTION_WEB_SEARCH).apply {
                setPackage("com.google.android.googlequicksearchbox")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
        )

        var launched = false
        for (intent in candidates) {
            if (startActivitySafe(intent)) {
                launched = true
                break
            }
        }

        val shell = ShellEngine.getInstance(applicationContext)
        if (shell.state.value.isAdbReady) {
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    shell.execute(
                        "am start --user 0 -a android.speech.action.WEB_SEARCH -n com.google.android.googlequicksearchbox/com.google.android.googlequicksearchbox.VoiceSearchActivity --es android.speech.extra.LANGUAGE_MODEL web_search --ez com.google.android.voicesearch.extra.CALLED_FROM_SEARCH_PLATE true >/dev/null 2>&1 || am start --user 0 -n com.google.android.googlequicksearchbox/com.google.android.googlequicksearchbox.VoiceSearchActivity >/dev/null 2>&1 || true"
                    )
                } catch (_: Exception) {}
            }
            launched = true
        }

        if (!launched) {
            Toast.makeText(
                this,
                "⚠️ Đang mở CH Play để cài đặt ứng dụng Google tìm kiếm giọng nói...",
                Toast.LENGTH_SHORT
            ).show()
            try {
                val playIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.googlequicksearchbox")).apply {
                    setPackage("com.android.vending")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(playIntent)
            } catch (_: Exception) {
                try {
                    val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.googlequicksearchbox")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(webIntent)
                } catch (_: Exception) {}
            }
        }
        finishWithoutAnimation()
    }

    private fun startActivitySafe(intent: Intent): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val options = ActivityOptions.makeBasic().apply {
                    setPendingIntentBackgroundActivityStartMode(
                        @Suppress("DEPRECATION") ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    )
                }
                startActivity(intent, options.toBundle())
            } else {
                startActivity(intent)
            }
            true
        } catch (_: Exception) {
            try {
                startActivity(intent)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    private fun triggerGentleHaptic() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(30L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(30L)
            }
        } catch (_: Exception) {}
    }

    /**
     * Nhường quyền hiển thị nổi trên màn hình cho Trợ lý Magic Overlay kèm vùng ảnh vừa khoanh:
     * Chuyển trực tiếp hình ảnh vừa khoanh + chữ trích xuất trên màn hình sang cho Trợ lý Magic để người dùng hỏi trực tiếp!
     */
    private fun launchMagicLiveFloatingOverlayAndYield() {
        triggerGentleHaptic()

        val shown = MagicLiveFloatingOverlay.showWithAttachedScreenQuery(
            context = this,
            base64Jpeg = lastCroppedJpegBase64,
            imageFile = lastCroppedFile,
            ocrSummary = null
        )

        if (shown) {
            finishWithoutAnimation()
            return
        }
        val launched = com.example.core.service.SystemFloatingHudOverlay.launchMagicLiveAssistantFromForeground(this)
        if (launched) {
            lifecycleScope.launch {
                delay(120L)
                finishWithoutAnimation()
            }
        } else {
            finishWithoutAnimation()
        }
    }

    private fun finishWithoutAnimation() {
        if (activeInstanceRef?.get() === this) {
            activeInstanceRef = null
        }
        if (!CircleToSearchWindowOverlay.isShowing) {
            isOverlayActive = false
            com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(applicationContext, false)
        }
        capturedBitmap = null
        croppedPreviewBitmap = null
        try {
            finishAndRemoveTask()
        } catch (_: Throwable) {
            finish()
        }
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    companion object {
        @Volatile
        var isOverlayActive: Boolean = false

        @Volatile
        var lastCreatedTimestampMs: Long = 0L

        @Volatile
        private var activeInstanceRef: java.lang.ref.WeakReference<CircleToSearchOverlayActivity>? = null

        internal const val LENS_DESKTOP_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
        internal const val LENS_DEFAULT_COOKIE =
            "SOCS=CAISHAgBEhJnd3NfMjAyNDA1MTUtMF9SQzIaAmVuIAEaBgiA_LyaBg; CONSENT=YES+cb.20240101-01-p0.vi+FX+999"

        internal fun resolveIntentToHttpsUrl(rawUrl: String): String? {
            if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) return rawUrl
            try {
                val intent = Intent.parseUri(rawUrl, Intent.URI_INTENT_SCHEME)
                val fallback = intent.getStringExtra("browser_fallback_url")
                    ?: intent.getStringExtra("S.browser_fallback_url")
                if (!fallback.isNullOrBlank() && (fallback.startsWith("http://") || fallback.startsWith("https://"))) {
                    return fallback
                }
                val dataStr = intent.dataString
                if (!dataStr.isNullOrBlank() && (dataStr.startsWith("http://") || dataStr.startsWith("https://"))) {
                    return dataStr
                }
            } catch (_: Throwable) {}

            if (rawUrl.startsWith("intent://")) {
                val body = rawUrl.removePrefix("intent://").substringBefore("#Intent")
                if (body.isNotBlank()) {
                    return "https://$body"
                }
            }
            return null
        }

        /**
         * Tải mảng byte JPEG lên Google Lens với cơ chế ngắt kết nối Socket tức thì (0ms) khi hết thời gian chờ `timeoutMs`,
         * tuyệt đối KHÔNG gọi CookieManager trên luồng nền (tránh deadlock WebViewFactory) và KHÔNG BAO GIỜ bị treo!
         */
        internal suspend fun uploadImageBytesToGoogleLensFast(
            jpegBytes: ByteArray,
            imgWidth: Int,
            imgHeight: Int,
            timeoutMs: Long = 2200L
        ): String? {
            return withTimeoutOrNull(timeoutMs) {
                kotlinx.coroutines.suspendCancellableCoroutine { cont ->
                    val connRef = java.util.concurrent.atomic.AtomicReference<HttpURLConnection?>(null)
                    cont.invokeOnCancellation {
                        try {
                            connRef.getAndSet(null)?.disconnect()
                        } catch (_: Throwable) {}
                    }
                    Thread {
                        val res = uploadImageBytesToGoogleLensStatic(
                            jpegBytes = jpegBytes,
                            imgWidth = imgWidth,
                            imgHeight = imgHeight,
                            connHolder = connRef
                        )
                        if (cont.isActive) {
                            cont.resume(res) {}
                        }
                    }.apply {
                        isDaemon = true
                        start()
                    }
                }
            }
        }

        internal fun uploadImageBytesToGoogleLensStatic(
            jpegBytes: ByteArray,
            imgWidth: Int,
            imgHeight: Int,
            connHolder: java.util.concurrent.atomic.AtomicReference<HttpURLConnection?>? = null
        ): String? {
            val boundary = "----MagicTuneLensBoundary${System.currentTimeMillis()}"
            val ts = System.currentTimeMillis()
            val endpoint = "https://lens.google.com/v3/upload?hl=vi&re=df&st=$ts&vpw=$imgWidth&vph=$imgHeight&ep=ccm"

            var conn: HttpURLConnection? = null
            return try {
                val url = URL(endpoint)
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    doInput = true
                    instanceFollowRedirects = false
                    connectTimeout = 8_000
                    readTimeout = 12_000
                    setRequestProperty("Connection", "close")
                    setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                    setRequestProperty("User-Agent", LENS_DESKTOP_USER_AGENT)
                    setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                    setRequestProperty("Accept-Language", "vi-VN,vi;q=0.9,en-US;q=0.8")
                    setRequestProperty("Origin", "https://lens.google.com")
                    setRequestProperty("Referer", "https://lens.google.com/")
                    setRequestProperty("Cookie", LENS_DEFAULT_COOKIE)
                }
                connHolder?.set(conn)

                val headerBytes = buildString {
                        append("--").append(boundary).append("\r\n")
                        append("Content-Disposition: form-data; name=\"encoded_image\"; filename=\"cts_${imgWidth}x${imgHeight}.jpg\"\r\n")
                        append("Content-Type: image/jpeg\r\n\r\n")
                    }.toByteArray(Charsets.UTF_8)
                val footerBytes = "\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8)
                conn.setFixedLengthStreamingMode(headerBytes.size + jpegBytes.size + footerBytes.size)
                conn.outputStream.use { os ->
                    os.write(headerBytes)
                    os.write(jpegBytes)
                    os.write(footerBytes)
                    os.flush()
                }

                val code = conn.responseCode
                val locationHeader = conn.getHeaderField("Location")
                if ((code in 300..399) && !locationHeader.isNullOrBlank()) {
                    val fullRedirect = when {
                        locationHeader.startsWith("http://") || locationHeader.startsWith("https://") -> locationHeader
                        locationHeader.startsWith("intent://") -> resolveIntentToHttpsUrl(locationHeader) ?: "https://lens.google.com/search?p=0&hl=vi"
                        locationHeader.startsWith("/") -> "https://lens.google.com$locationHeader"
                        else -> "https://lens.google.com/$locationHeader"
                    }
                    val host = runCatching { URL(fullRedirect).host.lowercase() }.getOrDefault("")
                    if (host == "lens.google.com" && fullRedirect.contains("/search")) {
                        if (!fullRedirect.contains("hl=vi")) "$fullRedirect&hl=vi" else fullRedirect
                    } else null
                } else {
                    val rawBody = try {
                        val stream = if (code >= 400) conn.errorStream else conn.inputStream
                        stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(256_000) }.orEmpty()
                    } catch (_: Throwable) {
                        ""
                    }
                    val unescaped = rawBody
                        .replace("\\u003d", "=")
                        .replace("\\u0026", "&")
                        .replace("\\/", "/")
                        .replace("&amp;", "&")
                    val regexLens = Regex("""https://lens\.google\.com/search\?[^"'\s<>\\]+""")
                    val regexRel = Regex("""/search\?[^"'\s<>\\]+""")
                    val found = regexLens.find(unescaped)?.value
                        ?: regexRel.find(unescaped)?.value?.let { "https://lens.google.com$it" }
                    if (!found.isNullOrBlank()) {
                        if (!found.contains("hl=vi")) "$found&hl=vi" else found
                    } else null
                }
            } catch (_: Throwable) {
                null
            } finally {
                connHolder?.set(null)
                try {
                    conn?.disconnect()
                } catch (_: Throwable) {}
            }
        }

        /**
         * Tự động đóng Khoanh tròn hỏi AI để nhường màn hình cho cửa sổ nổi Magic Live AI.
         */
        fun dismissIfActiveForMagicLive() {
            isOverlayActive = false
            CircleToSearchWindowOverlay.dismiss(null)
            val act = activeInstanceRef?.get()
            activeInstanceRef = null
            if (act != null) {
                try {
                    com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(act.applicationContext, false)
                } catch (_: Throwable) {}
                try {
                    act.runOnUiThread {
                        try {
                            act.finishWithoutAnimation()
                        } catch (_: Throwable) {}
                    }
                } catch (_: Throwable) {}
            }
        }

        fun launch(context: Context): Boolean {
            val appCtx = context.applicationContext ?: context

            return try {
                MagicLiveFloatingOverlay.dismiss(appCtx)

                // ƯU TIÊN SỐ 1: Mở trực tiếp Lớp Phủ Kính Xuyên Thấu 100% qua WindowManager (TYPE_APPLICATION_OVERLAY + PixelFormat.TRANSLUCENT)
                // -> KHÔNG chuyển Task, KHÔNG dừng ứng dụng phía dưới, KHÔNG BAO GIỜ bị đen màn hình trên mọi bản MagicOS 7-11 & Android 13-17!
                if (CircleToSearchWindowOverlay.show(appCtx)) {
                    return true
                }

                val intent = Intent(appCtx, CircleToSearchOverlayActivity::class.java).apply {
                    addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP or
                            Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION
                    )
                }
                val options = ActivityOptions.makeBasic().apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                        @Suppress("DEPRECATION")
                        setPendingIntentBackgroundActivityStartMode(
                            ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                        )
                    }
                }

                var started = false
                try {
                    val pi = android.app.PendingIntent.getActivity(
                        appCtx,
                        2026,
                        intent,
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE,
                        options.toBundle()
                    )
                    pi.send()
                    started = true
                } catch (_: Throwable) {}

                if (!started) {
                    try {
                        appCtx.startActivity(intent, options.toBundle())
                        started = true
                    } catch (_: Throwable) {
                        try {
                            appCtx.startActivity(intent)
                            started = true
                        } catch (_: Throwable) {}
                    }
                }

                // Dự phòng qua ShellEngine CHỈ KHI startActivity / PendingIntent bị hệ thống chặn (!started)
                if (!started) {
                    val shell = ShellEngine.getInstance(appCtx)
                    if (shell.state.value.isAdbReady) {
                        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                            try {
                                shell.execute(
                                    "am start --user 0 -n ${appCtx.packageName}/com.example.core.widget.CircleToSearchOverlayActivity --activity-clear-top --activity-no-animation >/dev/null 2>&1"
                                )
                            } catch (_: Throwable) {}
                        }
                        started = true
                    }
                }
                started
            } catch (_: Exception) {
                false
            }
        }
    }
}

@Composable
internal fun ForcedCircleToSearchScreen(
    bitmap: Bitmap?,
    isCameraCapturedBitmap: Boolean,
    croppedPreview: Bitmap?,
    lastCroppedJpegBase64: String?,
    selectionNormBounds: Rect?,
    isCapturing: Boolean,
    isUploadingToGoogle: Boolean,
    isTranslatingWithGoogle: Boolean,
    googleTranslationResult: CircleToSearchOverlayActivity.GoogleTranslationResult?,
    activeLensMode: CircleToSearchOverlayActivity.LensMode,
    uploadErrorMessage: String?,
    onSelectLensMode: (CircleToSearchOverlayActivity.LensMode) -> Unit,
    onCircleSelectionCompleted: (Float, Float, Float, Float, CircleToSearchOverlayActivity.LensMode) -> Unit,
    onActivateInstantGoogleTranslateAndScroll: () -> Unit,
    onSearchFullScreen: () -> Unit,
    onLaunchCameraSearch: () -> Unit,
    onLaunchGoogleVoiceSearch: () -> Unit,
    onLaunchMagicLiveFloatingOverlay: () -> Unit,
    onOpenExternalLensApp: () -> Unit,
    onResetCircleSelection: () -> Unit,
    onDismiss: () -> Unit
) {
    val density = LocalDensity.current
    val context = androidx.compose.ui.platform.LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val googleColors = remember {
        listOf(
            Color(0xFF4285F4), // Google Blue
            Color(0xFFEA4335), // Google Red
            Color(0xFFFBBC05), // Google Yellow
            Color(0xFF34A853), // Google Green
            Color(0xFF4285F4)
        )
    }

    val isPowerSavingOrLowEnd = remember(context) {
        com.example.core.compat.DeviceCompatProfile.isLowEndOrLegacyDevice(context) ||
            com.example.core.compat.DeviceCompatProfile.isDeviceWarmOrHot(context)
    }
    // Chạy hiệu ứng xuất hiện nhẹ 1 lần (280ms) rồi giữ TĨNH 0 FPS để màn hình 120Hz/OLED
    // và GPU SurfaceFlinger nghỉ hoàn toàn thay vì vẽ lại toàn màn hình 120 lần/giây!
    val entryGlowAnim = remember { Animatable(if (isPowerSavingOrLowEnd) 0.78f else 0.25f) }
    LaunchedEffect(isPowerSavingOrLowEnd) {
        if (!isPowerSavingOrLowEnd) {
            entryGlowAnim.animateTo(
                targetValue = 0.80f,
                animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
            )
        }
    }
    val glowAlpha = entryGlowAnim.value

    val borderSweepBrush = remember(googleColors) { Brush.sweepGradient(googleColors) }
    val strokeLinearBrush = remember(googleColors) { Brush.linearGradient(googleColors) }
    val borderCornerRadiusPx = remember(density) { with(density) { 32.dp.toPx() } }
    val selectionCornerRadiusPx = remember(density) { with(density) { 18.dp.toPx() } }
    val borderStrokeStyle = remember(density) { Stroke(width = with(density) { 5.dp.toPx() }) }
    val outerGlowStrokeStyle = remember(density) {
        Stroke(
            width = with(density) { 16.dp.toPx() },
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
    }
    val innerWhiteStrokeStyle = remember(density) {
        Stroke(
            width = with(density) { 5.dp.toPx() },
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
    }
    val selectionBoxBorderStyle = remember(density) { Stroke(width = with(density) { 3.dp.toPx() }) }
    val reusableFingerPath = remember { Path() }

    val fingerPoints = remember { mutableStateListOf<Offset>() }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var preferredCircleMode by remember { mutableStateOf(CircleToSearchOverlayActivity.LensMode.SEARCH) }
    var showCameraOrGalleryMenu by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .onSizeChanged { canvasSize = it }
            .testTag("circle_to_search_overlay_root")
            .pointerInput(googleTranslationResult, isTranslatingWithGoogle) {
                if (googleTranslationResult != null || isTranslatingWithGoogle) {
                    detectTapGestures(
                        onTap = {
                            onResetCircleSelection()
                        }
                    )
                }
            }
    ) {
        // 1. Nền lớp phủ:
        // - Khi khoanh tròn trên màn hình (!isCameraCapturedBitmap): GIỮ TRONG SUỐT NHƯ KÍNH 100% (Color.Transparent = 0x00000000)
        //   để người dùng luôn nhìn thấy trực tiếp nội dung ứng dụng/trang web phía sau lớp phủ!
        // - Chỉ khi người dùng chủ động chụp ảnh từ nút Camera (isCameraCapturedBitmap == true) mới hiển thị bức ảnh vừa chụp.
        if (isCameraCapturedBitmap && bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Ảnh chụp từ Camera để tìm kiếm Google",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x12000000))
            )
        }

        // 2. Bề mặt cảm ứng đón nét vẽ ngón tay KHOANH TRÒN (Lasso / Circle Gesture) - Vô hiệu hóa vẽ khi đang hiện bảng kết quả
        val canDraw = !isCapturing && !isTranslatingWithGoogle && googleTranslationResult == null
        if (canDraw) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(bitmap, canvasSize, preferredCircleMode) {
                        detectDragGestures(
                            onDragStart = { startOffset ->
                                fingerPoints.clear()
                                fingerPoints.add(startOffset)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val lastPt = fingerPoints.lastOrNull()
                                val pos = change.position
                                // Lọc nhiễu chạm dưới ~4.5px để không vẽ lại vô ích ở tần số cảm ứng 240Hz
                                if (lastPt == null ||
                                    ((pos.x - lastPt.x) * (pos.x - lastPt.x) + (pos.y - lastPt.y) * (pos.y - lastPt.y)) >= 20f
                                ) {
                                    fingerPoints.add(pos)
                                }
                            },
                            onDragEnd = {
                                if (fingerPoints.size >= 3 && canvasSize.width > 0 && canvasSize.height > 0) {
                                    val minX = fingerPoints.minOf { it.x }
                                    val maxX = fingerPoints.maxOf { it.x }
                                    val minY = fingerPoints.minOf { it.y }
                                    val maxY = fingerPoints.maxOf { it.y }

                                    val spanX = maxX - minX
                                    val spanY = maxY - minY

                                    if (spanX > 20f || spanY > 20f) {
                                        val normLeft = (minX / canvasSize.width).coerceIn(0f, 1f)
                                        val normTop = (minY / canvasSize.height).coerceIn(0f, 1f)
                                        val normRight = (maxX / canvasSize.width).coerceIn(0f, 1f)
                                        val normBottom = (maxY / canvasSize.height).coerceIn(0f, 1f)
                                        onCircleSelectionCompleted(
                                            normLeft,
                                            normTop,
                                            normRight,
                                            normBottom,
                                            preferredCircleMode
                                        )
                                    } else {
                                        fingerPoints.clear()
                                    }
                                } else if (fingerPoints.isNotEmpty() && canvasSize.width > 0 && canvasSize.height > 0) {
                                    // Single Tap: Chạm nhẹ vào một từ hoặc ảnh -> Tự động tạo ô chọn kích thước chuẩn (~40dp) quanh điểm chạm
                                    val tapPos = fingerPoints.first()
                                    val halfBox = with(density) { 36.dp.toPx() }
                                    val minX = (tapPos.x - halfBox).coerceAtLeast(0f)
                                    val maxX = (tapPos.x + halfBox).coerceAtMost(canvasSize.width.toFloat())
                                    val minY = (tapPos.y - halfBox).coerceAtLeast(0f)
                                    val maxY = (tapPos.y + halfBox).coerceAtMost(canvasSize.height.toFloat())
                                    val normLeft = (minX / canvasSize.width).coerceIn(0f, 1f)
                                    val normTop = (minY / canvasSize.height).coerceIn(0f, 1f)
                                    val normRight = (maxX / canvasSize.width).coerceIn(0f, 1f)
                                    val normBottom = (maxY / canvasSize.height).coerceIn(0f, 1f)
                                    fingerPoints.clear()
                                    onCircleSelectionCompleted(
                                        normLeft,
                                        normTop,
                                        normRight,
                                        normBottom,
                                        preferredCircleMode
                                    )
                                } else {
                                    fingerPoints.clear()
                                }
                            },
                            onDragCancel = {
                                fingerPoints.clear()
                            }
                        )
                    }
            ) {
                // Viền phát sáng 4 màu Google dọc xung quanh mép màn hình (đứng tĩnh 0 FPS sau 280ms)
                drawRoundRect(
                    brush = borderSweepBrush,
                    topLeft = Offset.Zero,
                    size = size,
                    cornerRadius = CornerRadius(borderCornerRadiusPx, borderCornerRadiusPx),
                    style = borderStrokeStyle,
                    alpha = glowAlpha
                )

                // Vẽ nét khoanh tròn lấp lánh theo ngón tay người dùng
                if (fingerPoints.size > 1) {
                    reusableFingerPath.reset()
                    reusableFingerPath.moveTo(fingerPoints.first().x, fingerPoints.first().y)
                    var minX = fingerPoints.first().x
                    var maxX = minX
                    var minY = fingerPoints.first().y
                    var maxY = minY
                    for (i in 1 until fingerPoints.size) {
                        val pt = fingerPoints[i]
                        reusableFingerPath.lineTo(pt.x, pt.y)
                        if (pt.x < minX) minX = pt.x
                        if (pt.x > maxX) maxX = pt.x
                        if (pt.y < minY) minY = pt.y
                        if (pt.y > maxY) maxY = pt.y
                    }

                    drawPath(
                        path = reusableFingerPath,
                        brush = strokeLinearBrush,
                        style = outerGlowStrokeStyle,
                        alpha = 0.48f
                    )

                    drawPath(
                        path = reusableFingerPath,
                        color = Color.White,
                        style = innerWhiteStrokeStyle,
                        alpha = 0.96f
                    )

                    val rectW = maxX - minX
                    val rectH = maxY - minY
                    if (rectW > 18f && rectH > 18f) {
                        drawRoundRect(
                            color = Color.White.copy(alpha = 0.14f),
                            topLeft = Offset(minX, minY),
                            size = Size(rectW, rectH),
                            cornerRadius = CornerRadius(selectionCornerRadiusPx, selectionCornerRadiusPx)
                        )
                        drawRoundRect(
                            brush = strokeLinearBrush,
                            topLeft = Offset(minX, minY),
                            size = Size(rectW, rectH),
                            cornerRadius = CornerRadius(selectionCornerRadiusPx, selectionCornerRadiusPx),
                            style = selectionBoxBorderStyle
                        )
                    }
                }
            }
        }

        // 2B. LỚP PHỦ BẢN DỊCH NỔI GOOGLE DỊCH THEO TỪNG KHUNG CHỮ (Nhỏ gọn 8.5sp, tự động né nhau & quy đổi VNĐ)
        if (activeLensMode == CircleToSearchOverlayActivity.LensMode.TRANSLATE &&
            googleTranslationResult != null &&
            googleTranslationResult.isSuccess &&
            canvasSize.width > 0 && canvasSize.height > 0
        ) {
            val selLeft = selectionNormBounds?.left ?: 0f
            val selTop = selectionNormBounds?.top ?: 0f
            val selRight = selectionNormBounds?.right ?: 1f
            val selBottom = selectionNormBounds?.bottom ?: 1f

            if (googleTranslationResult.boxes.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onTap = {
                                    onResetCircleSelection()
                                }
                            )
                        }
                ) {
                    for (box in googleTranslationResult.boxes) {
                        val boxLeftPx = (canvasSize.width * (selLeft + (box.xmin / 1000f) * (selRight - selLeft))).toInt()
                        val boxTopPx = (canvasSize.height * (selTop + (box.ymin / 1000f) * (selBottom - selTop))).toInt()
                        val rawBoxWidthPx = (canvasSize.width * ((box.xmax - box.xmin) / 1000f) * (selRight - selLeft)).toInt()
                        val maxBoxWidthDp = with(density) { rawBoxWidthPx.coerceAtLeast(110).toDp() }
                        val isPriceBox = box.translatedText.contains("≈") && box.translatedText.contains("đ")

                        Box(
                            modifier = Modifier
                                .offset { IntOffset(boxLeftPx, boxTopPx) }
                                .widthIn(min = 36.dp, max = maxOf(96.dp, maxBoxWidthDp))
                                .clip(RoundedCornerShape(4.5.dp))
                                .background(if (isPriceBox) Color(0xE678350F) else Color(0xE60F172A))
                                .border(
                                    width = 0.75.dp,
                                    color = if (isPriceBox) Color(0xFFF59E0B) else Color(0xFF38BDF8),
                                    shape = RoundedCornerShape(4.5.dp)
                                )
                                .clickable {
                                    GoogleLiveTranslateOverlay.speakVietnameseTranslation(context, box.translatedText)
                                }
                                .padding(horizontal = 3.5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = box.translatedText,
                                color = Color.White,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 10.5.sp,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // 4. Hộp chỉ báo đang xử lý (kèm nút Khoanh lại / Mở App Google Lens để không bao giờ bị kẹt)
        if (isUploadingToGoogle || isTranslatingWithGoogle) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 24.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xF20F172A))
                    .border(1.5.dp, Brush.horizontalGradient(googleColors), RoundedCornerShape(22.dp))
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        CircularProgressIndicator(
                            color = Color(0xFF4285F4),
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(26.dp)
                        )
                        Column {
                            Text(
                                text = if (isTranslatingWithGoogle || activeLensMode == CircleToSearchOverlayActivity.LensMode.TRANSLATE) {
                                    "🌐 Google Dịch đang dịch tức thì & quy đổi VNĐ..."
                                } else {
                                    "🔍 Đang truyền ảnh vùng khoanh sang Google Lens..."
                                },
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = if (isTranslatingWithGoogle || activeLensMode == CircleToSearchOverlayActivity.LensMode.TRANSLATE) {
                                    "Hỗ trợ cuộn đến đâu dịch đến đó cho Taobao, 1688"
                                } else {
                                    "Kết quả tìm kiếm Google sẽ hiển thị ngay bên dưới"
                                },
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF1E293B))
                                .border(1.dp, Color(0xFF64748B), RoundedCornerShape(14.dp))
                                .clickable {
                                    fingerPoints.clear()
                                    onResetCircleSelection()
                                }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "🔄 Khoanh lại",
                                color = Color.White,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (!isTranslatingWithGoogle) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0xFF2563EB))
                                    .border(1.dp, Color(0xFF60A5FA), RoundedCornerShape(14.dp))
                                    .clickable {
                                        onOpenExternalLensApp()
                                    }
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "🚀 Mở App Lens",
                                    color = Color.White,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Thông báo lỗi mạng nếu có
        val errMsg = uploadErrorMessage
        if (errMsg != null && !isUploadingToGoogle) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 24.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xF20F172A))
                    .border(1.dp, Color(0xFFEF4444), RoundedCornerShape(18.dp))
                    .padding(16.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = errMsg,
                        color = Color(0xFFFCA5A5),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Box(
                        modifier = Modifier
                            .defaultMinSize(minHeight = 48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF1E293B))
                            .clickable { onResetCircleSelection() }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                            .testTag("cts_retry_circle_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Thử khoanh lại", color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 5. Thanh hỏi Google chuẩn 1:1 theo ảnh mẫu: viên thuốc ngoài mờ trong suốt, bên trong gồm capsule tìm kiếm (G + Hỏi + Mic) và nút tròn dịch (Translate)
        if (!isCapturing) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(start = 14.dp, end = 14.dp, bottom = 22.dp)
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color(0x73FFFFFF))
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Nút "Trò chuyện với trợ lý" bên trái mở bảng MagicLive
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .shadow(elevation = 2.dp, shape = RoundedCornerShape(26.dp))
                        .clip(RoundedCornerShape(26.dp))
                        .background(Color.White)
                        .clickable { onLaunchMagicLiveFloatingOverlay() }
                        .padding(horizontal = 14.dp)
                        .testTag("cts_magic_live_chat_button"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_cts_sparkle),
                        contentDescription = "Trợ lý",
                        tint = Color(0xFF4285F4),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Trò chuyện với trợ lý",
                        color = Color(0xFF202124),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f),
                        maxLines = 1
                    )
                    Box(
                        modifier = Modifier.size(36.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Hỏi bằng giọng nói",
                            tint = Color(0xFF5F6368),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                Box(
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(Color.White)
                        .clickable { onLaunchCameraSearch() },
                    contentAlignment = Alignment.Center
                ) {
                    Text("📷", fontSize = 22.sp, modifier = Modifier.testTag("cts_camera_ai_button"))
                }
                Spacer(modifier = Modifier.width(6.dp))

                // Nút tròn trắng bên phải: Dịch màn hình tức thì & cuộn (Translate)
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .shadow(elevation = 2.dp, shape = CircleShape)
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable { onActivateInstantGoogleTranslateAndScroll() }
                        .testTag("cts_screen_translate_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_cts_translate),
                        contentDescription = "Dịch màn hình",
                        tint = Color(0xFF3C4043),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(start = 16.dp, top = 16.dp)
                .requiredSize(46.dp)
                .clip(CircleShape)
                .background(Color(0xCC10243A))
                .clickable { onDismiss() }
                .testTag("cts_close_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Đóng khoanh tròn tìm kiếm",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }

    }
}
