package com.example.core.service

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.example.MainActivity
import com.example.R
import com.example.core.projection.MediaProjectionHolder

class MagicTuneMediaProjectionService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_PROJECTION -> {
                MediaProjectionHolder.cleanup()
                stopForegroundCompat()
                stopSelf()
                return START_NOT_STICKY
            }
        }

        if (!startForegroundProjectionNotification()) {
            stopSelf()
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val resultData = try {
            intent?.let {
                IntentCompat.getParcelableExtra(it, EXTRA_RESULT_DATA, Intent::class.java)
            }
        } catch (_: Throwable) {
            null
        }

        if (resultCode != Activity.RESULT_OK || resultData == null) {
            Log.w(TAG, "Invalid MediaProjection token; stopping service")
            if (!MediaProjectionHolder.isProjectionActive) {
                stopForegroundCompat()
                stopSelf()
            }
            return START_NOT_STICKY
        }

        try {
            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
            val projection = mpManager?.getMediaProjection(resultCode, resultData)
            if (projection != null) {
                MediaProjectionHolder.initProjection(projection, applicationContext)
            } else {
                Log.w(TAG, "getMediaProjection returned null")
                stopForegroundCompat()
                stopSelf()
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to initialize MediaProjection: ${t.message}", t)
            MediaProjectionHolder.cleanup()
            stopForegroundCompat()
            stopSelf()
        }

        return START_NOT_STICKY
    }

    override fun onDestroy() {
        MediaProjectionHolder.cleanup()
        stopForegroundCompat()
        super.onDestroy()
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            try { nm.deleteNotificationChannel("magictune_projection_channel") } catch (_: Throwable) {}
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Chụp Màn Hình Tĩnh",
                    NotificationManager.IMPORTANCE_MIN
                ).apply {
                    description = "Kênh ẩn tối thiểu khi chụp khung hình tức thì"
                    setShowBadge(false)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_SECRET
                    enableVibration(false)
                    enableLights(false)
                    setSound(null, null)
                }
                nm.createNotificationChannel(channel)
            }
        }
    }

    private fun startForegroundProjectionNotification(): Boolean {
        return try {
            ensureNotificationChannel()
            val openAppIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val contentPi = PendingIntent.getActivity(
                this,
                NOTIFICATION_ID,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val stopIntent = Intent(this, MagicTuneMediaProjectionService::class.java).apply {
                action = ACTION_STOP_PROJECTION
            }
            val stopPi = PendingIntent.getService(
                this,
                NOTIFICATION_ID + 1,
                stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_magictune)
                .setContentTitle("MagicTune")
                .setContentText("")
                .setOngoing(false)
                .setSilent(true)
                .setShowWhen(false)
                .setVisibility(NotificationCompat.VISIBILITY_SECRET)
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_DEFERRED)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setContentIntent(contentPi)
                .addAction(0, "Dừng", stopPi)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        } catch (t: Throwable) {
            Log.e(TAG, "🛡️ Blocked MediaProjection startForeground crash: ${t.message}", t)
            false
        }
    }

    @Suppress("DEPRECATION")
    private fun stopForegroundCompat() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                stopForeground(true)
            }
        } catch (_: Throwable) {}
    }

    companion object {
        private const val TAG = "MagicTuneProjService"
        const val ACTION_START_PROJECTION = "com.example.core.service.ACTION_START_PROJECTION"
        const val ACTION_STOP_PROJECTION = "com.example.core.service.ACTION_STOP_PROJECTION"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val CHANNEL_ID = "magictune_projection_stealth_v2"
        const val NOTIFICATION_ID = 4910

        val isProjectionActive: Boolean
            get() = MediaProjectionHolder.isProjectionActive

        fun start(context: Context, resultCode: Int, data: Intent) {
            val appCtx = context.applicationContext ?: context
            val intent = Intent(appCtx, MagicTuneMediaProjectionService::class.java).apply {
                action = ACTION_START_PROJECTION
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_RESULT_DATA, data)
            }
            try {
                ContextCompat.startForegroundService(appCtx, intent)
            } catch (t: Throwable) {
                Log.e(TAG, "Cannot start MediaProjection foreground service: ${t.message}", t)
            }
        }

        fun stop(context: Context) {
            val appCtx = context.applicationContext ?: context
            try {
                val intent = Intent(appCtx, MagicTuneMediaProjectionService::class.java).apply {
                    action = ACTION_STOP_PROJECTION
                }
                appCtx.startService(intent)
            } catch (_: Throwable) {
                MediaProjectionHolder.cleanup()
            }
        }
    }
}
