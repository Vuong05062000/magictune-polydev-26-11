package com.example

import android.app.Application
import android.content.ComponentCallbacks2
import android.util.Log
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * MagicTuneApplication: Lớp khởi tạo gốc của ứng dụng.
 * Thiết lập Global Uncaught Exception Handler, Coil GPU Hardware ImageLoader & tác vụ khởi động nền trên IO
 * để mở app tức thì 120Hz/144Hz và tiết kiệm điện tối đa.
 */
class MagicTuneApplication : Application(), ImageLoaderFactory {

    companion object {
        private const val TAG = "MagicTuneApplication"

        val globalCoroutineExceptionHandler = kotlinx.coroutines.CoroutineExceptionHandler { _, throwable ->
            if (throwable is kotlinx.coroutines.CancellationException) return@CoroutineExceptionHandler
            Log.e(TAG, "🛡️ Caught coroutine exception safely: ${throwable.message}", throwable)
        }
    }

    private val appInitScope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + globalCoroutineExceptionHandler
    )

    @Volatile
    private var mainLooperShieldInstalled = false

    override fun newImageLoader(): ImageLoader {
        val budget = com.example.core.perf.DeviceMemoryStorageOptimizer.computeBudget(this)
        return ImageLoader.Builder(this)
            .allowHardware(true)
            .allowRgb565(budget.allowRgb565)
            .crossfade(120)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(budget.coilMemoryCachePercent)
                    .weakReferencesEnabled(true)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("coil_img_cache"))
                    .maxSizeBytes(budget.coilDiskCacheBytes)
                    .build()
            }
            .respectCacheHeaders(false)
            .build()
    }

    override fun onCreate() {
        super.onCreate()

        // Upgrade existing installs away from autonomous wakeup/thermal polling and
        // remove any legacy keep-alive jobs before other startup work begins.
        try {
            com.example.core.perf.MagicTuneSelfPowerGovernor.applyOnDemandThermalSafetyDefaults(applicationContext)
        } catch (_: Throwable) {}

        // Ra-đa bắt ANR tự động (Chỉ kích hoạt ở bản Debug):
        // Cảnh báo đỏ Logcat ngay lập tức nếu có bất kỳ đoạn code nào vi phạm Disk Reads/Writes hoặc Network trên Main Thread
        if (BuildConfig.DEBUG) {
            android.os.StrictMode.setThreadPolicy(
                android.os.StrictMode.ThreadPolicy.Builder()
                    .detectDiskReads()
                    .detectDiskWrites()
                    .detectNetwork()
                    .detectCustomSlowCalls()
                    .penaltyLog()
                    .build()
            )
            android.os.StrictMode.setVmPolicy(
                android.os.StrictMode.VmPolicy.Builder()
                    .detectLeakedSqlLiteObjects()
                    .detectLeakedClosableObjects()
                    .penaltyLog()
                    .build()
            )
            Log.i(TAG, "📡 StrictMode ANR Radar activated in DEBUG mode.")
        }

        // 0. Thiết lập Khiên Chống Sập Toàn Cục (Global Uncaught Exception + Main Looper Shield)
        installGlobalCrashAndLooperShield()

        // 1. Khởi tạo ngay lập tức trạng thái Pro & Auth Session từ bộ nhớ cache cục bộ (0ms UI reactivity)
        try {
            com.example.core.license.LicenseManager.initProFlowFromCache(applicationContext)
            com.example.core.auth.FirebaseAuthManager.initAuthSessionFromCache(applicationContext)
            Log.d("ProRestore", "MagicTuneApplication: initProFlowFromCache & initAuthSessionFromCache executed.")
        } catch (e: Throwable) {
            Log.e(TAG, "🚨 initProFlowFromCache error: ${e.message}")
        }

        // 2. Khởi tạo FirebaseApp nhẹ nhàng (không chặn Main Thread với Auth IPC)
        try {
            if (com.google.firebase.FirebaseApp.getApps(this).isEmpty()) {
                val appCtx = this.applicationContext
                val initialized = try {
                    com.google.firebase.FirebaseApp.initializeApp(appCtx)
                } catch (_: Throwable) { null }
if (initialized == null) {
                    // TUYỆT ĐỐI không hardcode Firebase API key/Application ID trong source code
                    // (chúng sẽ lộ trong APK giải mã). Dùng google-services.json (đã có) để Firebase
                    // tự cấu hình; chỉ fallback manual options khi không có config file.
                    val options = com.google.firebase.FirebaseOptions.Builder()
                        .setApplicationId("1:979840451154:android:9bc6d7866b29e90201558b")
                        .setProjectId("phn-mm-ha-n")
                        .setStorageBucket("phn-mm-ha-n.firebasestorage.app")
                        .build()
                    com.google.firebase.FirebaseApp.initializeApp(appCtx, options)
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "🚨 FirebaseApp init: ${e.message}")
        }

        // One-time repair for the thermal status override written by older app versions.
        appInitScope.launch {
            try {
                val info = packageManager.getPackageInfo(packageName, 0)
                if (info.firstInstallTime >= info.lastUpdateTime) return@launch
                val prefs = getSharedPreferences("magictune_thermal_safety", MODE_PRIVATE)
                if (prefs.getBoolean("legacy_override_reset_v1", false)) return@launch

                val shell = com.example.core.shell.ShellEngine.getInstance(applicationContext)
                val isReady = kotlinx.coroutines.withTimeoutOrNull(2_000L) {
                    shell.state.first { it.isAdbReady }
                } != null
                if (!isReady) return@launch

                val pkg = packageName
                val uid = android.os.Process.myUid()
                val cleanupCommands = listOf(
                    "cmd thermalservice reset",
                    "cmd deviceidle whitelist -$pkg",
                    "dumpsys deviceidle whitelist -$pkg",
                    "cmd appops set --user 0 $pkg RUN_IN_BACKGROUND default",
                    "cmd appops set --user 0 $pkg RUN_ANY_IN_BACKGROUND default",
                    "cmd appops set --user 0 $pkg AUTO_START default",
                    "cmd appops set --user 0 $pkg BOOT_COMPLETED default",
                    "cmd appops set --user 0 $pkg WAKE_LOCK default",
                    "cmd appops set --user 0 $pkg TURN_SCREEN_ON default",
                    "cmd role remove-role-holder --user 0 android.app.role.ASSISTANT $pkg",
                    "if [ \"\$(settings get secure voice_interaction_service)\" = \"$pkg/com.example.core.assistant.MagicTuneVoiceInteractionService\" ]; then settings delete secure voice_interaction_service; fi",
                    "if [ \"\$(settings get secure voice_recognition_service)\" = \"$pkg/com.example.core.assistant.MagicTuneRecognitionService\" ]; then settings delete secure voice_recognition_service; fi",
                    "cmd netpolicy remove restrict-background-whitelist $uid",
                    "cmd netpolicy remove app-idle-whitelist $uid"
                ).joinToString(" ; ") { "$it >/dev/null 2>&1 || true" }
                val result = shell.execute(cleanupCommands, isBackground = true)
                if (result.isSuccess) {
                    prefs.edit().putBoolean("legacy_override_reset_v1", true).apply()
                }
            } catch (_: Throwable) {}
        }

        // 2b + 3. Tác vụ nền nhẹ nhàng trên Dispatchers.IO:
        // Tuyệt đối không mở SQLite Firestore (configureFirestorePersistentCacheOnce) hay quét 7 Widget trên Main Thread lúc khởi động
        appInitScope.launch {
            if (com.example.core.crash.CrashBlackBox.isFirestoreOomRecoveryRequired(applicationContext)) {
                Log.w(TAG, "Firestore OOM recovery is pending; deferring cloud listeners until the user chooses a recovery action.")
                return@launch
            }
            // Hộp đen: Quét phát hiện hệ thống giết ngầm (ApplicationExitInfo - Android 11+)
            try {
                com.example.core.crash.CrashBlackBox.checkAndRecordHistoricalExitReasons(applicationContext)
            } catch (_: Throwable) {}

            try {
                com.example.core.perf.DeviceMemoryStorageOptimizer.configureFirestorePersistentCacheOnce(applicationContext)
            } catch (_: Throwable) {}
            try {
                com.example.core.auth.FirebaseAuthManager.ensureCentralAuthStateObserver(applicationContext)
            } catch (_: Throwable) {}
            // Chủ động làm mới token Firebase trong nền ngay sau khi khởi động
            // để đảm bảo phiên đăng nhập không bao giờ bị mất dù app bị tắt lâu ngày
            try {
                kotlinx.coroutines.delay(2_000L) // Nhường 2s cho Firebase Auth load token từ đĩa trước
                com.example.core.auth.FirebaseAuthManager.refreshFirebaseTokenSilentlyIfNeeded(applicationContext)
            } catch (_: Throwable) {}
            // Khởi tạo trước cấu hình Quản trị viên (Config cục bộ cực nhẹ ~1KB)
            // TUYỆT ĐỐI không nạp hàng ngàn user/thiết bị từ xa khi chưa vào Tab Quản Trị để giữ RAM mát mẻ dưới 120MB
            try {
                val isAdminBoot = com.example.core.license.LicenseManager.isCurrentUserAdmin(applicationContext) ||
                    com.example.core.auth.FirebaseAuthManager.isCurrentAdmin(applicationContext, null)
                if (isAdminBoot) {
                    com.example.core.auth.AdminSessionCache.loadAdminConfigSnapshot(applicationContext)
                }
            } catch (_: Throwable) {}
            try {
                val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                val prefs = applicationContext.getSharedPreferences("magictune_admin_prefs", android.content.Context.MODE_PRIVATE)
                prefs.edit().putString("last_admin_purge_date", todayStr).apply()
            } catch (_: Throwable) {}

            try {
                com.example.data.MagicTuneRepository.enforcePermanentConflictShieldWithoutWlan(applicationContext)
            } catch (_: Throwable) {}

            // Giữ trợ năng ngầm ở trạng thái ngủ (Tắt) khi mở app để tiết kiệm điện năng tuyệt đối
            try {
                com.example.core.service.MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(applicationContext)
            } catch (_: Throwable) {}

            // Khởi động bộ giám sát trần năng lượng < 50 mAh/giờ (Event-Driven, Zero WakeLock)
            try {
                com.example.core.perf.PowerBudgetGuard.evaluateAndEnforceBudget(applicationContext)
            } catch (_: Throwable) {}
        }
    }

    private fun installGlobalCrashAndLooperShield() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                Log.e(
                    TAG,
                    "🛡️ Intercepted uncaught exception on thread [${thread.name}]: ${throwable.message}",
                    throwable
                )
                // 1. Hộp đen: Ghi nhận ngay lập tức toàn bộ Stack Trace + RAM + thông tin thiết bị xuống last_crash.txt
                com.example.core.crash.CrashBlackBox.recordJavaCrash(applicationContext, thread, throwable)

                if (throwable is OutOfMemoryError) {
                    reclaimMemoryEmergency(aggressive = true)
                }
                val mainThread = android.os.Looper.getMainLooper()?.thread
                // Nếu ngoại lệ xảy ra trên luồng nền (IO / Default / Binder / Worker), cô lập luồng đó,
                // TUYỆT ĐỐI KHÔNG chuyển cho defaultHandler để hệ điều hành không đóng sập ứng dụng!
                if (mainThread != null && thread !== mainThread) {
                    return@setDefaultUncaughtExceptionHandler
                }
            } catch (_: Throwable) {}
            defaultHandler?.uncaughtException(thread, throwable)
        }

        // Không bọc lồng Looper.loop() trên Main Thread vì trên Android 12–15 (đặc biệt Honor MagicOS)
        // nếu có lỗi trong lúc ViewRootImpl/Choreographer giữ SyncBarrier sẽ làm treo cứng màn hình Splash -> gây ANR!
        mainLooperShieldInstalled = true
    }

    private fun reclaimMemoryEmergency(aggressive: Boolean) {
        try {
            com.example.core.assistant.MagicTuneVoiceInteractionService.releaseCapturedAssistBitmap()
        } catch (_: Throwable) {}
        try {
            com.example.core.ocr.ScreenOcrEngine.clearScrollOcrFrameCache()
            if (aggressive) {
                com.example.core.ocr.ScreenOcrEngine.releaseIdleResources()
            }
        } catch (_: Throwable) {}
        try {
            com.example.core.widget.AppIconMemoryCache.trimMemory(
                if (aggressive) ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL
                else ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW
            )
        } catch (_: Throwable) {}
        try {
            coil.Coil.imageLoader(this).memoryCache?.clear()
        } catch (_: Throwable) {}
        try {
            com.example.core.projection.MediaProjectionHolder.pauseSurfaceIfIdle()
        } catch (_: Throwable) {}
    }

override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // Không bao giờ chạy GC hay Binder IPC trực tiếp trên Main Thread khi người dùng đang cuộn danh sách
        val isCritical = level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE ||
            level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
            level >= ComponentCallbacks2.TRIM_MEMORY_MODERATE
        appInitScope.launch {
            if (isCritical) {
                reclaimMemoryEmergency(
                    aggressive = level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE ||
                        level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL
                )
            }
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        appInitScope.launch {
            reclaimMemoryEmergency(aggressive = true)
        }
    }

    override fun onTerminate() {
        super.onTerminate()
        // Dọn dẹp toàn bộ coroutine scope để không để task nền chạy sau khi app bị kill
        try {
            appInitScope.cancel()
        } catch (_: Throwable) {}
    }
}
