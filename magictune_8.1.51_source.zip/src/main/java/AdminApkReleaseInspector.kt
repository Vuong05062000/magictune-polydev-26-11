package com.example.core.installer

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.coroutineContext

/** Đọc và kiểm tra metadata APK trước khi phát hành liên kết Google Drive. */
object AdminApkReleaseInspector {

    private const val MAX_APK_SIZE_BYTES = 195L * 1024L * 1024L // 195 MB

    data class InspectedLocalApk(
        val file: File,
        val fileName: String,
        val packageName: String,
        val versionName: String,
        val versionCode: Long,
        val sizeBytes: Long,
        val isTempStagingFile: Boolean
    )

    private fun queryDisplayName(context: Context, uri: Uri): String {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        } catch (_: Throwable) {
            null
        }?.takeIf { it.isNotBlank() } ?: "MagicTune_Release.apk"
    }

    suspend fun prepareApkFromUri(context: Context, uri: Uri): Result<InspectedLocalApk> = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        val stagingDir = File(appCtx.cacheDir, "admin_apk_inspect").apply { if (!exists()) mkdirs() }
        val stagingFile = File(stagingDir, "staging_release_${System.currentTimeMillis()}.apk")
        try {
            // Dọn các tệp tạm cũ
            stagingDir.listFiles()?.forEach { old ->
                if (old.isFile && old.name != stagingFile.name) {
                    try { old.delete() } catch (_: Throwable) {}
                }
            }

            val displayName = queryDisplayName(appCtx, uri)
            val input = appCtx.contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(IllegalStateException("Không thể đọc tệp APK đã chọn."))

            var totalCopied = 0L
            var magicChecked = false
            input.use { src ->
                FileOutputStream(stagingFile).use { dst ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = src.read(buf)
                        if (n == -1) break
                        if (!magicChecked && n >= 4) {
                            magicChecked = true
                            if (buf[0] != 0x50.toByte() || buf[1] != 0x4B.toByte()) {
                                return@withContext Result.failure(
                                    IllegalArgumentException("Tệp vừa chọn không phải định dạng tệp cài đặt Android (.apk).")
                                )
                            }
                        }
                        dst.write(buf, 0, n)
                        totalCopied += n
                        if (totalCopied > MAX_APK_SIZE_BYTES) {
                            return@withContext Result.failure(
                                IllegalArgumentException("Tệp APK vượt quá giới hạn tối đa 195 MB.")
                            )
                        }
                    }
                    dst.flush()
                }
            }

            if (totalCopied < 512 * 1024L) {
                try { stagingFile.delete() } catch (_: Throwable) {}
                return@withContext Result.failure(
                    IllegalArgumentException("Tệp quá nhỏ (${totalCopied / 1024} KB), không phải gói APK hợp lệ.")
                )
            }

            val inspected = inspectApkFile(appCtx, stagingFile, displayName, isTempStagingFile = true)
                ?: run {
                    try { stagingFile.delete() } catch (_: Throwable) {}
                    return@withContext Result.failure(
                        IllegalArgumentException("Không thể đọc thông tin gói từ tệp APK. Tệp có thể bị lỗi hoặc chưa tải xong.")
                    )
                }

            if (inspected.packageName != appCtx.packageName) {
                try { stagingFile.delete() } catch (_: Throwable) {}
                return@withContext Result.failure(
                    IllegalArgumentException(
                        "Tệp APK khác mã gói ứng dụng (${inspected.packageName} ≠ ${appCtx.packageName}). Hãy chọn đúng tệp MagicTune Tool."
                    )
                )
            }

            Result.success(inspected)
        } catch (e: CancellationException) {
            try { stagingFile.delete() } catch (_: Throwable) {}
            throw e
        } catch (e: Throwable) {
            try { stagingFile.delete() } catch (_: Throwable) {}
            Result.failure(e)
        }
    }

    suspend fun prepareCurrentInstalledApk(context: Context): Result<InspectedLocalApk> = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext ?: context
        try {
            val sourcePath = appCtx.applicationInfo.sourceDir
            if (sourcePath.isNullOrBlank()) {
                return@withContext Result.failure(IllegalStateException("Không tìm thấy tệp APK đang cài trên thiết bị."))
            }
            val sourceFile = File(sourcePath)
            if (!sourceFile.exists() || !sourceFile.canRead() || sourceFile.length() < 512 * 1024L) {
                return@withContext Result.failure(IllegalStateException("Không thể truy cập tệp APK gốc của ứng dụng."))
            }
            val inspected = inspectApkFile(
                context = appCtx,
                apkFile = sourceFile,
                fileName = "MagicTune_Tool_Installed.apk",
                isTempStagingFile = false
            ) ?: return@withContext Result.failure(IllegalStateException("Không thể đọc thông tin phiên bản hiện tại."))
            Result.success(
                inspected.copy(
                    fileName = "MagicTune_Tool_v${inspected.versionName}_b${inspected.versionCode}.apk"
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    private fun inspectApkFile(
        context: Context,
        apkFile: File,
        fileName: String,
        isTempStagingFile: Boolean
    ): InspectedLocalApk? {
        return try {
            val pm = context.packageManager
            val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(
                    apkFile.absolutePath,
                    PackageManager.PackageInfoFlags.of(0L)
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(apkFile.absolutePath, 0)
            } ?: return null

            val vCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pkgInfo.versionCode.toLong()
            }
            val vName = pkgInfo.versionName.orEmpty().ifBlank { "Mới" }
            InspectedLocalApk(
                file = apkFile,
                fileName = fileName,
                packageName = pkgInfo.packageName.orEmpty(),
                versionName = vName,
                versionCode = vCode,
                sizeBytes = apkFile.length(),
                isTempStagingFile = isTempStagingFile
            )
        } catch (_: Throwable) {
            null
        }
    }

}
